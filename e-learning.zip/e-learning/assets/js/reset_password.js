// Fungsi toggle password visibility
function togglePassword(inputId, btn) {
  const input = document.getElementById(inputId);
  if (!input) return;

  if (input.type === "password") {
    input.type = "text";
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor"
           stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
        <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 12 52 32" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 52 52 32" stroke="#333" stroke-width="4" fill="none"/>
        <circle cx="32" cy="32" r="14" fill="#fff" stroke="#333" stroke-width="3"/>
        <circle cx="32" cy="32" r="9" fill="#555"/>
        <circle cx="32" cy="32" r="5" fill="#000"/>
        <circle cx="26" cy="26" r="2.5" fill="#bbb" opacity="0.7"/>
      </svg>
    `;
  } else {
    input.type = "password";
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor"
           stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
        <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
        <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
        <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
      </svg>
    `;
  }
}

// Validasi form sebelum submit
document.querySelector('.reset-form').addEventListener('submit', function(e) {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const confirmPassword = document.getElementById('confirm_password').value.trim();

  if (username.length < 3) {
    e.preventDefault();
    Swal.fire({
      icon: 'warning',
      title: 'Username tidak valid',
      text: 'Username wajib diisi minimal 3 karakter.',
      confirmButtonText: 'OK'
    });
    return;
  }
  if (password.length < 6) {
    e.preventDefault();
    Swal.fire({
      icon: 'warning',
      title: 'Password tidak valid',
      text: 'Password wajib diisi minimal 6 karakter.',
      confirmButtonText: 'OK'
    });
    return;
  }
  if (password !== confirmPassword) {
    e.preventDefault();
    Swal.fire({
      icon: 'warning',
      title: 'Password tidak cocok',
      text: 'Password dan konfirmasi password harus sama.',
      confirmButtonText: 'OK'
    });
    return;
  }
});