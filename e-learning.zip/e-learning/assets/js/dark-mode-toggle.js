document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('darkModeToggle');
  const body = document.body;

  if (!toggle) return;

  function enableDarkMode() {
    body.classList.add('dark');
    toggle.checked = true;
    toggle.setAttribute('aria-checked', 'true');
    localStorage.setItem('darkMode', 'enabled');
  }

  function disableDarkMode() {
    body.classList.remove('dark');
    toggle.checked = false;
    toggle.setAttribute('aria-checked', 'false');
    localStorage.setItem('darkMode', 'disabled');
  }

  // Set mode saat halaman dimuat berdasar localStorage
  const savedMode = localStorage.getItem('darkMode');
  if (savedMode === 'enabled') {
    enableDarkMode();
  } else {
    disableDarkMode();
  }

  toggle.addEventListener('change', () => {
    if (toggle.checked) {
      enableDarkMode();
    } else {
      disableDarkMode();
    }
  });
});