document.addEventListener('DOMContentLoaded', () => {
  const carousel = document.querySelector('#carouselExampleIndicators');
  const items = carousel.querySelectorAll('.carousel-item');
  const indicators = carousel.querySelectorAll('.carousel-indicators button');
  let currentIndex = 0;
  const total = items.length;
  const intervalTime = 6000;
  let intervalId;

  function goToSlide(index) {
    if (index === currentIndex) return;

    // Remove active class after fade out delay
    items[currentIndex].classList.remove('active');
    indicators[currentIndex].classList.remove('active');

    // Delay to allow opacity transition before showing next slide
    setTimeout(() => {
      items[index].classList.add('active');
      indicators[index].classList.add('active');
      currentIndex = index;
    }, 100); // 100ms delay, sesuaikan dengan CSS transition
  }

  function nextSlide() {
    let nextIndex = currentIndex + 1;
    if (nextIndex >= total) nextIndex = 0;
    goToSlide(nextIndex);
  }

  // autoplay
  intervalId = setInterval(nextSlide, intervalTime);

  // indicator click event
  indicators.forEach((btn, idx) => {
    btn.addEventListener('click', () => {
      clearInterval(intervalId);
      goToSlide(idx);
      intervalId = setInterval(nextSlide, intervalTime);
    });
  });

  // prev/next buttons
  carousel.querySelector('.carousel-control-prev').addEventListener('click', () => {
    clearInterval(intervalId);
    let prevIndex = currentIndex - 1;
    if (prevIndex < 0) prevIndex = total - 1;
    goToSlide(prevIndex);
    intervalId = setInterval(nextSlide, intervalTime);
  });

  carousel.querySelector('.carousel-control-next').addEventListener('click', () => {
    clearInterval(intervalId);
    nextSlide();
    intervalId = setInterval(nextSlide, intervalTime);
  });
});