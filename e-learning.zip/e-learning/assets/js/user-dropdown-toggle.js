document.addEventListener('DOMContentLoaded', () => {
  const userDropdown = document.querySelector('.user-dropdown');
  if (!userDropdown) return;

  const userBtn = userDropdown.querySelector('.user-name');
  const dropdownMenu = userDropdown.querySelector('.dropdown-menu');

  // Toggle dropdown on click
  userBtn.addEventListener('click', (e) => {
    e.preventDefault();
    userDropdown.classList.toggle('show');
    // Update aria-expanded
    const expanded = userDropdown.classList.contains('show');
    userBtn.setAttribute('aria-expanded', expanded);
  });

  // Close dropdown if clicked outside
  document.addEventListener('click', (e) => {
    if (!userDropdown.contains(e.target)) {
      userDropdown.classList.remove('show');
      userBtn.setAttribute('aria-expanded', 'false');
    }
  });

  // Keyboard accessibility
  userBtn.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      userDropdown.classList.remove('show');
      userBtn.setAttribute('aria-expanded', 'false');
      userBtn.focus();
    }
  });
});