// Fungsi toggle password
function togglePassword(inputId, btn) {
  const input = document.getElementById(inputId);
  if (input.type === "password") {
    input.type = "text";
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" 
           stroke-linecap="round" stroke-linejoin="round" width="28" height="28">
        <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 12 52 32" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 52 52 32" stroke="#333" stroke-width="4" fill="none"/>
        <circle cx="32" cy="32" r="14" fill="#fff" stroke="#333" stroke-width="3"/>
        <circle cx="32" cy="32" r="9" fill="#555"/>
        <circle cx="32" cy="32" r="5" fill="#000"/>
        <circle cx="26" cy="26" r="2.5" fill="#bbb" opacity="0.7"/>
      </svg>
    `;
  } else {
    input.type = "password";
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" 
           stroke-linecap="round" stroke-linejoin="round" width="28" height="28">
        <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
        <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
        <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
      </svg>
    `;
  }
}