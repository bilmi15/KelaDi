document.addEventListener('DOMContentLoaded', () => {
  const notifToggle = document.getElementById('notifToggle');
  const notifList = document.getElementById('notifList');
  const notifCount = document.getElementById('notifCount');

  // Load notifications count & list
  function loadNotifications() {
    fetch('pages/fetch_notifications.php')
      .then(res => res.json())
      .then(data => {
        notifCount.textContent = data.unread_count || 0;
        notifList.innerHTML = '';

        if (data.notifications && data.notifications.length > 0) {
          data.notifications.forEach(notif => {
            const item = document.createElement('a');
            item.href = notif.url || '#';
            item.textContent = notif.message;
            notifList.appendChild(item);
          });
        } else {
          notifList.textContent = 'Tidak ada notifikasi.';
        }
      });
  }

  notifToggle.addEventListener('click', () => {
    const isHidden = notifList.hasAttribute('hidden');
    if (isHidden) {
      notifList.removeAttribute('hidden');
      loadNotifications();
    } else {
      notifList.setAttribute('hidden', '');
    }
  });

  // Optional: refresh notifications every 1 minute
  setInterval(loadNotifications, 60000);
});