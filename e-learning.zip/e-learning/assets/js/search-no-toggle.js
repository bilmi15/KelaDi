document.addEventListener('DOMContentLoaded', () => {
  const searchForm = document.querySelector('.header-search-form');
  if (!searchForm) return;

  const searchInput = searchForm.querySelector('input[type="text"]');

  searchForm.addEventListener('submit', (e) => {
    if (searchInput.value.trim() === '') {
      e.preventDefault();
      searchInput.focus();
      alert('Masukkan kata kunci pencarian!');
    }
  });
});