<?php 
session_start();
require_once '../includes/config.php';

// Define $role variable based on session data
$role = $_SESSION['role'] ?? null;

// Ensure user is logged in and has a valid role
if (!isset($_SESSION['user_id']) || !in_array($role, ['dosen', 'mahasiswa'])) {
    header("Location: login.php");
    exit;
}

// Fetch the list of classes for the logged-in 'dosen'
$stmt = $pdo->prepare("SELECT * FROM kelas WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$kelasList = $stmt->fetchAll();

$kelas_id = $_GET['kelas_id'] ?? null;
$mahasiswaList = [];

if ($kelas_id) {
    // Check if the selected kelas_id exists
    $stmt = $pdo->prepare("SELECT * FROM kelas WHERE id = ?");
    $stmt->execute([$kelas_id]);
    $kelas = $stmt->fetch();
    
    if (!$kelas) {
        echo "Kelas tidak ditemukan!";
        exit;
    }

    // Fetch students in the selected class with attendance count
    $stmt = $pdo->prepare("SELECT u.id, u.name, 
                                  COUNT(a.id) AS jumlah_absensi
                           FROM users u
                           LEFT JOIN absensi a ON u.id = a.user_id AND a.kelas_id = ?
                           JOIN kelas_mahasiswa km ON u.id = km.mahasiswa_id
                           WHERE km.kelas_id = ?
                           GROUP BY u.id");
    $stmt->execute([$kelas_id, $kelas_id]);
    $mahasiswaList = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Daftar Mahasiswa per Kelas | Dashboard Dosen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../css/jumlah_mhs.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="container">
    <h2>Daftar Mahasiswa per Kelas</h2>

    <!-- Form to select class -->
    <form method="GET">
        <div class="mb-3">
            <label for="kelas_id" class="form-label">Pilih Kelas</label>
            <select name="kelas_id" id="kelas_id" class="form-control" onchange="this.form.submit()">
                <option value="">-- Pilih Kelas --</option>
                <?php foreach ($kelasList as $kelas): ?>
                    <option value="<?= $kelas['id'] ?>" <?= $kelas['id'] == $kelas_id ? 'selected' : '' ?>><?= htmlspecialchars($kelas['nama_kelas']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>

    <?php if ($kelas_id): ?>
        <h3>Mahasiswa di Kelas <?= htmlspecialchars($kelas['nama_kelas']) ?></h3>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Mahasiswa</th>
                        <th>Jumlah Absensi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($mahasiswaList as $index => $mahasiswa): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($mahasiswa['name']) ?></td>
                            <td><?= $mahasiswa['jumlah_absensi'] ?> / 16</td>
                            <td>
                                <a href="edit_mahasiswa.php?id=<?= $mahasiswa['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="hapus_mahasiswa.php?id=<?= $mahasiswa['id'] ?>" class="btn btn-danger btn-sm">Hapus</a>
                                <a href="tambah_absensi_mahasiswa.php?id=<?= $mahasiswa['id'] ?>" class="btn btn-success btn-sm">Absensi</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
</body>
</html>