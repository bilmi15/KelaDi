<?php     
session_start();
require_once '../includes/config.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
}

// Ambil detail pengguna
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['name'];
$role = $_SESSION['role']; // Periksa role: dosen atau mahasiswa

// Hitung total data dari berbagai tabel
$stmt = $pdo->query("SELECT COUNT(*) FROM kelas");
$total_kelas = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM materi");
$total_materi = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM tugas");
$total_tugas = $stmt->fetchColumn();

// Hitung total forum berdasar user_id
$stmt = $pdo->prepare("SELECT COUNT(*) FROM forum WHERE user_id = ?");
$stmt->execute([$user_id]);
$total_forum = $stmt->fetchColumn();

// Hitung total nilai berdasar dinilai_oleh
$stmt = $pdo->prepare("SELECT COUNT(*) FROM nilai WHERE dinilai_oleh = ?");
$stmt->execute([$user_id]);
$total_nilai = $stmt->fetchColumn();

// Hitung total notifikasi yang belum dibaca berdasar user_id
$stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$user_id]);
$total_notifikasi = $stmt->fetchColumn();

// Untuk dosen, hitung total uploads miliknya, mahasiswa tidak punya akses ini
if ($role === 'dosen') {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM uploads WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_uploads = $stmt->fetchColumn();
} else {
    $total_uploads = 0;
}

// Hitung total user dalam sistem
$stmt = $pdo->query("SELECT COUNT(*) FROM users");
$total_users = $stmt->fetchColumn();

$base_url = '/e-learning/';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Dashboard | KelaDi E-Learning</title>

    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/dashboard.css" />

</head>

<body>
    <?php include 'dashboard_header.php'; ?>

    <div class="wrapper">
        <aside class="sidebar" role="navigation" aria-label="Menu navigasi utama">
            <h5>Menu Dashboard</h5>
            <nav>
                <a href="#" class="nav-item active" data-page="<?= $base_url ?>pages/dashboard_home.php">🏠 Home</a>
                <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/kelas.php">🏫 Kelas</a>
                <?php if ($role === 'dosen') : ?>
                    <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/materi.php">📚 Materi</a>
                <?php else : ?>
                    <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/materi.php">📚 Materi</a>
                <?php endif; ?>
                <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/tugas.php">📝 Tugas</a>
                <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/forum.php">💬 Forum</a>
                <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/nilai.php">📊 Nilai</a>
                <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/notification.php">🔔 Notifikasi</a>
                <?php if ($role === 'dosen') : ?>
                    <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/upload.php">📥 Hasil Tugas</a>
                <?php else : ?>
                    <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/upload.php">📤 Upload Tugas</a>
                <?php endif; ?>
                <?php if ($role === 'dosen') : ?>
                    <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/jumlah_mahasiswa.php">👨🏻‍🎓 Jumlah Mahasiswa</a>
                <?php else : ?>
                <?php endif; ?>
                <?php if ($role === 'dosen') : ?>
                    <a href="#" class="nav-item" data-page="<?= $base_url ?>pages/admin_users.php">👤 List User</a>
                <?php else : ?>
                <?php endif; ?>
            </nav>
        </aside>

        <main class="content" role="main" aria-live="polite">
            <iframe id="content-frame" src="<?= $base_url ?>pages/dashboard_home.php" title="Konten Dashboard"></iframe>
        </main>
    </div>

    <?php include 'dashboard_footer.php'; ?>

    <script>
        const navItems = document.querySelectorAll('.sidebar .nav-item');
        const iframe = document.getElementById('content-frame');

        navItems.forEach(item => {
            item.addEventListener('click', e => {
                e.preventDefault();
                navItems.forEach(i => i.classList.remove('active'));
                item.classList.add('active');
                const page = item.getAttribute('data-page');
                iframe.src = page;
            });
        });
    </script>

</body>
</html>