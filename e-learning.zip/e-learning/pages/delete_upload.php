<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: upload.php");
    exit;
}

$id = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM uploads WHERE id = ?");
$stmt->execute([$id]);
$upload = $stmt->fetch();

if (!$upload) {
    header("Location: upload.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        try {
            if ($upload['file_url'] && !filter_var($upload['file_url'], FILTER_VALIDATE_URL)) {
                $filePath = '../' . $upload['file_url'];
                if (file_exists($filePath)) unlink($filePath);
            }

            $stmt = $pdo->prepare("DELETE FROM uploads WHERE id = ?");
            $stmt->execute([$id]);

            $_SESSION['success'] = "File berhasil dihapus.";
            header("Location: upload.php");
            exit;
        } catch (Exception $e) {
            $error = "Gagal menghapus file: " . $e->getMessage();
        }
    } else {
        header("Location: upload.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Hapus Upload | Dashboard Dosen</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="../assets/css/upload_delete.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
main.container {
    max-width: 480px;
    margin: 50px auto;
    background: white;
    padding: 30px 40px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    text-align: center;
    color: #2c2c2c;
}
</style>
</head>
<body>

<main class="container">
    <h2>Konfirmasi Hapus Upload</h2>
    <p>Apakah Anda yakin ingin menghapus file berikut?</p>
    <p><strong><?= htmlspecialchars($upload['file_name']) ?></strong></p>

    <form method="post" action="">
        <button type="submit" name="confirm" value="yes" class="btn btn-danger">Ya, Hapus</button>
        <a href="upload.php" class="btn btn-secondary">Batal</a>
    </form>
</main>

<?php if ($error): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: <?= json_encode($error) ?>,
    showConfirmButton: true
});
</script>
<?php endif; ?>

</body>
</html>