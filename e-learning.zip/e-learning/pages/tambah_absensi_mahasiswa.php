<?php 
session_start();
require_once '../includes/config.php';

// Pastikan hanya dosen yang bisa mengakses halaman ini
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];  // Using session's user_id
$mahasiswa_id = $_GET['id'] ?? null;  // ID mahasiswa
$kelas_id = $_GET['kelas_id'] ?? null;  // ID kelas
$error = '';  // Menyimpan pesan error

// Cek apakah kelas_id valid dan ada di tabel kelas
if ($kelas_id) {
    $stmt = $pdo->prepare("SELECT id, nama_kelas FROM kelas WHERE id = ?");
    $stmt->execute([$kelas_id]);
    $kelas = $stmt->fetch();
    if (!$kelas) {
        $error = "Kelas dengan ID yang diberikan tidak ditemukan.";
    }
}

// Cek apakah mahasiswa_id valid
if ($mahasiswa_id) {
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE id = ? AND role = 'mahasiswa'");
    $stmt->execute([$mahasiswa_id]);
    $mahasiswa = $stmt->fetch();
    if (!$mahasiswa) {
        $error = "Mahasiswa dengan ID yang diberikan tidak ditemukan.";
    }
} else {
    $error = "ID Mahasiswa tidak valid.";
}

// Tampilkan pesan error jika ada
if ($error) {
    echo "<div class='alert alert-danger'>$error</div>";
    exit;
}

// Mengambil kelas_id yang diikuti oleh mahasiswa dari tabel kelas_mahasiswa
$stmt = $pdo->prepare("SELECT kelas_id FROM kelas_mahasiswa WHERE mahasiswa_id = ?");
$stmt->execute([$mahasiswa_id]);
$kelas_mahasiswa = $stmt->fetch();

// Jika kelas_mahasiswa ditemukan, maka kelas_id terisi otomatis
if ($kelas_mahasiswa) {
    $kelas_id = $kelas_mahasiswa['kelas_id'];
} else {
    $error = "Mahasiswa tidak terdaftar dalam kelas.";
    echo "<div class='alert alert-danger'>$error</div>";
    exit;
}

// Proses absensi untuk setiap pertemuan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    $pertemuan = $_POST['pertemuan'] ?? null;
    $absen_status = $_POST['absen_status'] ?? null;  // Status absensi yang dipilih
    
    if ($pertemuan && $absen_status) {
        // Cek apakah absensi sudah ada untuk pertemuan tertentu
        $stmt = $pdo->prepare("SELECT id FROM absensi WHERE user_id = ? AND kelas_id = ? AND pertemuan = ?");
        $stmt->execute([$mahasiswa_id, $kelas_id, $pertemuan]);
        $existing = $stmt->fetch();

        // If absence already exists for this meeting, show an error
        if ($existing) {
            $error = "Absensi untuk pertemuan ini sudah ada.";
        } else {
            // Check if previous meetings have been filled in sequential order
            for ($i = 1; $i < $pertemuan; $i++) {
                $stmt = $pdo->prepare("SELECT id FROM absensi WHERE user_id = ? AND kelas_id = ? AND pertemuan = ?");
                $stmt->execute([$mahasiswa_id, $kelas_id, $i]);
                $previous_absence = $stmt->fetch();

                // If a previous meeting is missing, return an error
                if (!$previous_absence) {
                    $error = "Absensi untuk pertemuan ke-$i belum diisi. Harap mengisi absensi secara berurutan.";
                    break;
                }
            }

            // If no errors, insert the absence
            if (!$error) {
                // Insert absensi baru
                $stmt = $pdo->prepare("INSERT INTO absensi (user_id, kelas_id, pertemuan, absen_status) VALUES (?, ?, ?, ?)");
                $stmt->execute([$mahasiswa_id, $kelas_id, $pertemuan, $absen_status]);

                $_SESSION['success'] = "Absensi berhasil ditambahkan untuk pertemuan ke-$pertemuan.";
                header("Location: tambah_absensi_mahasiswa.php?id=$mahasiswa_id&kelas_id=$kelas_id");
                exit;
            }
        }
    } else {
        $error = "Pilih pertemuan dan status absensi.";
    }
}

// Menampilkan absensi yang sudah ada
$stmt = $pdo->prepare("SELECT * FROM absensi WHERE user_id = ? AND kelas_id = ? ORDER BY pertemuan ASC");
$stmt->execute([$mahasiswa_id, $kelas_id]);
$absensi = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tambah Absensi Mahasiswa | Dashboard Dosen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/absensi_mahasiswa.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="container">
    <h2>Tambah Absensi untuk Mahasiswa <?= htmlspecialchars($mahasiswa['name']) ?></h2>

    <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="pertemuan" class="form-label">Pilih Pertemuan</label>
            <select name="pertemuan" id="pertemuan" class="form-control" required>
                <option value="">Pilih Pertemuan</option>
                <?php for ($i = 1; $i <= 16; $i++): ?>
                    <option value="<?= $i ?>">Pertemuan ke-<?= $i ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="absen_status" class="form-label">Status Absensi</label>
            <select name="absen_status" id="absen_status" class="form-control" required>
                <option value="">Pilih Status</option>
                <option value="Hadir">Hadir</option>
                <option value="Sakit">Sakit</option>
                <option value="Izin">Izin</option>
                <option value="Alfa">Alfa</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Simpan Absensi</button>
        <a href="jumlah_mahasiswa.php?id=<?= $mahasiswa_id ?>&kelas_id=<?= $kelas_id ?>" class="btn btn-secondary">Kembali</a>
    </form>

    <h4>Daftar Absensi</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Pertemuan</th>
                <th>Status Absensi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($absensi as $item): ?>
            <tr>
                <td>Pertemuan ke-<?= $item['pertemuan'] ?></td>
                <td><?= htmlspecialchars($item['absen_status']) ?></td>
                <td>
                    <a href="hapus_absensi_mahasiswa.php?id=<?= $item['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus absensi ini?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>