<?php
session_start();

// Hapus semua session
$_SESSION = [];

// Hancurkan session
session_destroy();

// Redirect ke halaman utama / login
header('Location: ../index.php');
exit;