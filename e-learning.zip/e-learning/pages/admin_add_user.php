<?php
session_start();
require_once '../includes/config.php';

// Generate CSRF token jika belum ada
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Cek apakah pengguna sudah login dan memiliki role 'dosen'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'dosen') {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Token keamanan tidak valid. Silakan coba lagi.";
    } else {
        $username = trim($_POST['username']);
        $name = trim($_POST['name']);
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        $role = isset($_POST['role']) && in_array($_POST['role'], ['dosen', 'mahasiswa']) ? $_POST['role'] : 'mahasiswa';
        $is_approved = isset($_POST['is_approved']) ? 1 : 0;

        if (strlen($username) < 3) {
            $error = "Username minimal 3 karakter.";
        } elseif (strlen($name) < 3) {
            $error = "Nama lengkap wajib diisi minimal 3 karakter.";
        } elseif (strlen($password) < 6) {
            $error = "Password minimal 6 karakter.";
        } elseif ($password !== $confirmPassword) {
            $error = "Password dan konfirmasi password tidak cocok.";
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user) {
                $error = "Username sudah digunakan.";
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, name, password, role, is_approved) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$username, $name, $hashedPassword, $role, $is_approved]);

                $_SESSION['success_message'] = "User berhasil ditambahkan.";
                header("Location: " . $_SERVER['PHP_SELF']);
                exit;
            }
        }
    }
}

if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tambah User Baru | Dashboard Dosen</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/admin_add_user.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<main class="container mt-4">
  <h2>Tambah User Baru</h2>

  <form method="post" action="" novalidate>
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

    <div class="mb-3 position-relative">
      <label for="username" class="form-label">Username</label>
      <input type="text" name="username" id="username" class="form-control" required minlength="3" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" />
    </div>

    <div class="mb-3 position-relative">
      <label for="name" class="form-label">Nama Lengkap</label>
      <input type="text" name="name" id="name" class="form-control" required minlength="3" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" />
    </div>

    <div class="mb-3 position-relative">
      <label for="password" class="form-label">Password</label>
      <input type="password" name="password" id="password" class="form-control" required minlength="6" />
      <button
        type="button"
        class="password-toggle-btn1"
        onclick="togglePassword('password', this)"
        aria-label="Toggle password visibility"
      >
        <!-- Ikon mata tertutup default -->
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
          <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
          <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
          <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
          <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
        </svg>
      </button>
      <div id="passwordHelp" class="form-text">Minimal 6 karakter.</div>
    </div>

    <div class="mb-3 position-relative">
      <label for="confirm_password" class="form-label">Konfirmasi Password</label>
      <input type="password" name="confirm_password" id="confirm_password" class="form-control" required minlength="6" />
      <button
          type="button"
          class="password-toggle-btn2"
          onclick="togglePassword('confirm_password', this)"
          aria-label="Toggle password visibility"
       >
      <!-- Ikon mata tertutup default -->
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
          <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
          <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
          <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
          <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
        </svg>
      </button>
      <div id="passwordHelp" class="form-text">Minimal 6 karakter.</div>
    </div>

    <div class="mb-3">
      <label for="role" class="form-label">Pilih Role</label>
      <select id="role" name="role" class="form-select" required>
        <option value="mahasiswa" <?= (($_POST['role'] ?? '') === 'mahasiswa') ? 'selected' : '' ?>>Mahasiswa (User)</option>
        <option value="dosen" <?= (($_POST['role'] ?? '') === 'dosen') ? 'selected' : '' ?>>Dosen (Admin)</option>
      </select>
    </div>

    <div class="form-check mb-3">
      <input class="form-check-input" type="checkbox" id="is_approved" name="is_approved" <?= isset($_POST['is_approved']) ? 'checked' : '' ?> />
      <label class="form-check-label" for="is_approved">Setujui user langsung (Approved)</label>
    </div>

    <button type="submit" class="btn btn-primary">Tambah User</button>
    <a href="admin_users.php" class="btn btn-secondary">Kembali</a>
  </form>
</main>

<script>
function togglePassword(id, btn) {
  const input = document.getElementById(id);
  if (input.type === "password") {
    input.type = "text";
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" 
           stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
        <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 12 52 32" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 52 52 32" stroke="#333" stroke-width="4" fill="none"/>
        <circle cx="32" cy="32" r="14" fill="#fff" stroke="#333" stroke-width="3"/>
        <circle cx="32" cy="32" r="9" fill="#555"/>
        <circle cx="32" cy="32" r="5" fill="#000"/>
        <circle cx="26" cy="26" r="2.5" fill="#bbb" opacity="0.7"/>
      </svg>
    `;
  } else {
    input.type = "password";
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" 
           stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
        <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
        <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
        <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
        <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
      </svg>
    `;
  }
}

// SweetAlert notifikasi sukses
<?php if ($success): ?>
Swal.fire({
    icon: 'success',
    title: 'Sukses',
    text: <?= json_encode($success) ?>,
    timer: 3000,
    showConfirmButton: false
});
<?php endif; ?>

// SweetAlert notifikasi error
<?php if ($error): ?>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: <?= json_encode($error) ?>,
    timer: 4000,
    showConfirmButton: true
});
<?php endif; ?>
</script>

</body>
</html>