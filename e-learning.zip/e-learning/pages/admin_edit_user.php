<?php
session_start();
require_once '../includes/config.php';

// Cek apakah pengguna sudah login dan memiliki role 'dosen'
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin_users.php");
    exit;
}

$id = (int)$_GET['id'];
$error = '';
$success = '';

// Ambil data user berdasarkan id
$stmt = $pdo->prepare("SELECT id, username, name, role, is_approved FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    header("Location: admin_users.php");
    exit;
}

// Proses update data user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $name = trim($_POST['name']);
    $role = $_POST['role'] ?? 'mahasiswa';
    $is_approved = isset($_POST['is_approved']) ? 1 : 0;

    if (strlen($username) < 3 || strlen($name) < 3) {
        $error = "Username dan nama lengkap minimal 3 karakter.";
    } else {
        // Cek apakah username sudah dipakai user lain
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $stmt->execute([$username, $id]);
        if ($stmt->fetch()) {
            $error = "Username sudah digunakan oleh user lain.";
        } else {
            // Update data user
            $stmt = $pdo->prepare("UPDATE users SET username = ?, name = ?, role = ?, is_approved = ? WHERE id = ?");
            $stmt->execute([$username, $name, $role, $is_approved, $id]);
            
            $_SESSION['success_message'] = "User berhasil diperbarui.";
            
            // Redirect ke halaman yang sama untuk mencegah form resubmission
            header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $id);
            exit;
        }
    }
}

// Ambil pesan sukses dari session
if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);

    // Refresh data user untuk menampilkan data terbaru
    $stmt = $pdo->prepare("SELECT id, username, name, role, is_approved FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit User | Dashboard Dosen</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/admin_edit_user.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<main class="container mt-4">
  <h2>Edit User</h2>

  <form method="post" action="">
    <div class="mb-3">
      <label for="username" class="form-label">Username</label>
      <input type="text" name="username" id="username" class="form-control" required minlength="3" value="<?= htmlspecialchars($user['username']) ?>" />
    </div>
    <div class="mb-3">
      <label for="name" class="form-label">Nama Lengkap</label>
      <input type="text" name="name" id="name" class="form-control" required minlength="3" value="<?= htmlspecialchars($user['name']) ?>" />
    </div>
    <div class="mb-3">
      <label for="role" class="form-label">Role</label>
      <select name="role" id="role" class="form-select" required>
        <option value="mahasiswa" <?= $user['role'] === 'mahasiswa' ? 'selected' : '' ?>>Mahasiswa</option>
        <option value="dosen" <?= $user['role'] === 'dosen' ? 'selected' : '' ?>>Dosen (Admin)</option>
      </select>
    </div>
    <div class="form-check mb-3">
      <input class="form-check-input" type="checkbox" id="is_approved" name="is_approved" <?= $user['is_approved'] ? 'checked' : '' ?> />
      <label class="form-check-label" for="is_approved">Disetujui</label>
    </div>

    <button type="submit" class="btn btn-primary">Perbarui User</button>
    <a href="admin_users.php" class="btn btn-secondary">Kembali</a>
  </form>
</main>

<script>
// Tampilkan SweetAlert notifikasi sukses atau error
<?php if ($success): ?>
Swal.fire({
  icon: 'success',
  title: 'Sukses',
  text: <?= json_encode($success) ?>,
  timer: 3000,
  showConfirmButton: false
});
<?php endif; ?>

<?php if ($error): ?>
Swal.fire({
  icon: 'error',
  title: 'Error',
  text: <?= json_encode($error) ?>,
  timer: 4000,
  showConfirmButton: true
});
<?php endif; ?>
</script>

</body>
</html>