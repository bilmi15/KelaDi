<?php 
session_start();
require_once '../includes/config.php';

// Check if the user is logged in and has a valid role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['dosen', 'mahasiswa'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

$error = '';
$success = '';
$uploadDir = '../uploads/';

// Logic for mahasiswa uploading assignments
if ($role === 'mahasiswa') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $uploadMethod = $_POST['upload_method'] ?? 'file'; // 'file' or 'url'
        $desc = trim($_POST['description'] ?? '');
        $tugas_id = $_POST['tugas_id'] ?? 0; // ID of the task the student is uploading for

        // Fetch the deadline for the task from the database
        $stmt = $pdo->prepare("SELECT deadline FROM tugas WHERE id = ?");
        $stmt->execute([$tugas_id]);
        $task = $stmt->fetch();

        if ($task) {
            // Check if the deadline has passed
            $deadline = new DateTime($task['deadline']);
            $now = new DateTime();
            
            if ($now > $deadline) {
                // Deadline has passed, prevent submission
                $error = "The deadline for this task has passed. You cannot submit it anymore.";
            } else {
                // Only allow local file upload (PDF only)
                if ($uploadMethod === 'file') {
                    if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] === UPLOAD_ERR_OK) {
                        $fileTmpPath = $_FILES['upload_file']['tmp_name'];
                        $fileName = basename($_FILES['upload_file']['name']);
                        $fileSize = $_FILES['upload_file']['size'];
                        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

                        // Only accept PDF files
                        if ($fileType !== 'pdf') {
                            $error = "Only PDF files are allowed.";
                        } elseif ($fileSize > 20 * 1024 * 1024) {
                            $error = "File size exceeds the maximum limit of 20MB.";
                        } else {
                            $newFileName = uniqid('upload_', true) . '.' . $fileType;
                            $destPath = $uploadDir . $newFileName;

                            if (move_uploaded_file($fileTmpPath, $destPath)) {
                                $fileUrl = 'uploads/' . $newFileName;
                            } else {
                                $error = "Failed to move the uploaded file.";
                            }
                        }
                    } else {
                        $error = "No file uploaded or an error occurred during upload.";
                    }
                } else {
                    $error = "Only local file uploads are allowed. URL uploads are not accepted.";
                }

                if (!$error) {
                    // Insert or update file data into the database
                    if (isset($_POST['edit_id'])) {
                        // Update file if editing
                        $stmt = $pdo->prepare("UPDATE uploads SET file_name = ?, file_type = ?, file_url = ?, description = ?, tugas_id = ?, uploaded_at = NOW() WHERE id = ?");
                        $stmt->execute([$_SESSION['user_id'], $fileName, $fileType, $fileUrl, $desc, $tugas_id, $_POST['edit_id']]);
                        $_SESSION['success'] = "File updated successfully.";
                    } else {
                        // Insert new file
                        $stmt = $pdo->prepare("INSERT INTO uploads (user_id, file_name, file_type, file_url, description, tugas_id, uploaded_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                        $stmt->execute([$_SESSION['user_id'], $fileName, $fileType, $fileUrl, $desc, $tugas_id]);
                        $_SESSION['success'] = "File uploaded successfully.";
                    }
                    header("Location: upload.php");
                    exit;
                }
            }
        } else {
            $error = "Task not found.";
        }
    }

    // Handle edit (populate form fields)
    if (isset($_GET['edit'])) {
        $file_id = $_GET['edit'];
        $stmt = $pdo->prepare("SELECT * FROM uploads WHERE id = ? AND user_id = ?");
        $stmt->execute([$file_id, $_SESSION['user_id']]);
        $file = $stmt->fetch();

        if ($file) {
            $editFileName = $file['file_name'];
            $editFileType = $file['file_type'];
            $editDescription = $file['description'];
            $editTugasId = $file['tugas_id'];
        } else {
            $error = "File not found or unauthorized.";
        }
    }

    // Handle delete
    if (isset($_GET['delete'])) {
        $file_id = $_GET['delete'];
        // Get file details to delete from the server
        $stmt = $pdo->prepare("SELECT file_url FROM uploads WHERE id = ? AND user_id = ?");
        $stmt->execute([$file_id, $_SESSION['user_id']]);
        $file = $stmt->fetch();

        if ($file) {
            // Delete the file from server
            $filePath = '../' . $file['file_url'];  // Full path to the file
            if (file_exists($filePath)) {
                if (unlink($filePath)) {  // If file is deleted from the server
                    // Delete from the database
                    $stmt = $pdo->prepare("DELETE FROM uploads WHERE id = ?");
                    $stmt->execute([$file_id]);
                    $_SESSION['success'] = "File deleted successfully.";
                } else {
                    $error = "Failed to delete the file from the server.";
                }
            } else {
                $error = "File not found.";
            }
        } else {
            $error = "File not found or unauthorized.";
        }

        // Redirect after delete
        if ($error) {
            $_SESSION['error'] = $error;
        }
        header("Location: upload.php");  // Redirect back to the upload page
        exit;
    }
}

// Fetch list of tasks for mahasiswa to select when uploading
$stmt = $pdo->prepare("SELECT id, judul FROM tugas WHERE kelas_id IN (SELECT kelas_id FROM kelas_mahasiswa WHERE mahasiswa_id = ?)");
$stmt->execute([$_SESSION['user_id']]);
$tugasList = $stmt->fetchAll();

// Fetch all uploads for viewing (Including task name)
$stmt = $pdo->prepare("SELECT u.*, us.name, t.judul AS tugas_nama FROM uploads u 
                       JOIN users us ON u.user_id = us.id 
                       JOIN tugas t ON u.tugas_id = t.id 
                       ORDER BY u.uploaded_at DESC");
$stmt->execute();
$uploads = $stmt->fetchAll();

// For filtering uploads by class
$kelas_id = $_GET['kelas_id'] ?? null;
if ($kelas_id) {
    $stmt = $pdo->prepare("SELECT u.*, us.name, t.judul AS tugas_nama FROM uploads u 
                           JOIN users us ON u.user_id = us.id 
                           JOIN tugas t ON u.tugas_id = t.id 
                           WHERE t.kelas_id = ? 
                           ORDER BY u.uploaded_at DESC");
    $stmt->execute([$kelas_id]);
    $uploads = $stmt->fetchAll();
}

$success = $_SESSION['success'] ?? '';
unset($_SESSION['success']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Upload Assignment | Dashboard <?= ucfirst($role) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/upload.css" />
</head>
<body>

<div class="container py-4">
    <h2 class="mb-4">Upload Assignment</h2>

    <?php if ($role === 'mahasiswa'): ?>
        <!-- Mahasiswa upload form -->
        <form method="POST" enctype="multipart/form-data" class="mb-4" novalidate>

            <div class="mb-3" id="file_input_group">
                <label for="upload_file" class="form-label">Select File (PDF only)</label>
                <input type="file" id="upload_file" name="upload_file" class="form-control" value="<?= htmlspecialchars($editFileName ?? '') ?>" />
                <div class="form-text">Only PDF files are allowed. Max size: 20MB.</div>
                <div id="previewContainer" class="mt-3"></div>
            </div>

            <div class="mb-3">
                <label for="tugas_id" class="form-label">Select Task</label>
                <select name="tugas_id" id="tugas_id" class="form-control" required>
                    <option value="">-- Select Task --</option>
                    <?php foreach ($tugasList as $tugas): ?>
                        <option value="<?= $tugas['id'] ?>" <?= isset($editTugasId) && $editTugasId == $tugas['id'] ? 'selected' : '' ?>><?= htmlspecialchars($tugas['judul']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description (optional)</label>
                <textarea id="description" name="description" rows="3" class="form-control" placeholder="File description..."><?= htmlspecialchars($editDescription ?? '') ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary"><?= isset($editFileName) ? 'Update' : 'Upload' ?></button>

            <?php if (isset($editFileName)): ?>
                <a href="upload.php" class="btn btn-secondary">Cancel</a>
            <?php endif; ?>
        </form>
    <?php elseif ($role === 'dosen'): ?>
        <p class="alert alert-info">As a lecturer, you can only view and grade assignments uploaded by students.</p>
        
        <form method="GET" class="mb-3">
            <label for="kelas_id" class="form-label">Filter by Class</label>
            <select name="kelas_id" id="kelas_id" class="form-control" onchange="this.form.submit()">
                <option value="0" <?= $kelas_id === 0 ? 'selected' : '' ?>>All Classes</option>
                <?php foreach ($kelasList as $kelas): ?>
                    <option value="<?= $kelas['id'] ?>" <?= $kelas_id === (int)$kelas['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($kelas['nama_kelas']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    <?php endif; ?>

    <h3>Uploaded Files</h3>
    <?php if (!$uploads): ?>
        <p class="text-muted">No files uploaded yet.</p>
    <?php else: ?>
        <table class="table table-striped align-middle">
            <thead>
                <tr>
                    <th>File Name</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Uploader</th>
                    <th>Task Name</th>
                    <th>Upload Date</th>
                    <th>Preview / Link</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($uploads as $upload): ?>
                    <tr>
                        <td><?= htmlspecialchars($upload['file_name']) ?></td>
                        <td><?= strtoupper(htmlspecialchars($upload['file_type'])) ?></td>
                        <td><?= nl2br(htmlspecialchars($upload['description'])) ?></td>
                        <td><?= htmlspecialchars($upload['name']) ?></td>
                        <td><?= htmlspecialchars($upload['tugas_nama']) ?></td>
                        <td><?= date('d M Y H:i', strtotime($upload['uploaded_at'])) ?></td>
                        <td>
                            <?php 
                            $url = htmlspecialchars($upload['file_url']);
                            $ext = strtolower(pathinfo($upload['file_url'], PATHINFO_EXTENSION));
                            if (in_array($ext, ['jpg','jpeg','png','gif'])): ?>
                                <img src="../<?= $url ?>" alt="Preview" style="max-width:100px; max-height:70px; border-radius:5px;" />
                            <?php elseif ($ext === 'pdf'): ?>
                                <a href="../<?= $url ?>" target="_blank" class="btn btn-sm btn-outline-primary">View PDF</a>
                            <?php elseif ($ext === 'mp4'): ?>
                                <video width="160" height="90" controls>
                                    <source src="../<?= $url ?>" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            <?php else: ?>
                                <a href="../<?= $url ?>" target="_blank" class="btn btn-sm btn-outline-secondary">Download</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($role === 'mahasiswa'): ?>
                                <a href="upload.php?edit=<?= $upload['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="upload.php?delete=<?= $upload['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this file?')">Delete</a>
                            <?php elseif ($role === 'dosen'): ?>
                                <a href="nilai.php?id=<?= $upload['id'] ?>" class="btn btn-sm btn-success">Nilai</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// JavaScript to toggle between file upload and URL upload
const uploadFileRadio = document.getElementById('upload_file_radio');
const uploadUrlRadio = document.getElementById('upload_url_radio');
const fileInputGroup = document.getElementById('file_input_group');
const urlInputGroup = document.getElementById('url_input_group');
const fileInput = document.getElementById('upload_file');
const urlInput = document.getElementById('file_url');
const previewContainer = document.getElementById('previewContainer');
const urlPreview = document.getElementById('urlPreview');

function toggleUploadMethod() {
    if (uploadFileRadio.checked) {
        fileInputGroup.classList.remove('d-none');
        urlInputGroup.classList.add('d-none');
        urlPreview.innerHTML = '';
    } else {
        fileInputGroup.classList.add('d-none');
        urlInputGroup.classList.remove('d-none');
        previewContainer.innerHTML = '';
    }
}

function previewFile() {
    previewContainer.innerHTML = '';
    const file = fileInput.files[0];
    if (!file) return;

    const fileType = file.type;

    if (fileType.startsWith('image/')) {
        const img = document.createElement('img');
        img.style.maxWidth = '200px';
        img.style.borderRadius = '5px';
        img.src = URL.createObjectURL(file);
        previewContainer.appendChild(img);
    } else if (fileType === 'application/pdf') {
        const embed = document.createElement('embed');
        embed.type = 'application/pdf';
        embed.width = '100%';
        embed.height = '400px';
        embed.src = URL.createObjectURL(file);
        previewContainer.appendChild(embed);
    } else if (fileType.startsWith('video/')) {
        const video = document.createElement('video');
        video.controls = true;
        video.width = 320;
        video.height = 180;
        const source = document.createElement('source');
        source.src = URL.createObjectURL(file);
        source.type = fileType;
        video.appendChild(source);
        previewContainer.appendChild(video);
    } else {
        const p = document.createElement('p');
        p.textContent = 'Preview not available for this file type.';
        previewContainer.appendChild(p);
    }
}

function previewUrl() {
    urlPreview.innerHTML = '';
    const url = urlInput.value.trim();
    if (!url) return;

    const lowerUrl = url.toLowerCase();

    if (lowerUrl.endsWith('.json')) {
        urlPreview.innerHTML = `<lottie-player src="${url}" background="transparent" speed="1" loop autoplay style="width:150px; height:150px;"></lottie-player>`;
    } else if (/\.(png|jpg|jpeg|gif)$/i.test(lowerUrl)) {
        urlPreview.innerHTML = `<img src="${url}" alt="Preview URL" style="max-width:150px; max-height:150px; border-radius:8px;" />`;
    } else if (/\.(mp4)$/i.test(lowerUrl)) {
        urlPreview.innerHTML = `<video width="200" controls><source src="${url}" type="video/mp4">Your browser does not support the video tag.</video>`;
    } else if (url.includes('youtube.com') || url.includes('youtu.be')) {
        let embedUrl = url;
        if (url.includes('watch?v=')) {
            embedUrl = url.replace('watch?v=', 'embed/');
        }
        urlPreview.innerHTML = `<iframe width="250" height="150" src="${embedUrl}" frameborder="0" allowfullscreen></iframe>`;
    } else {
        urlPreview.innerHTML = `<small style="color:#888;">Unable to display preview for this URL.</small>`;
    }
}

uploadFileRadio.addEventListener('change', toggleUploadMethod);
uploadUrlRadio.addEventListener('change', toggleUploadMethod);
fileInput.addEventListener('change', previewFile);
urlInput.addEventListener('input', previewUrl);

toggleUploadMethod();
</script>
</body>
</html>