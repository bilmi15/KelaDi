<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Cek session login valid dan role sesuai
if (
    !isset($_SESSION['user_id'], $_SESSION['role'], $_SESSION['name'], $_SESSION['username'])
    || !in_array($_SESSION['role'], ['dosen', 'mahasiswa'])
) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$name = $_SESSION['name'];
$username = $_SESSION['username'];
$base_url = '/e-learning/';

require_once '../includes/config.php';

// Cek apakah kolom sender_role ada di tabel notifications
$hasSenderRoleColumn = false;
try {
    $res = $pdo->query("SHOW COLUMNS FROM notifications LIKE 'sender_role'")->fetch();
    if ($res) {
        $hasSenderRoleColumn = true;
    }
} catch (Exception $e) {
    // jika query gagal, anggap kolom tidak ada
    $hasSenderRoleColumn = false;
}

// Query jumlah notifikasi belum dibaca berdasarkan role dan adanya sender_role
try {
    if ($role === 'dosen') {
        $stmtNotif = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmtNotif->execute([$user_id]);
    } else {
        if ($hasSenderRoleColumn) {
            $stmtNotif = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0 AND sender_role = 'dosen'");
            $stmtNotif->execute([$user_id]);
        } else {
            $stmtNotif = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
            $stmtNotif->execute([$user_id]);
        }
    }
    $unreadCount = $stmtNotif->fetchColumn();
} catch (Exception $e) {
    $unreadCount = 0;
}
?>

<!DOCTYPE html>
<html lang="id" class="no-js" dir="ltr">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Dashboard <?= ucfirst(htmlspecialchars($role)) ?> - KelaDi</title>

<!-- Google Fonts Nunito -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />

<!-- HF CSS -->
<link rel="stylesheet" href="../assets/css/hefo.css" />

</head>
<body>

<header class="main-header" role="banner" aria-label="Header website">
  <a href="<?= $base_url ?>index.php" class="branding" aria-label="Beranda KelaDi" tabindex="0">
    <img src="<?= $base_url ?>assets/images/logokeladi.png" alt="Logo KelaDi" />
    <span class="tagline">Belajar Modern, Mudah, dan Menyenangkan</span>
  </a>

  <?php if ($username): ?>
  <div style="display:flex; align-items:center; gap:1rem;">
    <!-- Icon Notifikasi -->
    <div class="notification-icon" id="notificationToggle" title="Notifikasi" tabindex="0" role="button" aria-pressed="false" aria-label="Toggle notifikasi" aria-live="polite" aria-atomic="true" aria-relevant="additions">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"></path>
        <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
      </svg>
      <?php if ($unreadCount > 0): ?>
        <span class="notification-badge" id="notifBadge"><?= $unreadCount ?></span>
      <?php endif; ?>
    </div>

    <!-- User Dropdown -->
    <div class="user-dropdown" tabindex="0" aria-haspopup="true" aria-expanded="false" aria-label="User menu">
      <button class="user-name" aria-haspopup="true" aria-expanded="false" aria-label="Toggle user menu" id="user-menu-button" aria-controls="user-menu-list" aria-describedby="user-menu-desc">
        <!-- Desktop: Tampilkan nama lengkap, Mobile: username -->
        <span class="user-fullname d-none d-md-inline"><?= htmlspecialchars($name) ?></span>
        <span class="user-username d-inline d-md-none">(<?= htmlspecialchars($username) ?>)</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
          <polyline points="6 9 12 15 18 9"></polyline>
        </svg>
      </button>
      <div class="dropdown-menu" role="menu" aria-labelledby="user-menu-button" id="user-menu-list" aria-live="polite" aria-relevant="additions" hidden>
        <?php if ($role === 'dosen'): ?>
          <a href="<?= $base_url ?>pages/dashboard.php" class="dropdown-item" role="menuitem" tabindex="-1">Dashboard</a>
        <?php else: ?>
          <a href="<?= $base_url ?>pages/dashboard.php" class="dropdown-item" role="menuitem" tabindex="-1">Dashboard</a>
        <?php endif; ?>
        <form action="<?= $base_url ?>pages/logout.php" method="POST" class="m-0" role="none">
          <button type="submit" class="dropdown-item" role="menuitem" tabindex="-1">Logout</button>
        </form>
      </div>
    </div>
  </div>
  <?php else: ?>
    <button class="btn-login" onclick="window.location.href='<?= $base_url ?>pages/login.php';" aria-label="Login">Login</button>
  <?php endif; ?>
</header>

<script>
document.addEventListener('DOMContentLoaded', () => {
  // Toggle dropdown menu user
  const userDropdown = document.querySelector('.user-dropdown');
  if (userDropdown) {
    const userBtn = userDropdown.querySelector('.user-name');
    const dropdownMenu = userDropdown.querySelector('.dropdown-menu');
    dropdownMenu.hidden = true;
    userBtn.setAttribute('aria-expanded', 'false');

    userBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const isShown = userDropdown.classList.toggle('show');
      dropdownMenu.hidden = !isShown;
      userBtn.setAttribute('aria-expanded', isShown);
    });

    document.addEventListener('click', (e) => {
      if (!userDropdown.contains(e.target)) {
        userDropdown.classList.remove('show');
        dropdownMenu.hidden = true;
        userBtn.setAttribute('aria-expanded', 'false');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && userDropdown.classList.contains('show')) {
        userDropdown.classList.remove('show');
        dropdownMenu.hidden = true;
        userBtn.setAttribute('aria-expanded', 'false');
        userBtn.focus();
      }
    });
  }

  // Klik icon notifikasi buka halaman notifikasi
  const notifToggle = document.getElementById('notificationToggle');
  if (notifToggle) {
    notifToggle.addEventListener('click', () => {
      // Cek apakah iframe dashboard ada (misal parent window)
      const iframe = parent.document.getElementById('dashboardIframe');
      if (iframe) {
        iframe.src = '<?= $base_url ?>pages/notification.php';
      } else {
        window.location.href = '<?= $base_url ?>pages/notification.php';
      }
    });
  }
});
</script>

</body>
</html>