<?php
session_start();
require_once '../includes/config.php';

// Cek login dan role
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['dosen', 'mahasiswa'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);

// Ambil notifikasi sesuai role
try {
    if ($role === 'dosen') {
        // Dosen dapat semua notifikasi yang ditujukan ke user dosen (baik dari dosen atau user)
        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$user_id]);
    } else {
        // Mahasiswa dapat notifikasi dari dosen dan user (jika kolom sender_role ada)
        // Cek apakah kolom sender_role ada di tabel notifications
        $hasSenderRoleColumn = false;
        $res = $pdo->query("SHOW COLUMNS FROM notifications LIKE 'sender_role'")->fetch();
        if ($res) {
            $hasSenderRoleColumn = true;
        }

        if ($hasSenderRoleColumn) {
            // Jika kolom sender_role ada, hanya ambil notifikasi dari dosen atau user
            $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? AND (sender_role = 'dosen' OR sender_role IS NULL) ORDER BY created_at DESC");
            $stmt->execute([$user_id]);
        } else {
            // Jika tidak ada kolom sender_role, ambil semua notifikasi user_id mahasiswa
            $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$user_id]);
        }
    }
    $notifications = $stmt->fetchAll();
} catch (Exception $e) {
    $error = "Gagal mengambil notifikasi: " . $e->getMessage();
    $notifications = [];
}

// Proses POST (tandai baca/hapus)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['mark_read'])) {
            $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $_SESSION['success'] = "Semua notifikasi telah ditandai sebagai sudah dibaca.";
            header("Location: notification.php");
            exit;
        }
        if (isset($_POST['delete_notification'])) {
            $deleteId = $_POST['delete_notification'];
            $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
            $stmt->execute([$deleteId, $user_id]);
            $_SESSION['success'] = "Notifikasi berhasil dihapus.";
            header("Location: notification.php");
            exit;
        }
        if (isset($_POST['mark_unread'])) {
            $unreadId = $_POST['mark_unread'];
            $stmt = $pdo->prepare("UPDATE notifications SET is_read = 0 WHERE id = ? AND user_id = ?");
            $stmt->execute([$unreadId, $user_id]);
            $_SESSION['success'] = "Notifikasi berhasil ditandai sebagai belum dibaca.";
            header("Location: notification.php");
            exit;
        }
    } catch (Exception $e) {
        $_SESSION['error'] = "Terjadi kesalahan: " . $e->getMessage();
        header("Location: notification.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Notifikasi | Dashboard <?= ucfirst($role) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/notification.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<main class="container mt-4">
    <h2>Daftar Notifikasi</h2>

    <div class="d-flex justify-content-between mb-3">
        <!-- Kembali button always visible -->
        <a href="dashboard.php" class="btn btn-secondary btn-sm">Kembali</a>
        <?php if (count($notifications) > 0): ?>
            <!-- Only show the "Tandai Semua Dibaca" button if there are notifications -->
            <form method="POST" class="mb-0">
                <button type="submit" name="mark_read" class="btn btn-primary btn-sm">Tandai Semua Dibaca</button>
            </form>
        <?php endif; ?>
    </div>

    <?php if (count($notifications) === 0): ?>
        <p class="text-center mt-5 text-muted">Belum ada notifikasi.</p>
    <?php else: ?>
        <ul class="list-group notification-list">
            <?php foreach ($notifications as $notif): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center <?= $notif['is_read'] ? 'read' : 'unread' ?>">
                    <div class="notification-message">
                        <strong><?= htmlspecialchars($notif['judul']) ?></strong>
                        <?php if (!empty($notif['url'])): ?>
                            <a href="view_notification.php?id=<?= $notif['id'] ?>" class="ms-2 notification-link">Lihat</a>
                        <?php endif; ?>
                    </div>
                    <div class="notification-date">
                        <?= date('d M Y H:i', strtotime($notif['created_at'])) ?>
                    </div>
                    <div class="notification-actions">
                        <?php if ($notif['is_read']): ?>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="mark_unread" value="<?= $notif['id'] ?>" />
                                <button type="submit" class="btn btn-warning btn-sm">Tandai Belum Dibaca</button>
                            </form>
                        <?php endif; ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="delete_notification" value="<?= $notif['id'] ?>" />
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus notifikasi ini?');">Hapus</button>
                        </form>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</main>

<?php if ($success): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Sukses',
    text: <?= json_encode($success) ?>,
    timer: 2500,
    timerProgressBar: true,
    showConfirmButton: false
});
</script>
<?php endif; ?>

<?php if ($error): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: <?= json_encode($error) ?>,
    showConfirmButton: true
});
</script>
<?php endif; ?>

</body>
</html>