<?php
session_start();
require_once '../includes/config.php';

// Pastikan pengguna sudah login dan memiliki role 'dosen'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Pastikan ada parameter mahasiswa_id yang diterima
if (isset($_GET['id'])) {
    $mahasiswa_id = intval($_GET['id']);  // Sanitize input by casting to an integer

    // Cek apakah mahasiswa ada di kelas yang dikelola oleh dosen ini
    $stmt = $pdo->prepare("SELECT km.id, u.name 
                           FROM kelas_mahasiswa km 
                           JOIN users u ON u.id = km.mahasiswa_id
                           WHERE km.mahasiswa_id = ? AND km.kelas_id IN (SELECT id FROM kelas WHERE user_id = ?)");
    $stmt->execute([$mahasiswa_id, $user_id]);

    // Jika mahasiswa ditemukan di kelas yang dikelola oleh dosen
    if ($stmt->rowCount() > 0) {
        // Hapus mahasiswa dari kelas_mahasiswa
        $stmt = $pdo->prepare("DELETE FROM kelas_mahasiswa WHERE mahasiswa_id = ? AND kelas_id IN (SELECT id FROM kelas WHERE user_id = ?)");
        $stmt->execute([$mahasiswa_id, $user_id]);

        // Ambil nama mahasiswa yang dikeluarkan
        $mahasiswa = $pdo->prepare("SELECT name FROM users WHERE id = ?");
        $mahasiswa->execute([$mahasiswa_id]);
        $mahasiswa_name = $mahasiswa->fetchColumn();

        // Kirim notifikasi ke dosen jika berhasil menghapus mahasiswa
        addNotification($pdo, $user_id, "Mahasiswa Dikeluarkan", "Mahasiswa \"$mahasiswa_name\" telah dikeluarkan dari kelas Anda.", "jumlah_mahasiswa.php");

        $_SESSION['success'] = "Mahasiswa berhasil dihapus dari kelas.";
    } else {
        $_SESSION['error'] = "Mahasiswa tidak terdaftar di kelas ini.";
    }
    header("Location: jumlah_mahasiswa.php");
    exit;
} else {
    $_SESSION['error'] = "ID mahasiswa tidak ditemukan.";
    header("Location: jumlah_mahasiswa.php");
    exit;
}

// Fungsi untuk menambahkan notifikasi
function addNotification($pdo, $user_id, $judul, $message, $url = null) {
    $sql = "INSERT INTO notifications (user_id, judul, message, url, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $judul, $message, $url]);
}
?>