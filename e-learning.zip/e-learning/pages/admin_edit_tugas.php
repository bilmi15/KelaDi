<?php
session_start();
require_once '../includes/config.php';

// Fungsi tambah notifikasi
function addNotification($pdo, $user_id, $judul, $message, $url = null) {
    $sql = "INSERT INTO notifications (user_id, judul, message, url, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $judul, $message, $url]);
}

// Cek login & role dosen
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: tugas.php");
    exit;
}

$id = (int)$_GET['id'];
$error = '';
$success = '';
$user_id = $_SESSION['user_id'];

// Ambil daftar kelas untuk dropdown
$stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
$kelas_list = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kelas_id = $_POST['kelas_id'] ?? '';
    $judul = trim($_POST['judul'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $deadline = $_POST['deadline'] ?? '';

    if (empty($kelas_id) || empty($judul) || empty($deadline)) {
        $error = "Semua kolom wajib diisi kecuali deskripsi.";
    } else {
        $stmt = $pdo->prepare("UPDATE tugas SET kelas_id = ?, judul = ?, deskripsi = ?, deadline = ? WHERE id = ?");
        $stmt->execute([$kelas_id, $judul, $deskripsi, $deadline, $id]);

        // Tambah notifikasi update tugas
        addNotification($pdo, $user_id, "Tugas Diperbarui", "Tugas berhasil diperbarui: $judul", "tugas.php");

        $_SESSION['success_message'] = "Tugas berhasil diperbarui.";

        // Redirect ke halaman yang sama untuk menghindari resubmission
        header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $id);
        exit;
    }
}

// Setelah redirect, ambil pesan sukses jika ada
if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

// Ambil data tugas sesuai kondisi
if ($success) {
    $tugas = ['kelas_id' => '', 'judul' => '', 'deskripsi' => '', 'deadline' => ''];
} else {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        $stmt = $pdo->prepare("SELECT * FROM tugas WHERE id = ?");
        $stmt->execute([$id]);
        $tugas = $stmt->fetch();
    } else {
        $tugas = [
            'kelas_id' => $_POST['kelas_id'] ?? '',
            'judul' => $_POST['judul'] ?? '',
            'deskripsi' => $_POST['deskripsi'] ?? '',
            'deadline' => $_POST['deadline'] ?? ''
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Tugas | Dashboard Dosen</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/dashboard_dosen.css" />
    <link rel="stylesheet" href="../assets/css/admin_edit_tugas.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<main class="container mt-4" style="padding-bottom: 60px;">
  <h2>Edit Tugas</h2>

  <form method="post" action="" novalidate>
    <div class="mb-3">
      <label for="kelas_id" class="form-label">Pilih Kelas</label>
      <select id="kelas_id" name="kelas_id" class="form-select" required>
        <option value="">-- Pilih Kelas --</option>
        <?php foreach ($kelas_list as $kelas): ?>
          <option value="<?= htmlspecialchars($kelas['id']) ?>" <?= ($tugas['kelas_id'] == $kelas['id']) ? 'selected' : '' ?>>
            <?= htmlspecialchars($kelas['nama_kelas']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label for="judul" class="form-label">Judul Tugas</label>
      <input type="text" id="judul" name="judul" class="form-control" required value="<?= htmlspecialchars($tugas['judul']) ?>" />
    </div>

    <div class="mb-3">
      <label for="deskripsi" class="form-label">Deskripsi</label>
      <textarea id="deskripsi" name="deskripsi" class="form-control" rows="4"><?= htmlspecialchars($tugas['deskripsi']) ?></textarea>
    </div>

    <div class="mb-3">
      <label for="deadline" class="form-label">Deadline</label>
      <input type="datetime-local" id="deadline" name="deadline" class="form-control" required value="<?= htmlspecialchars(date('Y-m-d\TH:i', strtotime($tugas['deadline'] ?? ''))) ?>" />
    </div>

    <button type="submit" class="btn btn-primary">Perbarui Tugas</button>
    <a href="tugas.php" class="btn btn-secondary">Kembali</a>
  </form>
</main>

<?php if ($success): ?>
<script>
Swal.fire({
  icon: 'success',
  title: 'Sukses',
  text: <?= json_encode($success) ?>,
  timer: 3000,
  showConfirmButton: false
});
</script>
<?php endif; ?>

<?php if ($error): ?>
<script>
Swal.fire({
  icon: 'error',
  title: 'Error',
  text: <?= json_encode($error) ?>,
  timer: 4000,
  showConfirmButton: true
});
</script>
<?php endif; ?>

</body>
</html>