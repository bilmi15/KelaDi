<?php
session_start();
require_once '../includes/config.php';

// Generate CSRF token jika belum ada
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';
$successMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Token keamanan tidak valid. Silakan coba lagi.";
    } else {
        $username = trim($_POST['username']);
        $namaLengkap = trim($_POST['nama_lengkap']);
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        $role = isset($_POST['role']) && in_array($_POST['role'], ['dosen', 'mahasiswa']) ? $_POST['role'] : 'mahasiswa'; // default mahasiswa

        if (strlen($username) < 3) {
            $error = "Username minimal 3 karakter.";
        } elseif (strlen($namaLengkap) < 3) {
            $error = "Nama lengkap wajib diisi minimal 3 karakter.";
        } elseif (strlen($password) < 6) {
            $error = "Password minimal 6 karakter.";
        } elseif ($password !== $confirmPassword) {
            $error = "Password dan konfirmasi password tidak cocok.";
        } else {
            // Cek apakah username sudah ada di database
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user) {
                $error = "Username sudah digunakan.";
            } else {
                // Hash password dan simpan di database dengan is_approved = 0 (pending)
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, name, password, role, is_approved) VALUES (?, ?, ?, ?, 0)");
                $stmt->execute([$username, $namaLengkap, $hashedPassword, $role]);

                $successMessage = "Registrasi berhasil. Silakan tunggu persetujuan admin sebelum login.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Daftar - KelaDi</title>

  <!-- Google Fonts Nunito -->
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

  <!-- SweetAlert2 -->
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet" />

  <!-- Lottie Player -->
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

  <!-- tsParticles -->
  <script src="https://cdn.jsdelivr.net/npm/tsparticles@2.11.1/tsparticles.bundle.min.js"></script>

  <!-- Custom CSS -->
  <link href="../assets/css/registed.css" rel="stylesheet" />
</head>
<body>

<div id="tsparticles" class="tsparticles-bg"></div>

<div class="register-wrapper">

  <div class="left-panel">
    <!-- Lottie animasi register -->
    <lottie-player
      src="https://assets2.lottiefiles.com/packages/lf20_jcikwtux.json"
      background="transparent"
      speed="1"
      loop autoplay
      style="width: 100%; max-width: 500px;"
    ></lottie-player>
  </div>

  <div class="right-panel">
    <h3 class="register-title">Daftar Akun</h3>

    <form method="post" action="" novalidate class="register-form">

      <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

      <!-- Username input with icon -->
      <div class="mb-3 input-with-icon">
        <label for="username" class="form-label">Username</label>
        <span class="icon-left">
          <img src="../assets/images/user.png" alt="Username Icon" class="icon" />
        </span>
        <input
          type="text"
          id="username"
          name="username"
          class="form-control"
          required minlength="3"
          value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
          aria-describedby="usernameHelp"
        />
        <div id="usernameHelp" class="form-text">Minimal 3 karakter.</div>
      </div>

      <!-- Nama lengkap input with icon -->
      <div class="mb-3 input-with-icon">
        <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
        <span class="icon-left">
          <img src="../assets/images/id-card.png" alt="Nama Lengkap Icon" class="icon" />
        </span>
        <input
          type="text"
          id="nama_lengkap"
          name="nama_lengkap"
          class="form-control"
          required minlength="3"
          value="<?= htmlspecialchars($_POST['nama_lengkap'] ?? '') ?>"
          aria-describedby="namaLengkapHelp"
        />
        <div id="namaLengkapHelp" class="form-text">Wajib diisi minimal 3 karakter.</div>
      </div>

      <!-- Password input with icon and toggle -->
      <div class="mb-3 position-relative input-with-icon">
        <label for="password" class="form-label">Password</label>
        <span class="icon-left">
          <img src="../assets/images/locked.png" alt="Password Icon" class="icon" />
        </span>
        <input
          type="password"
          id="password"
          name="password"
          class="form-control"
          required minlength="6"
          aria-describedby="passwordHelp"
        />
        <button
          type="button"
          class="password-toggle-btn1"
          onclick="togglePassword('password', this)"
          aria-label="Toggle password visibility"
        >
          <!-- Ikon mata tertutup default -->
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
            <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
            <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
            <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
            <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
          </svg>
        </button>
        <div id="passwordHelp" class="form-text">Minimal 6 karakter.</div>
      </div>

      <!-- Confirm password input with icon and toggle -->
      <div class="mb-3 position-relative input-with-icon">
        <label for="confirm_password" class="form-label">Konfirmasi Password</label>
        <span class="icon-left1">
          <img src="../assets/images/locked.png" alt="Confirm Password Icon" class="icon" />
        </span>
        <input
          type="password"
          id="confirm_password"
          name="confirm_password"
          class="form-control"
          required
          aria-describedby="confirmPasswordHelp"
        />
        <button
          type="button"
          class="password-toggle-btn2"
          onclick="togglePassword('confirm_password', this)"
          aria-label="Toggle password visibility"
        >
          <!-- Ikon mata tertutup default -->
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
            <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
            <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
            <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
            <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
          </svg>
        </button>
      </div>

      <!-- Role selection -->
      <div class="mb-3">
        <label for="role" class="form-label">Pilih Role</label>
        <select id="role" name="role" class="form-select" required>
          <option value="mahasiswa" <?= (($_POST['role'] ?? '') === 'mahasiswa') ? 'selected' : '' ?>>Mahasiswa (User)</option>
          <option value="dosen" <?= (($_POST['role'] ?? '') === 'dosen') ? 'selected' : '' ?>>Dosen (Admin)</option>
        </select>
      </div>

      <button type="submit" class="btn btn-primary w-100">Daftar</button>

    </form>

    <p class="text-center mt-3">Sudah punya akun? <a href="login.php">Masuk di sini</a></p>
  </div>
</div>

<script src="../assets/js/register.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  tsParticles.load("tsparticles", {
    fpsLimit: 60,
    background: {
      color: "#f0f4f8",
    },
    particles: {
      number: {
        value: 50,
        density: { enable: true, area: 800 },
      },
      color: { value: "#6a11cb" },
      shape: { type: "circle" },
      opacity: { value: 0.3 },
      size: { value: { min: 1, max: 3 } },
      move: {
        enable: true,
        speed: 2,
        direction: "none",
        outMode: "bounce",
      },
    },
    interactivity: {
      events: {
        onHover: { enable: true, mode: "repulse" },
        onClick: { enable: true, mode: "push" },
      },
      modes: {
        repulse: { distance: 100, duration: 0.4 },
        push: { quantity: 4 },
      },
    },
    detectRetina: true,
  });

  <?php if ($error): ?>
    Swal.fire({
      icon: 'error',
      title: 'Kesalahan',
      text: '<?= addslashes($error) ?>',
    });
  <?php endif; ?>

  <?php if ($successMessage): ?>
    Swal.fire({
      icon: 'success',
      title: 'Sukses',
      text: '<?= addslashes($successMessage) ?>',
    }).then(() => {
      window.location.href = 'login.php';
    });
  <?php endif; ?>

  // Toggle password visibility function
  function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
      input.type = "text";
      btn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" 
             stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
          <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
          <path d="M12 32 Q32 12 52 32" stroke="#333" stroke-width="4" fill="none"/>
          <path d="M12 32 Q32 52 52 32" stroke="#333" stroke-width="4" fill="none"/>
          <circle cx="32" cy="32" r="14" fill="#fff" stroke="#333" stroke-width="3"/>
          <circle cx="32" cy="32" r="9" fill="#555"/>
          <circle cx="32" cy="32" r="5" fill="#000"/>
          <circle cx="26" cy="26" r="2.5" fill="#bbb" opacity="0.7"/>
        </svg>
      `;
    } else {
      input.type = "password";
      btn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" 
             stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
          <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
          <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
          <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
          <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
        </svg>
      `;
    }
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>