<?php
require_once '../includes/config.php';

// Ambil ID absensi dari URL
$id = $_GET['id'] ?? null;

if ($id) {
    // Proses hapus absensi berdasarkan ID
    $stmt = $pdo->prepare("DELETE FROM absensi WHERE id = ?");
    $stmt->execute([$id]);

    $_SESSION['success'] = "Absensi berhasil dihapus.";
    
    // Redirect kembali ke halaman tambah_absensi_mahasiswa.php tanpa parameter tambahan
    header("Location: tambah_absensi_mahasiswa.php");
    exit;
}
?>