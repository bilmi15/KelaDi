<?php
session_start();
require_once '../includes/config.php';

// Jika user sudah login, langsung redirect ke dashboard sesuai role
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'dosen') {
        header('Location: dashboard_dosen.php');
        exit;
    } elseif ($_SESSION['role'] === 'mahasiswa') {
        header('Location: dashboard_mahasiswa.php');
        exit;
    }
}

// Generate CSRF token jika belum ada
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';
$errorType = '';
$alertType = '';
$alertTitle = '';
$alertText = '';
$successLogin = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Token keamanan tidak valid. Silakan coba lagi.";
    } else {
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        // Validasi panjang input
        if (strlen($username) < 3 || strlen($password) < 6) {
            $error = "Username minimal 3 karakter dan password minimal 6 karakter.";
            $errorType = 'not_contain';
        } else {
            // Ambil data user berdasarkan username
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if (!$user) {
                $error = "Username tidak ditemukan atau belum terdaftar.";
                $errorType = 'not_found';
            } elseif (!password_verify($password, $user['password'])) {
                $error = "Password salah.";
                $errorType = 'wrong_password';
            } elseif ($user['is_approved'] == 0) {
                $error = "Akun Anda belum disetujui oleh administrator.";
                $errorType = 'not_approved';
            } else {
                // Login berhasil, simpan session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['role'] = $user['role'];

                $successLogin = true;
                $alertType = 'success';
                $alertTitle = 'Login Berhasil';
                $alertText = 'Selamat datang, ' . htmlspecialchars($user['name']) . '! Mengalihkan ke dashboard...';

                // Redirect sesuai role
                if ($user['role'] === 'mahasiswa') {
                    $redirectUrl = 'dashboard.php';
                } elseif ($user['role'] === 'dosen') {
                    $redirectUrl = 'dashboard.php';
                } else {
                    $redirectUrl = 'login.php'; // fallback jika role tak dikenali
                }
            }
        }
    }

    if ($error) {
        $alertType = 'error';
        $alertTitle = 'Login Gagal';
        $alertText = $error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Masuk - KelaDi</title>

<!-- Google Fonts Nunito -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

<!-- SweetAlert2 -->
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet" />

<!-- Lottie Player -->
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

<!-- tsParticles -->
<script src="https://cdn.jsdelivr.net/npm/tsparticles@2.11.1/tsparticles.bundle.min.js"></script>

<link href="../assets/css/login.css" rel="stylesheet" />

</head>
<body>

<div id="tsparticles" class="tsparticles-bg"></div>

<div class="login-wrapper">

  <div class="left-panel">
    <lottie-player
      src="https://assets2.lottiefiles.com/packages/lf20_jcikwtux.json"
      background="transparent"
      speed="1"
      loop autoplay
      style="width: 100%; max-width: 500px;"
    ></lottie-player>
  </div>

  <div class="right-panel">
    <h3 class="login-title">Masuk ke Akun</h3>

    <form method="post" action="" novalidate class="login-form">
      <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

      <div class="mb-3 input-with-icon">
        <label for="username" class="form-label">Username</label>
        <span class="icon-left">
          <img src="../assets/images/user.png" alt="Username Icon" class="icon" />
        </span>
        <input
          type="text"
          id="username"
          name="username"
          class="form-control"
          required minlength="3"
          value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
          aria-describedby="usernameHelp"
        />
        <div id="usernameHelp" class="form-text">Minimal 3 karakter.</div>
      </div>

      <div class="input-with-icon position-relative">
        <label for="password" class="form-label">Password</label>
        <span class="icon-left">
          <img src="../assets/images/locked.png" alt="Password Icon" class="icon" />
        </span>
        <input
          type="password"
          id="password"
          name="password"
          class="form-control"
          required minlength="6"
          aria-describedby="passwordHelp"
        />
        <button
          type="button"
          class="password-toggle-btn"
          onclick="togglePassword('password', this)"
          aria-label="Toggle password visibility"
        >
          <!-- Default closed eye icon -->
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor"
            stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
            <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none" />
            <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc" />
            <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc" />
            <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3" />
          </svg>
        </button>
        <div id="passwordHelp" class="form-text">Minimal 6 karakter.</div>
      </div>

      <button type="submit" class="btn btn-primary w-100">Masuk</button>

      <p class="text-center mt-3"><a href="reset_password.php">Lupa Password?</a></p>
    </form>

    <p class="text-center mt-3">Belum punya akun? <a href="register.php">Daftar di sini</a></p>
  </div>

</div>

<script src="../assets/js/login.js"></script>
<script src="../assets/js/particles.js"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if ($errorType === 'not_contain'): ?>
<script>
Swal.fire({
  icon: 'error',
  title: 'Form Tidak Lengkap',
  text: 'Isi minimal 3 karakter untuk Username dan 6 karakter untuk Password. Silakan coba lagi.',
  confirmButtonText: 'OK'
});
</script>
<?php elseif ($errorType === 'not_found'): ?>
<script>
Swal.fire({
  icon: 'error',
  title: 'Username Tidak Ditemukan',
  text: 'Username yang Anda masukkan tidak terdaftar. Silakan cek kembali atau daftar terlebih dahulu.',
  confirmButtonText: 'OK'
});
</script>
<?php elseif ($errorType === 'wrong_password'): ?>
<script>
Swal.fire({
  icon: 'error',
  title: 'Password Salah',
  text: 'Password yang Anda masukkan salah. Silakan coba lagi.',
  confirmButtonText: 'OK'
});
</script>
<?php elseif ($errorType === 'not_approved'): ?>
<script>
Swal.fire({
  icon: 'warning',
  title: 'Akun Belum Disetujui',
  text: 'Akun Anda belum disetujui oleh administrator. Harap hubungi admin.',
  confirmButtonText: 'OK'
});
</script>
<?php elseif ($alertType === 'success'): ?>
<script>
Swal.fire({
  icon: 'success',
  title: '<?= $alertTitle ?>',
  text: '<?= $alertText ?>',
  timer: 3000,
  timerProgressBar: true,
  allowOutsideClick: false,
  didClose: () => {
    window.location.href = '<?= $redirectUrl ?>';
  }
});
</script>
<?php endif; ?>

<script>
  // Toggle password visibility function
  function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
      input.type = "text";
      btn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" 
             stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
          <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
          <path d="M12 32 Q32 12 52 32" stroke="#333" stroke-width="4" fill="none"/>
          <path d="M12 32 Q32 52 52 32" stroke="#333" stroke-width="4" fill="none"/>
          <circle cx="32" cy="32" r="14" fill="#fff" stroke="#333" stroke-width="3"/>
          <circle cx="32" cy="32" r="9" fill="#555"/>
          <circle cx="32" cy="32" r="5" fill="#000"/>
          <circle cx="26" cy="26" r="2.5" fill="#bbb" opacity="0.7"/>
        </svg>
      `;
    } else {
      input.type = "password";
      btn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" 
             stroke-linecap="round" stroke-linejoin="round" width="18" height="18">
          <path d="M12 20 Q32 10 52 20" stroke="#333" stroke-width="4" fill="none"/>
          <path d="M12 32 Q32 22 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
          <path d="M12 32 Q32 42 52 32" stroke="#333" stroke-width="4" fill="#ccc"/>
          <line x1="12" y1="32" x2="52" y2="32" stroke="#333" stroke-width="3"/>
        </svg>
      `;
    }
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>