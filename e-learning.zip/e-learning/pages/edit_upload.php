<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';
$uploadDir = '../uploads/';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: upload.php");
    exit;
}

$id = (int)$_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM uploads WHERE id = ?");
$stmt->execute([$id]);
$upload = $stmt->fetch();

if (!$upload) {
    header("Location: upload.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadMethod = $_POST['upload_method'] ?? 'file';
    $desc = trim($_POST['description'] ?? '');
    $fileUrl = $upload['file_url'];
    $fileName = $upload['file_name'];
    $fileType = $upload['file_type'];

    if ($uploadMethod === 'file') {
        if (isset($_FILES['upload_file']) && $_FILES['upload_file']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['upload_file']['tmp_name'];
            $fileNameNew = basename($_FILES['upload_file']['name']);
            $fileSize = $_FILES['upload_file']['size'];
            $fileExt = strtolower(pathinfo($fileNameNew, PATHINFO_EXTENSION));

            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'mp4', 'json'];
            if (!in_array($fileExt, $allowedExtensions)) {
                $error = "Jenis file tidak diperbolehkan. Hanya: " . implode(', ', $allowedExtensions);
            } elseif ($fileSize > 20 * 1024 * 1024) {
                $error = "Ukuran file maksimal 20MB.";
            } else {
                $newFileName = uniqid('upload_', true) . '.' . $fileExt;
                $destPath = $uploadDir . $newFileName;

                if (move_uploaded_file($fileTmpPath, $destPath)) {
                    if ($upload['file_url'] && !filter_var($upload['file_url'], FILTER_VALIDATE_URL)) {
                        $oldFile = '../' . $upload['file_url'];
                        if (file_exists($oldFile)) unlink($oldFile);
                    }
                    $fileUrl = 'uploads/' . $newFileName;
                    $fileName = $fileNameNew;
                    $fileType = $fileExt;
                } else {
                    $error = "Gagal memindahkan file ke folder upload.";
                }
            }
        }
    } elseif ($uploadMethod === 'url') {
        $url = trim($_POST['file_url'] ?? '');
        if (!$url || !filter_var($url, FILTER_VALIDATE_URL)) {
            $error = "URL tidak valid.";
        } else {
            $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'mp4', 'json'];
            if (!in_array($ext, $allowedExtensions)) {
                $error = "URL file harus berekstensi: " . implode(', ', $allowedExtensions);
            } else {
                if ($upload['file_url'] && !filter_var($upload['file_url'], FILTER_VALIDATE_URL)) {
                    $oldFile = '../' . $upload['file_url'];
                    if (file_exists($oldFile)) unlink($oldFile);
                }
                $fileUrl = $url;
                $fileName = basename(parse_url($url, PHP_URL_PATH));
                $fileType = $ext;
            }
        }
    } else {
        $error = "Metode upload tidak dikenali.";
    }

    if (!$error) {
        $stmt = $pdo->prepare("UPDATE uploads SET file_name = ?, file_type = ?, file_url = ?, description = ?, uploaded_at = NOW() WHERE id = ?");
        $stmt->execute([$fileName, $fileType, $fileUrl, $desc, $id]);
        $_SESSION['success'] = "File berhasil diperbarui.";
        header("Location: upload.php");
        exit;
    }
}

$success = $_SESSION['success'] ?? '';
unset($_SESSION['success']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit Upload | Dashboard Dosen</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="../assets/css/upload_edit.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<div class="container py-4">
    <h2 class="mb-4">Edit Upload File</h2>

    <form method="POST" enctype="multipart/form-data" novalidate>
        <div class="mb-3">
            <label class="form-label">Metode Upload</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="upload_method" id="upload_file_radio" value="file" <?= (!filter_var($upload['file_url'], FILTER_VALIDATE_URL)) ? 'checked' : '' ?>>
                <label class="form-check-label" for="upload_file_radio">Upload File dari Komputer</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="upload_method" id="upload_url_radio" value="url" <?= (filter_var($upload['file_url'], FILTER_VALIDATE_URL)) ? 'checked' : '' ?>>
                <label class="form-check-label" for="upload_url_radio">Upload dari URL</label>
            </div>
        </div>

        <div class="mb-3" id="file_input_group" style="display: none;">
            <label for="upload_file" class="form-label">Pilih File</label>
            <input type="file" id="upload_file" name="upload_file" class="form-control" />
            <div class="form-text">Format file: jpg, jpeg, png, gif, pdf, mp4, json. Maksimal 20MB.</div>
            <div id="previewContainer" class="mt-3"></div>
            <?php if (!filter_var($upload['file_url'], FILTER_VALIDATE_URL)): ?>
                <p>Preview file saat ini:</p>
                <?php 
                $ext = strtolower(pathinfo($upload['file_url'], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                    <img src="../<?= htmlspecialchars($upload['file_url']) ?>" alt="Preview Saat Ini" style="max-width: 200px; border-radius: 5px;">
                <?php elseif ($ext === 'pdf'): ?>
                    <embed src="../<?= htmlspecialchars($upload['file_url']) ?>" type="application/pdf" width="100%" height="400px" />
                <?php elseif ($ext === 'mp4'): ?>
                    <video width="320" height="180" controls>
                        <source src="../<?= htmlspecialchars($upload['file_url']) ?>" type="video/mp4" />
                    </video>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="mb-3" id="url_input_group" style="display: none;">
            <label for="file_url" class="form-label">URL File</label>
            <input type="url" id="file_url" name="file_url" class="form-control" placeholder="Masukkan URL file" value="<?= htmlspecialchars($upload['file_url']) ?>" />
            <div class="form-text">Pastikan URL berakhiran ekstensi yang diizinkan.</div>
            <?php if (filter_var($upload['file_url'], FILTER_VALIDATE_URL)): ?>
                <p>Preview file saat ini:</p>
                <?php
                $ext = strtolower(pathinfo($upload['file_url'], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                    <img src="<?= htmlspecialchars($upload['file_url']) ?>" alt="Preview Saat Ini" style="max-width: 200px; border-radius: 5px;">
                <?php elseif ($ext === 'pdf'): ?>
                    <embed src="<?= htmlspecialchars($upload['file_url']) ?>" type="application/pdf" width="100%" height="400px" />
                <?php elseif ($ext === 'mp4'): ?>
                    <video width="320" height="180" controls>
                        <source src="<?= htmlspecialchars($upload['file_url']) ?>" type="video/mp4" />
                    </video>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Deskripsi (opsional)</label>
            <textarea id="description" name="description" rows="3" class="form-control"><?= htmlspecialchars($upload['description']) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Perbarui Upload</button>
        <a href="upload.php" class="btn btn-secondary ms-2">Batal</a>
    </form>
</div>

<?php if ($success): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Sukses',
    text: <?= json_encode($success) ?>,
    timer: 3000,
    timerProgressBar: true,
    showConfirmButton: false
});
</script>
<?php endif; ?>

<?php if ($error): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: <?= json_encode($error) ?>,
    showConfirmButton: true
});
</script>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const uploadFileRadio = document.getElementById('upload_file_radio');
const uploadUrlRadio = document.getElementById('upload_url_radio');
const fileInputGroup = document.getElementById('file_input_group');
const urlInputGroup = document.getElementById('url_input_group');
const fileInput = document.getElementById('upload_file');
const previewContainer = document.getElementById('previewContainer');
const urlInput = document.getElementById('file_url');

function toggleUploadMethod() {
    if (uploadFileRadio.checked) {
        fileInputGroup.style.display = 'block';
        urlInputGroup.style.display = 'none';
    } else {
        fileInputGroup.style.display = 'none';
        urlInputGroup.style.display = 'block';
    }
}

function previewFile() {
    previewContainer.innerHTML = '';
    const file = fileInput.files[0];
    if (!file) return;

    const fileType = file.type;

    if (fileType.startsWith('image/')) {
        const img = document.createElement('img');
        img.style.maxWidth = '200px';
        img.style.borderRadius = '5px';
        img.src = URL.createObjectURL(file);
        previewContainer.appendChild(img);
    } else if (fileType === 'application/pdf') {
        const embed = document.createElement('embed');
        embed.type = 'application/pdf';
        embed.width = '100%';
        embed.height = '400px';
        embed.src = URL.createObjectURL(file);
        previewContainer.appendChild(embed);
    } else if (fileType.startsWith('video/')) {
        const video = document.createElement('video');
        video.controls = true;
        video.width = 320;
        video.height = 180;
        const source = document.createElement('source');
        source.src = URL.createObjectURL(file);
        source.type = fileType;
        video.appendChild(source);
        previewContainer.appendChild(video);
    } else {
        const p = document.createElement('p');
        p.textContent = 'Preview tidak tersedia untuk jenis file ini.';
        previewContainer.appendChild(p);
    }
}

function previewUrl() {
    const urlPreview = document.getElementById('urlPreview');
    urlPreview.innerHTML = '';
    const url = urlInput.value.trim();
    if (!url) return;

    const lowerUrl = url.toLowerCase();

    if (lowerUrl.endsWith('.json')) {
        urlPreview.innerHTML = `<lottie-player src="${url}" background="transparent" speed="1" loop autoplay style="width:150px; height:150px;"></lottie-player>`;
    } else if (/\.(png|jpg|jpeg|gif)$/i.test(lowerUrl)) {
        urlPreview.innerHTML = `<img src="${url}" alt="Preview URL" style="max-width:150px; max-height:150px; border-radius:8px;" />`;
    } else if (/\.(mp4)$/i.test(lowerUrl)) {
        urlPreview.innerHTML = `<video width="200" controls><source src="${url}" type="video/mp4">Browser tidak mendukung video.</video>`;
    } else if (url.includes('youtube.com') || url.includes('youtu.be')) {
        let embedUrl = url;
        if (url.includes('watch?v=')) {
            embedUrl = url.replace('watch?v=', 'embed/');
        }
        urlPreview.innerHTML = `<iframe width="250" height="150" src="${embedUrl}" frameborder="0" allowfullscreen></iframe>`;
    } else {
        urlPreview.innerHTML = `<small style="color:#888;">Tidak dapat menampilkan preview untuk URL ini.</small>`;
    }
}

uploadFileRadio.addEventListener('change', toggleUploadMethod);
uploadUrlRadio.addEventListener('change', toggleUploadMethod);
fileInput.addEventListener('change', previewFile);
urlInput.addEventListener('input', previewUrl);

toggleUploadMethod();
</script>

</body>
</html>