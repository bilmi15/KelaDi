<?php 
session_start();
require_once '../includes/config.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['name'];
$role = $_SESSION['role'];

$message = '';
$error = '';

$limit = 5;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$kelas_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;

// General data for both roles
$stmt = $pdo->query("SELECT COUNT(*) FROM kelas");
$total_kelas_general = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM materi");
$total_materi_general = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM tugas");
$total_tugas_general = $stmt->fetchColumn();

// Data for the logged-in user (both dosen and mahasiswa)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM forum WHERE user_id = ?");
$stmt->execute([$user_id]);
$total_forum_user = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM nilai WHERE dinilai_oleh = ?");
$stmt->execute([$user_id]);
$total_nilai_user = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$user_id]);
$total_notifikasi_user = $stmt->fetchColumn();

// Data for the logged-in mahasiswa (student)
if ($role === 'mahasiswa') {
    // Count the number of classes the student is enrolled in
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT kelas_id) FROM kelas_mahasiswa WHERE mahasiswa_id = ?");
    $stmt->execute([$user_id]);
    $total_kelas_mahasiswa = $stmt->fetchColumn(); // Classes enrolled by the student

    // Count the materials related to the student's enrolled classes
    $stmt = $pdo->prepare("SELECT COUNT(*) 
        FROM materi m
        JOIN kelas k ON m.kelas_id = k.id
        JOIN kelas_mahasiswa km ON km.kelas_id = k.id
        WHERE km.mahasiswa_id = ?");
    $stmt->execute([$user_id]);
    $total_materi_mahasiswa = $stmt->fetchColumn(); // Materials available for the student

    // Count the assignments related to the student's enrolled classes
    $stmt = $pdo->prepare("SELECT COUNT(*) 
        FROM tugas t
        JOIN kelas k ON t.kelas_id = k.id
        JOIN kelas_mahasiswa km ON km.kelas_id = k.id
        WHERE km.mahasiswa_id = ?");
    $stmt->execute([$user_id]);
    $total_tugas_mahasiswa = $stmt->fetchColumn(); // Assignments related to the student's classes

    // Count the number of students in all classes for the entire system
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT mahasiswa_id) FROM kelas_mahasiswa");
    $stmt->execute();
    $total_mahasiswa_mahasiswa = $stmt->fetchColumn(); // Total students across all classes
}

// Total users in the system
$stmt = $pdo->query("SELECT COUNT(*) FROM users");
$total_users_data = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Dashboard | KelaDi E-Learning</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/dashboard.css" />
</head>

<body>
    <div class="welcome-box" aria-label="Informasi selamat datang">
        <div class="profile-circle" aria-hidden="true">
            <?= strtoupper(htmlspecialchars($user_name[0])); ?>
        </div>
        <div>
            <div class="welcome-text">Selamat Datang, <?= htmlspecialchars($user_name); ?>!</div>
            <div class="welcome-subtext">Semoga hari Anda menyenangkan.</div>
        </div>
    </div>

    <section aria-label="Ringkasan aktivitas">
        <div class="dashboard-cards">

        <?php if ($role === 'dosen') : ?>
            <a href="#" class="card card-kelas" role="region" aria-labelledby="kelas-label" tabindex="0" data-page="kelas">
                <img src="../assets/icons/classroom.svg" alt="Ikon Kelas" class="card-icon" aria-hidden="true" />
                <h3 id="kelas-label">Total Kelas</h3>
                <h4><?= $total_kelas_general ?></h4>
            </a>

            <a href="#" class="card card-materi" role="region" aria-labelledby="materi-label" tabindex="0" data-page="materi">
                <img src="../assets/icons/material.svg" alt="Ikon Materi" class="card-icon" aria-hidden="true" />
                <h3 id="materi-label">Total Materi</h3>
                <h4><?= $total_materi_general ?></h4>
            </a>

            <a href="#" class="card card-tugas" role="region" aria-labelledby="tugas-label" tabindex="0" data-page="tugas">
                <img src="../assets/icons/task.svg" alt="Ikon Tugas" class="card-icon" aria-hidden="true" />
                <h3 id="tugas-label">Total Tugas</h3>
                <h4><?= $total_tugas_general ?></h4>
            </a>

            <a href="#" class="card card-forum" role="region" aria-labelledby="forum-label" tabindex="0" data-page="forum">
                <img src="../assets/icons/forum.svg" alt="Ikon Forum" class="card-icon" aria-hidden="true" />
                <h3 id="forum-label">Total Forum</h3>
                <h4><?= $total_forum_user ?></h4>
            </a>

            <a href="#" class="card card-nilai" role="region" aria-labelledby="nilai-label" tabindex="0" data-page="nilai">
                <img src="../assets/icons/grade.svg" alt="Ikon Nilai" class="card-icon" aria-hidden="true" />
                <h3 id="nilai-label">Total Nilai Diberikan</h3>
                <h4><?= $total_nilai_user ?></h4>
            </a>

            <a href="#" class="card card-notifikasi" role="region" aria-labelledby="notifikasi-label" tabindex="0" data-page="notifications">
                <img src="../assets/icons/notification.svg" alt="Ikon Notifikasi" class="card-icon" aria-hidden="true" />
                <h3 id="notifikasi-label">Notifikasi Baru</h3>
                <h4><?= $total_notifikasi_user ?></h4>
            </a>

            <a href="#" class="card card-user" role="region" aria-labelledby="user-label" tabindex="0" data-page="user">
                <img src="../assets/icons/user.svg" alt="Ikon User" class="card-icon" aria-hidden="true" />
                <h3 id="user-label">Total User</h3>
                <h4><?= $total_users_data ?></h4>
            </a>

        <?php else : ?>
            <a href="#" class="card card-kelas" role="region" aria-labelledby="kelas-label" tabindex="0" data-page="kelas">
                <img src="../assets/icons/classroom.svg" alt="Ikon Kelas" class="card-icon" aria-hidden="true" />
                <h3 id="kelas-label">Total Kelas</h3>
                <h4><?= $total_kelas_mahasiswa ?></h4>
            </a>

            <a href="#" class="card card-materi" role="region" aria-labelledby="materi-label" tabindex="0" data-page="materi">
                <img src="../assets/icons/material.svg" alt="Ikon Materi" class="card-icon" aria-hidden="true" />
                <h3 id="materi-label">Total Materi</h3>
                <h4><?= $total_materi_mahasiswa ?></h4>
            </a>

            <a href="#" class="card card-tugas" role="region" aria-labelledby="tugas-label" tabindex="0" data-page="tugas">
                <img src="../assets/icons/task.svg" alt="Ikon Tugas" class="card-icon" aria-hidden="true" />
                <h3 id="tugas-label">Total Tugas</h3>
                <h4><?= $total_tugas_mahasiswa ?></h4>
            </a>

            <a href="#" class="card card-forum" role="region" aria-labelledby="forum-label" tabindex="0" data-page="forum">
                <img src="../assets/icons/forum.svg" alt="Ikon Forum" class="card-icon" aria-hidden="true" />
                <h3 id="forum-label">Total Forum</h3>
                <h4><?= $total_forum_user ?></h4>
            </a>

            <a href="#" class="card card-nilai" role="region" aria-labelledby="nilai-label" tabindex="0" data-page="nilai">
                <img src="../assets/icons/grade.svg" alt="Ikon Nilai" class="card-icon" aria-hidden="true" />
                <h3 id="nilai-label">Total Nilai</h3>
                <h4><?= $total_nilai_user ?></h4>
            </a>
        <?php endif; ?>
        </div>
    </section>

    <script>
        // Anda bisa menambahkan JS untuk klik pada card jika ingin menavigasi
    </script>
</body>
</html>