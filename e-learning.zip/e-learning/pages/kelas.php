<?php   
session_start();
require_once '../includes/config.php';

// Fungsi addNotification di sini supaya bisa dipakai di semua halaman
function addNotification($pdo, $user_id, $judul, $message, $url = null) {
    $sql = "INSERT INTO notifications (user_id, judul, message, url, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $judul, $message, $url]);
}

// --- Proteksi halaman untuk dosen atau mahasiswa ---
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || !in_array($_SESSION['role'], ['dosen', 'mahasiswa'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$name = $_SESSION['name'] ?? ''; // Untuk notifikasi nanti

$error = '';
$success = '';

$uploadDir = '../uploads/kelas/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// --- PROSES POST ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($role === 'dosen') {
        // Bagian ini untuk dosen tambah/edit kelas
        $id = $_POST['id'] ?? null;
        $nama_kelas = trim($_POST['nama_kelas'] ?? '');
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        $enrollment_key = trim($_POST['enrollment_key'] ?? ''); // Kode enroll key
        $gambar = '';
        $jenis_gambar = '';

        if (!$nama_kelas) {
            $error = "Nama kelas wajib diisi.";
        } elseif (!$enrollment_key) {
            $error = "Enrollment key wajib diisi.";
        } else {
            // Upload gambar jika ada
            if (isset($_FILES['gambar_file']) && $_FILES['gambar_file']['error'] === UPLOAD_ERR_OK) {
                $fileTmp = $_FILES['gambar_file']['tmp_name'];
                $fileName = basename($_FILES['gambar_file']['name']);
                $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                $allowedExt = ['png', 'jpg', 'jpeg', 'gif'];

                if (!in_array($fileExt, $allowedExt)) {
                    $error = "File gambar harus berekstensi PNG, JPG, JPEG, atau GIF.";
                } elseif ($_FILES['gambar_file']['size'] > 5 * 1024 * 1024) {
                    $error = "Ukuran file maksimal 5MB.";
                } else {
                    $newFileName = uniqid('kelas_') . '.' . $fileExt;
                    $uploadPath = $uploadDir . $newFileName;

                    if (!move_uploaded_file($fileTmp, $uploadPath)) {
                        $error = "Gagal mengupload file gambar.";
                    } else {
                        $gambar = 'uploads/kelas/' . $newFileName;
                        $jenis_gambar = $fileExt;
                    }
                }
            } else {
                // URL gambar jika tidak ada file upload
                $gambarInput = trim($_POST['gambar'] ?? '');
                if ($gambarInput) {
                    if (filter_var($gambarInput, FILTER_VALIDATE_URL)) {
                        $gambar = $gambarInput;
                        $ext = strtolower(pathinfo(parse_url($gambarInput, PHP_URL_PATH), PATHINFO_EXTENSION));
                        if (in_array($ext, ['png', 'jpg', 'jpeg', 'gif'])) {
                            $jenis_gambar = $ext;
                        } elseif (substr($gambarInput, -5) === '.json') {
                            $jenis_gambar = 'lottie';
                        } else {
                            $jenis_gambar = 'url';
                        }
                    } else {
                        $error = "URL tidak valid.";
                    }
                } elseif ($id) {
                    $stmt = $pdo->prepare("SELECT gambar, jenis_gambar FROM kelas WHERE id = ?");
                    $stmt->execute([$id]);
                    $existing = $stmt->fetch();
                    $gambar = $existing['gambar'] ?? '';
                    $jenis_gambar = $existing['jenis_gambar'] ?? '';
                }
            }
        }

        // Jika tidak ada error, proses tambah atau update kelas
        if (!$error) {
            if ($id) {
                // Update kelas
                $stmt = $pdo->prepare("UPDATE kelas SET nama_kelas = ?, deskripsi = ?, gambar = ?, jenis_gambar = ?, enrollment_key = ? WHERE id = ?");
                $stmt->execute([$nama_kelas, $deskripsi, $gambar, $jenis_gambar, $enrollment_key, $id]);

                addNotification($pdo, $user_id, "Kelas Diperbarui", "Kelas \"$nama_kelas\" berhasil diperbarui.", "kelas.php");
                $_SESSION['success'] = "Data kelas berhasil diperbarui.";
            } else {
                // Tambah kelas baru
                $stmt = $pdo->prepare("INSERT INTO kelas (nama_kelas, deskripsi, gambar, jenis_gambar, user_id, enrollment_key) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$nama_kelas, $deskripsi, $gambar, $jenis_gambar, $user_id, $enrollment_key]);

                addNotification($pdo, $user_id, "Kelas Baru Ditambahkan", "Kelas \"$nama_kelas\" berhasil ditambahkan.", "kelas.php");
                $_SESSION['success'] = "Kelas baru berhasil ditambahkan.";
            }
            header("Location: kelas.php");
            exit;
        } else {
            $_SESSION['error'] = $error;
            header("Location: kelas.php");
            exit;
        }
    } elseif ($role === 'mahasiswa' && isset($_POST['join_kelas_id'], $_POST['enrollment_key'])) {
        // Mahasiswa join kelas
        $kelas_id = intval($_POST['join_kelas_id']);
        $enrollment_key = trim($_POST['enrollment_key']);

        // Cek enrollment key
        $stmt = $pdo->prepare("SELECT enrollment_key FROM kelas WHERE id = ?");
        $stmt->execute([$kelas_id]);
        $kelas = $stmt->fetch();

        if ($kelas && $kelas['enrollment_key'] === $enrollment_key) {
            // Cek apakah mahasiswa sudah bergabung ke kelas ini
            $check = $pdo->prepare("SELECT * FROM kelas_mahasiswa WHERE mahasiswa_id = ? AND kelas_id = ?");
            $check->execute([$user_id, $kelas_id]); // Using mahasiswa_id for the check
            if (!$check->fetch()) {
                // Mahasiswa belum bergabung, lakukan insert
                $insert = $pdo->prepare("INSERT INTO kelas_mahasiswa (mahasiswa_id, kelas_id, joined_at) VALUES (?, ?, NOW())");
                $insert->execute([$user_id, $kelas_id]); // Using mahasiswa_id for the insert

                // Kirim notifikasi ke dosen pemilik kelas
                $owner = $pdo->prepare("SELECT user_id FROM kelas WHERE id = ?");
                $owner->execute([$kelas_id]);
                $owner_id = $owner->fetchColumn();

                if ($owner_id) {
                    addNotification($pdo, $owner_id, "Mahasiswa Gabung Kelas", "Mahasiswa \"$name\" telah bergabung ke kelas Anda.", "kelas.php");
                }

                $_SESSION['success'] = "Berhasil bergabung ke kelas.";
            } else {
                $_SESSION['error'] = "Anda sudah tergabung di kelas ini.";
            }
        } else {
            $_SESSION['error'] = "Kode enroll tidak valid.";
        }
        header("Location: kelas.php");
        exit;
    }
}

// --- Delete kelas tetap hanya dosen ---
if ($role === 'dosen' && isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    $stmt = $pdo->prepare("SELECT gambar, jenis_gambar FROM kelas WHERE id = ?");
    $stmt->execute([$deleteId]);
    $kelasToDelete = $stmt->fetch();

    if ($kelasToDelete && in_array($kelasToDelete['jenis_gambar'], ['png', 'jpg', 'jpeg', 'gif']) && !empty($kelasToDelete['gambar'])) {
        $fileToDelete = '../' . $kelasToDelete['gambar'];
        if (file_exists($fileToDelete)) {
            unlink($fileToDelete);
        }
    }

    $stmt = $pdo->prepare("DELETE FROM kelas WHERE id = ?");
    $stmt->execute([$deleteId]);
    $_SESSION['success'] = "Kelas berhasil dihapus.";
    header("Location: kelas.php");
    exit;
}

$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);

// --- Ambil daftar kelas ---
$kelasList = $pdo->query("SELECT k.*, u.name AS owner_name FROM kelas k LEFT JOIN users u ON u.id = k.user_id ORDER BY k.created_at DESC")->fetchAll();

$editData = null;
if ($role === 'dosen' && isset($_GET['edit'])) {
    $editId = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM kelas WHERE id = ?");
    $stmt->execute([$editId]);
    $editData = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Manajemen Kelas - Dashboard <?= ucfirst($role) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/kelas.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
</head>
<body>

<div class="container py-4">
    <h2 class="mb-4">Manajemen Kelas</h2>

    <?php if ($role === 'dosen'): ?>
    <form method="POST" enctype="multipart/form-data" id="formKelas" novalidate>
        <input type="hidden" name="id" value="<?= htmlspecialchars($editData['id'] ?? '') ?>">

        <div class="mb-3">
            <label for="nama_kelas" class="form-label">Nama Kelas <span class="text-danger">*</span></label>
            <input type="text" id="nama_kelas" name="nama_kelas" class="form-control" required value="<?= htmlspecialchars($editData['nama_kelas'] ?? '') ?>" />
            <div class="invalid-feedback">Nama kelas wajib diisi.</div>
        </div>

        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi</label>
            <textarea id="deskripsi" name="deskripsi" class="form-control" rows="3"><?= htmlspecialchars($editData['deskripsi'] ?? '') ?></textarea>
        </div>

        <div class="mb-3">
            <label for="enrollment_key" class="form-label">Enrollment Key <span class="text-danger">*</span></label>
            <input type="text" name="enrollment_key" class="form-control" required value="<?= htmlspecialchars($editData['enrollment_key'] ?? '') ?>" />
        </div>

        <div class="mb-3">
            <label class="form-label">Upload Gambar (PNG, JPG, JPEG, GIF)</label>
            <input type="file" name="gambar_file" id="gambar_file" accept=".png,.jpg,.jpeg,.gif" class="form-control" />
            <div class="form-text">File maksimal 5MB. Format: png, jpg, jpeg, gif.</div>
            <img id="preview_img" src="<?= !empty($editData['gambar']) && in_array($editData['jenis_gambar'], ['png', 'jpg', 'jpeg', 'gif']) ? '../' . htmlspecialchars($editData['gambar']) : '' ?>" alt="Preview Gambar" style="max-width:150px; margin-top:10px; display: <?= !empty($editData['gambar']) ? 'block' : 'none' ?>;" />
        </div>

        <div class="mb-3">
            <label for="gambar" class="form-label">Atau Masukkan URL Gambar / Link Lottie JSON</label>
            <input type="url" id="gambar" name="gambar" class="form-control" value="<?= htmlspecialchars($editData['gambar'] ?? '') ?>" placeholder="https://example.com/image.png atau https://example.com/animation.json" />
            <div id="urlPreview" style="margin-top:10px;"></div>
        </div>

        <button type="submit" class="btn btn-primary"><?= $editData ? 'Update' : 'Tambah' ?> Kelas</button>
        <?php if ($editData): ?>
        <a href="kelas.php" class="btn btn-secondary ms-2">Batal</a>
        <?php endif; ?>
    </form>
    <?php endif; ?>

<h4 class="mt-5">Daftar Kelas</h4>
<table class="table table-striped align-middle">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Kelas</th>
            <th>Deskripsi</th>
            <th>Gambar</th>
            <th>Pemilik</th>
            <?php if ($role === 'dosen'): ?>
                <th>Enrollment Key</th>  <!-- Menambahkan kolom untuk Enrollment Key -->
            <?php endif; ?>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($kelasList): ?>
            <?php foreach ($kelasList as $idx => $kelas): ?>
                <tr>
                    <td><?= $idx + 1 ?></td>
                    <td><?= htmlspecialchars($kelas['nama_kelas']) ?></td>
                    <td><?= nl2br(htmlspecialchars($kelas['deskripsi'])) ?></td>
                    <td style="max-width: 120px;">
                        <?php 
                        if ($kelas['jenis_gambar'] === 'lottie' && $kelas['gambar']): ?>
                            <lottie-player src="<?= htmlspecialchars($kelas['gambar']) ?>" background="transparent" speed="1" loop autoplay style="width: 100px; height: 100px;"></lottie-player>
                        <?php elseif ($kelas['gambar']): ?>
                            <?php
                            $imgSrc = $kelas['gambar'];
                            if (!preg_match('#^https?://#i', $imgSrc)) {
                                $imgSrc = '../' . ltrim($imgSrc, '/');
                            }
                            ?>
                            <img src="<?= htmlspecialchars($imgSrc) ?>" alt="Gambar Kelas" style="max-width: 100px; max-height: 100px; object-fit: contain;" />
                        <?php else: ?>
                            - 
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($kelas['owner_name'] ?? '-') ?></td>
                    <?php if ($role === 'dosen'): ?>
                        <td><?= htmlspecialchars($kelas['enrollment_key']) ?></td> <!-- Menampilkan Enrollment Key untuk dosen -->
                    <?php endif; ?>
                    <td>
                        <?php if ($role === 'dosen'): ?>
                            <a href="kelas.php?edit=<?= $kelas['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="kelas.php?delete=<?= $kelas['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus kelas ini?');">Hapus</a>
                        <?php else: ?>
                            <?php
                            // Cek apakah mahasiswa sudah gabung kelas ini
                            $stmtCheck = $pdo->prepare("SELECT * FROM kelas_mahasiswa WHERE mahasiswa_id = ? AND kelas_id = ?");
                            $stmtCheck->execute([$user_id, $kelas['id']]);
                            $joined = (bool) $stmtCheck->fetch();
                            ?>
                            <?php if ($joined): ?>
                                <button class="btn btn-sm btn-secondary" disabled>Sudah Bergabung</button>
                            <?php else: ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="join_kelas_id" value="<?= $kelas['id'] ?>" />
                                    <input type="text" name="enrollment_key" class="form-control" placeholder="Masukkan Enrollment Key" required />
                                    <button type="submit" class="btn btn-sm btn-success">Gabung Kelas</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="7" class="text-center">Belum ada kelas yang dibuat.</td></tr>
        <?php endif; ?>
    </tbody>
</table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
// Preview gambar upload lokal
document.getElementById('gambar_file').addEventListener('change', function(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('preview_img');

    if (!file) {
        preview.style.display = 'none';
        return;
    }

    const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'File harus berupa gambar PNG, JPG, JPEG, atau GIF.'
        });
        event.target.value = '';
        preview.style.display = 'none';
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Ukuran file maksimal 5MB.'
        });
        event.target.value = '';
        preview.style.display = 'none';
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        preview.src = e.target.result;
        preview.style.display = 'block';
    };
    reader.readAsDataURL(file);
});

// Fungsi preview URL (gambar, lottie, video, youtube)
function previewUrl() {
    const urlInput = document.getElementById('gambar');
    const preview = document.getElementById('urlPreview');
    const url = urlInput.value.trim();
    preview.innerHTML = '';

    if (!url) return;

    const lowerUrl = url.toLowerCase();

    if (lowerUrl.endsWith('.json')) {
        preview.innerHTML = `<lottie-player src="${url}" background="transparent" speed="1" loop autoplay style="width:150px; height:150px;"></lottie-player>`;
    } else if (/\.(png|jpg|jpeg|gif)$/i.test(lowerUrl)) {
        preview.innerHTML = `<img src="${url}" alt="Preview" style="max-width:150px; max-height:150px; border-radius:8px;" />`;
    } else if (/\.(mp4)$/i.test(lowerUrl)) {
        preview.innerHTML = `<video width="200" controls><source src="${url}" type="video/mp4">Browser tidak mendukung video.</video>`;
    } else if (url.includes('youtube.com') || url.includes('youtu.be')) {
        let embedUrl = url;
        if (url.includes('watch?v=')) {
            embedUrl = url.replace('watch?v=', 'embed/');
        }
        preview.innerHTML = `<iframe width="250" height="150" src="${embedUrl}" frameborder="0" allowfullscreen></iframe>`;
    } else {
        preview.innerHTML = `<small style="color:#888;">Tidak dapat menampilkan preview untuk URL ini.</small>`;
    }
}

// Event listener input URL
document.getElementById('gambar').addEventListener('input', previewUrl);

// Panggil preview URL saat halaman load jika ada nilai
document.addEventListener('DOMContentLoaded', function() {
    previewUrl();

    <?php if ($success): ?>
    Swal.fire({
        icon: 'success',
        title: 'Sukses',
        text: <?= json_encode($success) ?>,
        timer: 2500,
        timerProgressBar: true,
        showConfirmButton: false
    });
    <?php elseif ($error): ?>
    Swal.fire({
        icon: 'error',
        title: 'Error',
        text: <?= json_encode($error) ?>,
        showConfirmButton: true
    });
    <?php endif; ?>
});
</script>

</body>
</html>