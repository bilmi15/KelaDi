<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    http_response_code(403);
    echo "Akses ditolak.";
    exit;
}

$page = $_GET['page'] ?? 'home';
$user_id = $_SESSION['user_id'];

// Ambil data sesuai page
switch ($page) {
    case 'kelas':
        $stmt = $pdo->query("SELECT * FROM kelas");
        $kelas = $stmt->fetchAll();
        ?>
        <h2>Daftar Kelas</h2>
        <ul>
            <?php foreach ($kelas as $k): ?>
                <li><?= htmlspecialchars($k['nama_kelas']) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php
        break;

    case 'materi':
        $stmt = $pdo->query("SELECT * FROM materi");
        $materi = $stmt->fetchAll();
        ?>
        <h2>Daftar Materi</h2>
        <ul>
            <?php foreach ($materi as $m): ?>
                <li><?= htmlspecialchars($m['judul_materi']) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php
        break;

    case 'tugas':
        $stmt = $pdo->query("SELECT * FROM tugas");
        $tugas = $stmt->fetchAll();
        ?>
        <h2>Daftar Tugas</h2>
        <ul>
            <?php foreach ($tugas as $t): ?>
                <li><?= htmlspecialchars($t['judul_tugas']) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php
        break;

    case 'nilai':
        $stmt = $pdo->prepare("SELECT * FROM nilai WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $nilai = $stmt->fetchAll();
        ?>
        <h2>Daftar Nilai</h2>
        <ul>
            <?php foreach ($nilai as $n): ?>
                <li><?= htmlspecialchars($n['mata_kuliah']) . ': ' . htmlspecialchars($n['nilai']) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php
        break;

    case 'forum':
        $stmt = $pdo->prepare("SELECT * FROM forum WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $forum = $stmt->fetchAll();
        ?>
        <h2>Daftar Forum</h2>
        <ul>
            <?php foreach ($forum as $f): ?>
                <li><?= htmlspecialchars($f['judul_forum']) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php
        break;

    case 'notifications':
        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$user_id]);
        $notifications = $stmt->fetchAll();
        ?>
        <h2>Notifikasi Baru</h2>
        <ul>
            <?php foreach ($notifications as $note): ?>
                <li><?= htmlspecialchars($note['pesan']) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php
        break;

    case 'upload':
        $stmt = $pdo->prepare("SELECT * FROM uploads WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $uploads = $stmt->fetchAll();
        ?>
        <h2>Upload Anda</h2>
        <ul>
            <?php foreach ($uploads as $up): ?>
                <li><?= htmlspecialchars($up['nama_file']) ?></li>
            <?php endforeach; ?>
        </ul>
        <?php
        break;

    case 'admin_users':
        // Contoh halaman list user
        $stmt = $pdo->query("SELECT id, username, name, role FROM users ORDER BY created_at DESC");
        $users = $stmt->fetchAll();
        ?>
        <h2>Daftar User</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th><th>Username</th><th>Nama</th><th>Role</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($users as $u): ?>
                <tr>
                    <td><?= htmlspecialchars($u['id']) ?></td>
                    <td><?= htmlspecialchars($u['username']) ?></td>
                    <td><?= htmlspecialchars($u['name']) ?></td>
                    <td><?= htmlspecialchars($u['role']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php
        break;

    case 'home':
    default:
        // Konten default halaman dashboard
        $user_name = $_SESSION['name'];
        ?>
        <div class="welcome-box" aria-label="Informasi selamat datang dosen">
            <div style="display:flex; align-items:center;">
                <div class="profile-circle" aria-hidden="true">
                    <?= strtoupper(htmlspecialchars($user_name[0])); ?>
                </div>
                <div>
                    <div class="welcome-text">Selamat Datang di Dashboard Dosen, <?= htmlspecialchars($user_name); ?></div>
                    <div class="welcome-subtext">Semoga hari Anda menyenangkan!</div>
                </div>
            </div>
        </div>
        <section aria-label="Ringkasan aktivitas dosen">
            <div class="dashboard-cards">
                <div class="card-kelas card" role="region" aria-labelledby="kelas-label">
                    <h3 id="kelas-label">Total Kelas</h3>
                    <h4><?= $pdo->query("SELECT COUNT(*) FROM kelas")->fetchColumn(); ?></h4>
                </div>
                <div class="card-materi card" role="region" aria-labelledby="materi-label">
                    <h3 id="materi-label">Total Materi</h3>
                    <h4><?= $pdo->query("SELECT COUNT(*) FROM materi")->fetchColumn(); ?></h4>
                </div>
                <div class="card-tugas card" role="region" aria-labelledby="tugas-label">
                    <h3 id="tugas-label">Total Tugas</h3>
                    <h4><?= $pdo->query("SELECT COUNT(*) FROM tugas")->fetchColumn(); ?></h4>
                </div>
                <!-- Tambah card lain sesuai kebutuhan -->
            </div>
        </section>
        <?php
        break;
}