<?php
// dashboard_footer.php
?>

<footer class="main-footer" role="contentinfo">
  <div class="container">
    &copy; <?= date('Y') ?> KelaDi — Kelas Digital untuk Generasi Cerdas.
  </div>
</footer>

<link rel="stylesheet" href="/e-learning/assets/css/hefo.css" />

</body>
</html>