<?php
session_start();
require_once '../includes/config.php';

// Cek apakah pengguna sudah login dan memiliki role admin (role = 1)
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

// Validasi parameter id pada URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: admin_users.php');
    exit;
}

$id = (int)$_GET['id'];

// Update status approval user
$stmt = $pdo->prepare("UPDATE users SET is_approved = 1 WHERE id = ?");
$success = $stmt->execute([$id]);

// Jika update berhasil, bisa tambahkan notifikasi sukses dengan session (opsional)
if ($success) {
    $_SESSION['success_message'] = "User dengan ID $id berhasil disetujui.";
} else {
    $_SESSION['error_message'] = "Terjadi kesalahan saat menyetujui user.";
}

header('Location: admin_users.php');
exit;