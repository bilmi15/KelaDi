<?php 
session_start();
require_once '../includes/config.php';

// Cek apakah pengguna sudah login dan memiliki role 'dosen'
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

// Ambil data users dari database, urut berdasarkan tanggal dibuat terbaru
$stmt = $pdo->prepare("SELECT id, username, name, role, is_approved, created_at FROM users ORDER BY created_at DESC");
$stmt->execute();
$users = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Daftar User | Dashboard Dosen</title>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/admin_user.css" />
</head>
<body>

<main class="container mt-4">
  <h2>Daftar User</h2>
  <a href="admin_add_user.php" class="btn btn-success mb-3">Tambah User Baru</a>

  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
      <thead class="table-primary">
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Nama Lengkap</th>
          <th>Role</th>
          <th>Status Approval</th>
          <th>Dibuat Pada</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $user): ?>
          <tr>
            <td><?= htmlspecialchars($user['id']) ?></td>
            <td><?= htmlspecialchars($user['username']) ?></td>
            <td><?= htmlspecialchars($user['name']) ?></td>
            <td>
              <?= ($user['role'] === 'dosen' || $user['role'] === 'admin' || $user['role'] === 1) ? 'Dosen (Admin)' : 'Mahasiswa' ?>
            </td>
            <td>
              <?php if ($user['is_approved']): ?>
                <span class="badge bg-success">Disetujui</span>
              <?php else: ?>
                <span class="badge bg-warning text-dark">Pending</span>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($user['created_at']) ?></td>
            <td>
              <?php if (!$user['is_approved']): ?>
                <a href="admin_approve.php?id=<?= urlencode($user['id']) ?>" class="btn btn-sm btn-primary">Approve</a>
              <?php endif; ?>
              <a href="admin_edit_user.php?id=<?= urlencode($user['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
              <a href="admin_delete_user.php?id=<?= urlencode($user['id']) ?>" onclick="return confirm('Yakin hapus user ini?');" class="btn btn-sm btn-danger">Hapus</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

</main>

</body>
</html>