<?php
session_start();
require_once '../includes/config.php';

// Fungsi tambah notifikasi
function addNotification($pdo, $user_id, $judul, $message, $url = null) {
    $sql = "INSERT INTO notifications (user_id, judul, message, url, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $judul, $message, $url]);
}

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || !in_array($_SESSION['role'], ['dosen', 'mahasiswa'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$name = $_SESSION['name'] ?? '';

$message = '';
$error = '';

$limit = 5;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$kelas_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;

$uploadDir = '../uploads/';

// Fungsi validasi tipe file
function isValidFileType($fileType, $allowedTypes) {
    return in_array(strtolower($fileType), $allowedTypes);
}

// Fungsi render preview media tugas dan hasil tugas
function renderMediaPreview($tipe, $fileRaw, $judul = '') {
    $file = preg_match('#^https?://#i', $fileRaw) ? $fileRaw : '../' . ltrim($fileRaw, '/');
    switch ($tipe) {
        case 'pdf':
            return "<embed src='$file' type='application/pdf' width='100%' height='400px' class='rounded mb-3' />";
        case 'video':
            return "<video width='100%' controls class='rounded mb-3'><source src='$file' type='video/mp4'>Browser tidak mendukung video.</video>";
        case 'image':
            return "<img src='$file' alt='$judul' class='mb-3 rounded' style='max-width:100%; height:auto; object-fit: contain;' />";
        case 'lottie':
            return "<lottie-player src='$file' background='transparent' speed='1' loop autoplay class='mb-3' style='width:100%; max-height:300px;'></lottie-player>";
        case 'url':
            return "<iframe src='$file' width='100%' height='400' frameborder='0' allowfullscreen class='rounded mb-3'></iframe>";
        case 'text':
            return "<div class='materi-text-content mb-3' style='background:#f5f5f5; padding:15px; border-radius:8px; white-space: pre-wrap;'>Deskripsi teks tidak dapat dipreview.</div>";
        default:
            return "<p class='text-danger mb-3'>Tipe file tidak dikenali atau tidak dapat dipreview.</p>";
    }
}

// PROSES TAMBAH / EDIT TUGAS (hanya dosen)
if ($role === 'dosen' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && in_array($_POST['action'], ['add', 'edit'])) {
    $action = $_POST['action'];
    $kelas_id_post = $_POST['kelas_id'] ?? null;
    $judul = trim($_POST['judul'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $deadline = $_POST['deadline'] ?? null;

    if (!$kelas_id_post || !$judul || !$deadline) {
        $error = "Kelas, Judul, dan Deadline wajib diisi.";
    }

    if (!$error) {
        try {
            if ($action === 'add') {
                $stmt = $pdo->prepare("INSERT INTO tugas (kelas_id, judul, deskripsi, deadline, created_at) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$kelas_id_post, $judul, $deskripsi, $deadline]);
                addNotification($pdo, $user_id, "Tugas Baru Ditambahkan", "Tugas baru berhasil ditambahkan: $judul", "tugas.php?kelas_id=$kelas_id_post");
                $_SESSION['success'] = "Tugas berhasil ditambahkan.";
            } elseif ($action === 'edit') {
                $edit_id = intval($_POST['id'] ?? 0);
                if (!$edit_id) {
                    $error = "ID tugas tidak valid.";
                } else {
                    $stmt = $pdo->prepare("UPDATE tugas SET kelas_id=?, judul=?, deskripsi=?, deadline=? WHERE id=?");
                    $stmt->execute([$kelas_id_post, $judul, $deskripsi, $deadline, $edit_id]);
                    addNotification($pdo, $user_id, "Tugas Diperbarui", "Tugas berhasil diperbarui: $judul", "tugas.php?kelas_id=$kelas_id_post");
                    $_SESSION['success'] = "Tugas berhasil diperbarui.";
                }
            }
            header("Location: tugas.php?kelas_id=$kelas_id_post");
            exit;
        } catch (Exception $e) {
            $error = "Terjadi kesalahan saat menyimpan tugas.";
        }
    }
}

// PROSES HAPUS TUGAS (hanya dosen)
if ($role === 'dosen' && isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    try {
        $stmt = $pdo->prepare("DELETE FROM tugas WHERE id = ?");
        $stmt->execute([$delete_id]);
        $_SESSION['success'] = "Tugas berhasil dihapus.";
        header("Location: tugas.php?kelas_id=$kelas_id");
        exit;
    } catch (Exception $e) {
        $error = "Terjadi kesalahan saat menghapus tugas.";
    }
}

// Check enrollment for mahasiswa role before displaying tasks
if ($role === 'mahasiswa' && $kelas_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM kelas_mahasiswa WHERE mahasiswa_id = ? AND kelas_id = ?");
    $stmt->execute([$user_id, $kelas_id]);
    $isEnrolled = $stmt->fetch();
    if (!$isEnrolled) {
        $message = "Harap gabung ke kelas terlebih dahulu dengan enrollment key.";
    }
}

if (isset($_GET['msg'])) {
    switch ($_GET['msg']) {
        case 'success': $message = "Tugas berhasil ditambahkan."; break;
        case 'updated': $message = "Tugas berhasil diperbarui."; break;
        case 'deleted': $message = "Tugas berhasil dihapus."; break;
    }
}

$editData = null;
if ($role === 'dosen' && isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $stmt = $pdo->prepare("SELECT * FROM tugas WHERE id = ?");
    $stmt->execute([$edit_id]);
    $editData = $stmt->fetch();
}

$kelasStmt = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas ASC");
$kelasList = $kelasStmt->fetchAll();

if ($kelas_id > 0) {
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM tugas WHERE kelas_id = ?");
    $stmtCount->execute([$kelas_id]);
} else {
    $stmtCount = $pdo->query("SELECT COUNT(*) FROM tugas");
}
$totalTugas = $stmtCount->fetchColumn();
$totalPages = ceil($totalTugas / $limit);

if ($kelas_id > 0) {
    $stmt = $pdo->prepare("SELECT t.*, k.nama_kelas FROM tugas t JOIN kelas k ON t.kelas_id = k.id WHERE t.kelas_id = ? ORDER BY t.deadline DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $kelas_id, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
} else {
    $stmt = $pdo->prepare("SELECT t.*, k.nama_kelas FROM tugas t JOIN kelas k ON t.kelas_id = k.id ORDER BY t.deadline DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
}
$tugass = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Manajemen Tugas - KelaDi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="../assets/css/task.css" rel="stylesheet" />
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<div id="page-wrapper">

  <main class="content-body container">
    <h1 class="mb-4">Manajemen Tugas</h1>

    <?php if ($role === 'dosen'): ?>
    <section class="add-tugas mb-5">
      <h2><?= $editData ? "Edit Tugas" : "Tambah Tugas Baru" ?></h2>
      <form id="tugasForm" method="POST" action="tugas.php<?= $kelas_id ? '?kelas_id=' . $kelas_id : '' ?>">
          <input type="hidden" name="action" value="<?= $editData ? 'edit' : 'add' ?>" />
          <?php if ($editData): ?>
              <input type="hidden" name="id" value="<?= $editData['id'] ?>" />
          <?php endif; ?>
          <div class="mb-3">
              <label for="kelas_id" class="form-label">Kelas</label>
              <select id="kelas_id" name="kelas_id" class="form-select" required>
                  <option value="">-- Pilih Kelas --</option>
                  <?php foreach ($kelasList as $kelas): ?>
                      <option value="<?= $kelas['id'] ?>" <?= ($editData && $editData['kelas_id'] == $kelas['id']) ? 'selected' : '' ?>><?= htmlspecialchars($kelas['nama_kelas']) ?></option>
                  <?php endforeach; ?>
              </select>
          </div>
          <div class="mb-3">
              <label for="judul" class="form-label">Judul Tugas</label>
              <input type="text" id="judul" name="judul" class="form-control" value="<?= $editData ? htmlspecialchars($editData['judul']) : '' ?>" required />
          </div>
          <div class="mb-3">
              <label for="deskripsi" class="form-label">Deskripsi</label>
              <textarea id="deskripsi" name="deskripsi" class="form-control" rows="3"><?= $editData ? htmlspecialchars($editData['deskripsi']) : '' ?></textarea>
          </div>
          <div class="mb-3">
              <label for="deadline" class="form-label">Deadline</label>
              <input type="datetime-local" id="deadline" name="deadline" class="form-control" value="<?= $editData ? date('Y-m-d\TH:i', strtotime($editData['deadline'])) : '' ?>" required />
          </div>
          <button type="submit" class="btn btn-primary"><?= $editData ? 'Update Tugas' : 'Tambah Tugas' ?></button>
          <?php if ($editData): ?>
            <a href="tugas.php<?= $kelas_id ? '?kelas_id=' . $kelas_id : '' ?>" class="btn btn-danger btn-sm me-1">Batal Edit</a>
          <?php endif; ?>
      </form>
    </section>
    <?php endif; ?>

    <?php if ($message): ?>
      <script>
        window.onload = () => {
          Swal.fire({
            icon: 'success',
            title: 'Sukses',
            text: '<?= htmlspecialchars($message) ?>',
            timer: 3000,
            timerProgressBar: true,
            showConfirmButton: false
          });
        };
      </script>
    <?php endif; ?>

    <?php if ($error): ?>
      <script>
        window.onload = () => {
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: '<?= htmlspecialchars($error) ?>',
            timer: 3000,
            timerProgressBar: true,
            showConfirmButton: false
          });
        };
      </script>
    <?php endif; ?>

    <form method="get" class="filter-kelas mb-4">
      <label for="kelas_id_filter" class="form-label">Filter Berdasarkan Kelas:</label>
      <select name="kelas_id" id="kelas_id_filter" class="form-select" onchange="this.form.submit()">
        <option value="0" <?= $kelas_id === 0 ? 'selected' : '' ?>>Semua Kelas</option>
        <?php foreach ($kelasList as $kelas): ?>
          <option value="<?= $kelas['id'] ?>" <?= $kelas_id === (int)$kelas['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($kelas['nama_kelas']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </form>

    <?php if (empty($tugass)): ?>
      <p class="text-center">Tidak ada tugas tersedia untuk kelas ini.</p>
    <?php else: ?>
      <?php foreach ($tugass as $tugas): ?>
        <div class="tugas-item mb-4 p-3 bg-white rounded shadow-sm">
          <h3 class="fw-bold"><?= htmlspecialchars($tugas['judul']) ?></h3>
          <p><strong>Kelas:</strong> <?= htmlspecialchars($tugas['nama_kelas']) ?></p>
          <p><strong>Deskripsi:</strong> <?= nl2br(htmlspecialchars($tugas['deskripsi'])) ?></p>
          <p><strong>Deadline:</strong> <?= date('d M Y H:i', strtotime($tugas['deadline'])) ?></p>

        <div class="mb-3">
          <?php if ($role === 'dosen'): ?>
            <a href="tugas.php?edit_id=<?= $tugas['id'] ?>" class="btn btn-warning btn-sm me-1">Edit</a>
            <a href="tugas.php?delete=<?= $tugas['id'] ?>" class="btn btn-danger btn-sm me-1" onclick="return confirm('Yakin ingin hapus tugas ini?')">Hapus</a>
          <?php endif; ?>

          <?php 
          // Get current date and task deadline
            $currentDate = new DateTime();
            $deadline = new DateTime($tugas['deadline']);

          // Check if the task is past the deadline for mahasiswa
          if ($role === 'mahasiswa' && $currentDate > $deadline): ?>
            <button class="btn btn-danger btn-sm" disabled>Tugas Terlambat</button>
          <?php elseif ($role === 'mahasiswa'): ?>
            <a href="upload.php?kelas_id=<?= $tugas['kelas_id'] ?>" class="btn btn-warning btn-sm me-1">Upload Tugas</a>
          <?php endif; ?>

          <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#previewModal" data-judul="<?= htmlspecialchars($tugas['judul']) ?>" data-deskripsi="<?= htmlspecialchars($tugas['deskripsi']) ?>" data-deadline="<?= htmlspecialchars($tugas['deadline']) ?>">Preview</button>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

  </main>

</div>

<!-- Modal Preview Tugas -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-labelledby="previewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="previewModalLabel">Preview Tugas</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body">
        <h4 id="modalJudul"></h4>
        <p><strong>Deskripsi:</strong> <span id="modalDeskripsi"></span></p>
        <p><strong>Deadline:</strong> <span id="modalDeadline"></span></p>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const previewModal = document.getElementById('previewModal');
  previewModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    const judul = button.getAttribute('data-judul');
    const deskripsi = button.getAttribute('data-deskripsi');
    const deadline = button.getAttribute('data-deadline');
    document.getElementById('modalJudul').textContent = judul;
    document.getElementById('modalDeskripsi').textContent = deskripsi;
    document.getElementById('modalDeadline').textContent = new Date(deadline).toLocaleString('id-ID', {
      year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  });
</script>

</body>
</html>