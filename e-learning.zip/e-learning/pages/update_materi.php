<?php
session_start();
require_once '../includes/config.php';

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

if ($role !== 'dosen') {
    header("Location: materi.php");
    exit;
}

$error = '';
$success = '';
$editData = null;
$kelas_id = $_GET['kelas_id'] ?? null;
$edit_id = $_GET['edit_id'] ?? null;

// Fungsi untuk menangani upload file atau URL media
function handleMedia($media_source, $media_url, $media_file, $tipe_media, $upload_dir) {
    if ($media_source === 'url') {
        if (empty($media_url)) {
            return ['error' => 'URL media harus diisi.'];
        }
        return ['path' => $media_url];
    } else {
        if (!isset($media_file) || $media_file['error'] === UPLOAD_ERR_NO_FILE) {
            return ['error' => 'File media harus diupload.'];
        }
        if ($media_file['error'] !== UPLOAD_ERR_OK) {
            return ['error' => 'Terjadi kesalahan saat upload file.'];
        }

        $allowedTypes = [
            'image' => ['image/png', 'image/jpeg', 'image/gif'],
            'video' => ['video/mp4'],
            'pdf' => ['application/pdf'],
            'lottie' => ['application/json'],
        ];

        $fileType = mime_content_type($media_file['tmp_name']);
        if (!in_array($fileType, $allowedTypes[$tipe_media] ?? [])) {
            return ['error' => 'Tipe file tidak didukung untuk tipe media ini.'];
        }

        $ext = pathinfo($media_file['name'], PATHINFO_EXTENSION);
        $newFileName = uniqid('media_', true) . '.' . $ext;
        $targetPath = rtrim($upload_dir, '/') . '/' . $newFileName;

        if (!move_uploaded_file($media_file['tmp_name'], $targetPath)) {
            return ['error' => 'Gagal menyimpan file yang diupload.'];
        }

        // Simpan path relatif
        return ['path' => $targetPath];
    }
}

if ($edit_id) {
    // Memeriksa jika materi yang ingin diedit ada
    $stmt = $pdo->prepare("SELECT * FROM materi WHERE id = ?");
    $stmt->execute([$edit_id]);
    $editData = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi dan ambil data input dari form
    $judul = trim($_POST['judul']);
    $deskripsi = trim($_POST['deskripsi']);
    $tipe_media = $_POST['tipe_media'];
    $media_url = $_POST['media_url'];
    $media_file = $_FILES['media_file'] ?? null;
    $kelas_id = $_POST['kelas_id'] ?? null;

    // Validasi kelas_id yang dipilih
    $stmt = $pdo->prepare("SELECT id FROM kelas WHERE id = ?");
    $stmt->execute([$kelas_id]);
    $kelasExists = $stmt->fetchColumn();

    if (!$kelasExists) {
        $error = "Kelas tidak ditemukan!";
    }

    // Validasi judul dan deskripsi
    if (!$judul || !$deskripsi) {
        $error = "Judul dan deskripsi materi harus diisi.";
    }

    // Jika tidak ada error, proses upload dan simpan materi
    if (!$error) {
        // Proses upload dan simpan materi baru
        $mediaResult = handleMedia($_POST['media_source'], $media_url, $media_file, $tipe_media, '../uploads/');
        if (isset($mediaResult['error'])) {
            $error = $mediaResult['error'];
        } else {
            $filePathToSave = $mediaResult['path'];

            if ($edit_id) {
                // Update materi
                $stmt = $pdo->prepare("UPDATE materi SET judul = ?, deskripsi = ?, tipe_media = ?, media_url = ?, kelas_id = ? WHERE id = ?");
                $stmt->execute([$judul, $deskripsi, $tipe_media, $filePathToSave, $kelas_id, $edit_id]);
            } else {
                // Insert materi baru
                $stmt = $pdo->prepare("INSERT INTO materi (kelas_id, judul, deskripsi, tipe_media, media_url, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt->execute([$kelas_id, $judul, $deskripsi, $tipe_media, $filePathToSave]);
            }

            $success = 'Materi berhasil disimpan.';
            header("Location: materi.php?kelas_id=$kelas_id");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Update Materi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/material.css" />
</head>
<body>
  <div id="page-wrapper">
    <main class="content-body container">
      <h1 class="mb-4"><?= $editData ? "Edit Materi" : "Tambah Materi Baru" ?></h1>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php elseif ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
      <?php endif; ?>

      <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label for="kelas_id" class="form-label">Kelas</label>
          <select name="kelas_id" id="kelas_id" class="form-select" required>
            <option value="">-- Pilih Kelas --</option>
            <?php
            // Menampilkan daftar kelas
            $kelasStmt = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas ASC");
            $kelasList = $kelasStmt->fetchAll();
            foreach ($kelasList as $kelas) {
                echo "<option value='{$kelas['id']}' " . (($editData && $editData['kelas_id'] == $kelas['id']) ? 'selected' : '') . ">{$kelas['nama_kelas']}</option>";
            }
            ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="judul" class="form-label">Judul Materi</label>
          <input type="text" id="judul" name="judul" class="form-control" value="<?= $editData ? htmlspecialchars($editData['judul']) : '' ?>" required />
        </div>

        <div class="mb-3">
          <label for="deskripsi" class="form-label">Deskripsi</label>
          <textarea id="deskripsi" name="deskripsi" class="form-control" rows="3"><?= $editData ? htmlspecialchars($editData['deskripsi']) : '' ?></textarea>
        </div>

        <div class="mb-3">
          <label for="tipe_media" class="form-label">Tipe Media</label>
          <select id="tipe_media" name="tipe_media" class="form-select" required>
            <option value="image" <?= ($editData && $editData['tipe_media'] === 'image') ? 'selected' : '' ?>>Gambar (PNG/JPG/GIF)</option>
            <option value="video" <?= ($editData && $editData['tipe_media'] === 'video') ? 'selected' : '' ?>>Video MP4</option>
            <option value="pdf" <?= ($editData && $editData['tipe_media'] === 'pdf') ? 'selected' : '' ?>>PDF</option>
            <option value="lottie" <?= ($editData && $editData['tipe_media'] === 'lottie') ? 'selected' : '' ?>>Animasi Lottie (.json)</option>
            <option value="url" <?= ($editData && $editData['tipe_media'] === 'url') ? 'selected' : '' ?>>URL Embed</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Sumber Media</label>
          <input type="radio" name="media_source" value="file" checked /> File Upload
          <input type="radio" name="media_source" value="url" /> URL
        </div>

        <div class="mb-3">
          <label for="media_file" class="form-label">Upload File</label>
          <input type="file" id="media_file" name="media_file" class="form-control" />
        </div>

        <div class="mb-3">
          <label for="media_url" class="form-label">URL Media</label>
          <input type="url" id="media_url" name="media_url" class="form-control" value="<?= $editData ? htmlspecialchars($editData['media_url']) : '' ?>" />
        </div>

        <button type="submit" class="btn btn-primary"><?= $editData ? 'Update Materi' : 'Tambah Materi' ?></button>
      </form>
    </main>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>