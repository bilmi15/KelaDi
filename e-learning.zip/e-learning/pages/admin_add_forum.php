<?php
session_start();
require_once '../includes/config.php';

// Fungsi addNotification bisa Anda tempatkan di file terpisah lalu require_once di sini
function addNotification($pdo, $user_id, $judul, $message, $url = null) {
    $sql = "INSERT INTO notifications (user_id, judul, message, url, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, $judul, $message, $url]);
}

// Cek login & role dosen
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

// Ambil data kelas untuk dropdown
$stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
$kelas_list = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kelas_id = $_POST['kelas_id'] ?? '';
    $topik = trim($_POST['topik'] ?? '');
    $isi = trim($_POST['isi'] ?? '');

    if (empty($kelas_id) || empty($topik) || empty($isi)) {
        $error = "Semua kolom wajib diisi.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO forum (kelas_id, user_id, topik, isi, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$kelas_id, $_SESSION['user_id'], $topik, $isi]);

        // Tambah notifikasi
        addNotification($pdo, $_SESSION['user_id'], "Forum Baru Dibuat", "Forum baru berhasil dibuat: $topik", "forum.php");

        $_SESSION['success_message'] = "Forum berhasil ditambahkan.";
        header("Location: admin_add_forum.php");
        exit;
    }
}

// Ambil pesan sukses dari session (PRG)
if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Tambah Forum | Dashboard Dosen</title>
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/admin_add_forum.css" />
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<main class="container mt-4">
  <h2>Tambah Forum Baru</h2>
  <form method="post" action="" novalidate>
    <div class="mb-3">
      <label for="kelas_id" class="form-label">Pilih Kelas</label>
      <select id="kelas_id" name="kelas_id" class="form-select" required>
        <option value="">-- Pilih Kelas --</option>
        <?php foreach ($kelas_list as $kelas): ?>
          <option value="<?= htmlspecialchars($kelas['id']) ?>" <?= (isset($_POST['kelas_id']) && $_POST['kelas_id'] == $kelas['id']) ? 'selected' : '' ?>>
            <?= htmlspecialchars($kelas['nama_kelas']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label for="topik" class="form-label">Topik</label>
      <input type="text" id="topik" name="topik" class="form-control" required value="<?= htmlspecialchars($_POST['topik'] ?? '') ?>" />
    </div>

    <div class="mb-3">
      <label for="isi" class="form-label">Isi</label>
      <textarea id="isi" name="isi" class="form-control" rows="5" required><?= htmlspecialchars($_POST['isi'] ?? '') ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Tambah Forum</button>
    <a href="forum.php" class="btn btn-secondary">Kembali</a>
  </form>
</main>

<?php if ($success): ?>
<script>
Swal.fire({
  icon: 'success',
  title: 'Sukses',
  text: <?= json_encode($success) ?>,
  timer: 3000,
  showConfirmButton: false
});
</script>
<?php endif; ?>

<?php if ($error): ?>
<script>
Swal.fire({
  icon: 'error',
  title: 'Error',
  text: <?= json_encode($error) ?>,
  timer: 4000,
  showConfirmButton: true
});
</script>
<?php endif; ?>

</body>
</html>