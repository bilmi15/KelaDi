<?php  
session_start();
require_once '../includes/config.php';

$message = '';
$error = '';
$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];

$limit = 5;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$kelas_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;
$uploadDir = '../uploads/';

// Fungsi untuk memvalidasi tipe file
function isValidFileType($fileType, $allowedTypes) {
    return in_array(strtolower($fileType), $allowedTypes);
}

// Fungsi untuk upload file dan return path
function uploadFile($file, $tipe_media, $uploadDir) {
    $allowedExtensions = [];
    $fileTmpPath = $file['tmp_name'];
    $fileName = basename($file['name']);
    $fileSize = $file['size'];
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if ($fileSize > 10 * 1024 * 1024) {
        return ['error' => "Ukuran file maksimal 10MB."];
    }

    switch ($tipe_media) {
        case 'image': $allowedExtensions = ['jpg','jpeg','png','gif']; break;
        case 'video': $allowedExtensions = ['mp4']; break;
        case 'pdf': $allowedExtensions = ['pdf']; break;
        case 'lottie': $allowedExtensions = ['json']; break;
    }

    if (!isValidFileType($fileType, $allowedExtensions)) {
        return ['error' => "Ekstensi file tidak sesuai untuk tipe media yang dipilih."];
    }

    $newFileName = uniqid('media_', true) . '.' . $fileType;
    $destPath = $uploadDir . $newFileName;
    
    if (!move_uploaded_file($fileTmpPath, $destPath)) {
        return ['error' => "Gagal menyimpan file upload."];
    }

    return ['path' => 'uploads/' . $newFileName];
}

// Fungsi untuk menghapus file lama
function deleteOldFile($oldFilePath) {
    $oldFullPath = '../' . ltrim($oldFilePath, '/');
    if (file_exists($oldFullPath)) {
        unlink($oldFullPath);
    }
}

// Fungsi untuk menangani media (file atau url)
function handleMedia($media_source, $media_url, $media_file, $tipe_media, $uploadDir) {
    $filePath = '';
    if ($media_source === 'file' && isset($media_file) && $media_file['error'] === UPLOAD_ERR_OK) {
        $uploadResult = uploadFile($media_file, $tipe_media, $uploadDir);
        if (isset($uploadResult['error'])) {
            return ['error' => $uploadResult['error']];
        }
        $filePath = $uploadResult['path'];
    } elseif ($media_source === 'url' && filter_var($media_url, FILTER_VALIDATE_URL)) {
        $filePath = $media_url;
    } else {
        return ['error' => "Media tidak valid."];
    }
    return ['path' => $filePath];
}

// Fungsi untuk menambah atau memperbarui materi
function saveMateri($action, $edit_id, $kelas_id_post, $judul, $deskripsi, $tipe_media, $media_source, $media_url, $media_file, $uploadDir) {
    global $pdo;

    // Proses media
    $mediaResult = handleMedia($media_source, $media_url, $media_file, $tipe_media, $uploadDir);
    if (isset($mediaResult['error'])) {
        return ['error' => $mediaResult['error']];
    }
    $filePathToSave = $mediaResult['path'];

    // Jika edit, hapus file lama jika ada file baru
    if ($action === 'edit') {
        // Ambil data lama (file lama)
        $stmtOld = $pdo->prepare("SELECT media_url FROM materi WHERE id = ?");
        $stmtOld->execute([$edit_id]);
        $oldData = $stmtOld->fetch(PDO::FETCH_ASSOC);
        $oldFilePath = $oldData ? $oldData['media_url'] : '';

        // Hapus file lama jika ada file baru dan file tersebut bukan URL
        if ($oldFilePath && !filter_var($oldFilePath, FILTER_VALIDATE_URL)) {
            deleteOldFile($oldFilePath); // Hapus file lama
        }

        // Update materi dengan file atau URL baru dan update judul dan deskripsi
        $stmt = $pdo->prepare("UPDATE materi SET kelas_id=?, judul=?, deskripsi=?, tipe_media=?, media_url=? WHERE id=?");
        $stmt->execute([$kelas_id_post, $judul, $deskripsi, $tipe_media, $filePathToSave, $edit_id]);
    } else {
        // Tambah materi baru
        $stmt = $pdo->prepare("INSERT INTO materi (kelas_id, judul, deskripsi, tipe_media, media_url, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$kelas_id_post, $judul, $deskripsi, $tipe_media, $filePathToSave]);
    }

    return ['success' => "Materi berhasil " . ($action === 'add' ? 'ditambahkan' : 'diperbarui') . "."];
}

// Handle POST request for adding/editing materi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $kelas_id_post = $_POST['kelas_id'] ?? null;
    $judul = trim($_POST['judul'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $tipe_media = $_POST['tipe_media'] ?? 'image';
    $media_url = trim($_POST['media_url'] ?? '');
    $media_source = $_POST['media_source'] ?? 'file';
    $media_file = $_FILES['media_file'] ?? null;

    if (!$kelas_id_post || !$judul) {
        $error = "Kelas dan Judul materi wajib diisi.";
    }

    if (!$error) {
        $result = saveMateri($action, $_POST['id'] ?? null, $kelas_id_post, $judul, $deskripsi, $tipe_media, $media_source, $media_url, $media_file, $uploadDir);
        if (isset($result['error'])) {
            $error = $result['error'];
        } else {
            $_SESSION['success'] = $result['success'];
            header("Location: materi.php?kelas_id=$kelas_id_post&msg=" . ($action === 'add' ? 'success' : 'updated'));
            exit;
        }
    }
}

// Handle delete request
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    try {
        $stmt = $pdo->prepare("DELETE FROM materi WHERE id = ?");
        $stmt->execute([$delete_id]);
        $_SESSION['success'] = "Materi berhasil dihapus.";
        header("Location: materi.php?kelas_id=$kelas_id&msg=deleted");
        exit;
    } catch (Exception $e) {
        $error = "Terjadi kesalahan saat menghapus materi.";
    }
}

// Get edit data if editing
$editData = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $stmt = $pdo->prepare("SELECT * FROM materi WHERE id = ?");
    $stmt->execute([$edit_id]);
    $editData = $stmt->fetch();
}

// Get list of classes
$kelasStmt = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas ASC");
$kelasList = $kelasStmt->fetchAll();

// Get materials based on class ID
if ($kelas_id > 0) {
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM materi WHERE kelas_id = ?");
    $stmtCount->execute([$kelas_id]);
} else {
    $stmtCount = $pdo->query("SELECT COUNT(*) FROM materi");
}
$totalMateri = $stmtCount->fetchColumn();
$totalPages = ceil($totalMateri / $limit);

if ($kelas_id > 0) {
    $stmt = $pdo->prepare("SELECT m.*, k.nama_kelas FROM materi m JOIN kelas k ON m.kelas_id = k.id WHERE m.kelas_id = ? ORDER BY m.created_at DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $kelas_id, PDO::PARAM_INT);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
} else {
    $stmt = $pdo->prepare("SELECT m.*, k.nama_kelas FROM materi m JOIN kelas k ON m.kelas_id = k.id ORDER BY m.created_at DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
}
$materis = $stmt->fetchAll();

// Render Materi Content (Tetap sama seperti sebelumnya)
function renderMateriContent($materi) {
    $tipe = $materi['tipe_media'];
    $fileRaw = $materi['media_url'];
    $judul = htmlspecialchars($materi['judul']);
    $deskripsi = nl2br(htmlspecialchars($materi['deskripsi']));

    $file = preg_match('#^https?://#i', $fileRaw) ? $fileRaw : '../' . ltrim($fileRaw, '/');

    echo "<div class='materi-content'>";
    echo "<h3 class='fw-bold mb-2'>$judul</h3>";
    echo "<p class='text-muted mb-3'>$deskripsi</p>";

    switch ($tipe) {
        case 'pdf':
            echo "<embed src='$file' type='application/pdf' width='100%' height='400px' class='rounded mb-3' />";
            break;
        case 'video':
            echo "<video width='100%' controls class='rounded mb-3'><source src='$file' type='video/mp4'>Browser tidak mendukung video.</video>";
            break;
        case 'image':
            echo "<img src='$file' alt='$judul' class='mb-3 rounded' style='max-width:100%; height:auto; object-fit: contain;' />";
            break;
        case 'lottie':
            echo "<lottie-player src='$file' background='transparent' speed='1' loop autoplay class='mb-3' style='width:100%; max-height:300px;'></lottie-player>";
            break;
        case 'url':
            echo "<iframe src='$file' width='100%' height='400' frameborder='0' allowfullscreen class='rounded mb-3'></iframe>";
            break;
        case 'text':
            echo "<div class='materi-text-content mb-3' style='background:#f5f5f5; padding:15px; border-radius:8px; white-space: pre-wrap;'>$deskripsi</div>";
            break;
        default:
            echo "<p class='text-danger mb-3'>Tipe file tidak dikenali atau tidak dapat dipreview.</p>";
    }
    echo "</div>";
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Materi - KelaDi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="../assets/css/material.css" rel="stylesheet" />
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<div id="page-wrapper">

  <main class="content-body container">
    <h1 class="mb-4">Fitur Manajemen Materi</h1>

<?php if ($role === 'dosen'): ?>
    <!-- Dosen Form to Add/Edit Material -->
    <section class="add-materi mb-5">
        <h2><?= $editData ? "Edit Materi" : "Tambah Materi Baru" ?></h2>
        <form id="materiForm" method="POST" enctype="multipart/form-data" action="materi.php<?= $kelas_id ? '?kelas_id=' . $kelas_id : '' ?>">
            <input type="hidden" name="action" value="<?= $editData ? 'edit' : 'add' ?>" />
            <?php if ($editData): ?>
                <input type="hidden" name="id" value="<?= $editData['id'] ?>" />
            <?php endif; ?>
            <div class="mb-3">
                <label for="kelas_id" class="form-label">Kelas</label>
                <select id="kelas_id" name="kelas_id" class="form-select" required>
                    <option value="">-- Pilih Kelas --</option>
                    <?php foreach ($kelasList as $kelas): ?>
                        <option value="<?= $kelas['id'] ?>" <?= ($editData && $editData['kelas_id'] == $kelas['id']) ? 'selected' : '' ?>><?= htmlspecialchars($kelas['nama_kelas']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="judul" class="form-label">Judul Materi</label>
                <input type="text" id="judul" name="judul" class="form-control" value="<?= $editData ? htmlspecialchars($editData['judul']) : '' ?>" required />
            </div>
            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi</label>
                <textarea id="deskripsi" name="deskripsi" class="form-control" rows="3"><?= $editData ? htmlspecialchars($editData['deskripsi']) : '' ?></textarea>
            </div>
            <div class="mb-3">
                <label for="tipe_media" class="form-label">Tipe Media</label>
                <select id="tipe_media" name="tipe_media" class="form-select" required>
                    <?php 
                    $mediaTypes = ['image' => 'Gambar (PNG/JPG/GIF)', 'lottie' => 'Animasi Lottie (.json)', 'pdf' => 'PDF', 'video' => 'Video MP4', 'url' => 'URL Embed (YouTube, dll)', 'text' => 'Teks'];
                    foreach ($mediaTypes as $val => $label): ?>
                        <option value="<?= $val ?>" <?= ($editData && $editData['tipe_media'] === $val) ? 'selected' : (!$editData && $val === 'image' ? 'selected' : '') ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Sumber Media</label>
                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="media_source" id="media_source_file" value="file" <?= (!$editData || ($editData && !$editData['media_url'])) ? 'checked' : '' ?> onchange="toggleMediaInput()">
                        <label class="form-check-label" for="media_source_file">Upload File</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="media_source" id="media_source_url" value="url" <?= ($editData && $editData['media_url']) ? 'checked' : '' ?> onchange="toggleMediaInput()">
                        <label class="form-check-label" for="media_source_url">URL Media</label>
                    </div>
                </div>
            </div>

            <div class="mb-3" id="media_file_group" style="display:none;">
                <label for="media_file" class="form-label">Pilih File</label>
                <input type="file" id="media_file" name="media_file" class="form-control" accept="image/*,video/mp4,application/pdf,application/json" />
                <div id="uploadPreview" class="mt-3"></div>
            </div>

            <div class="mb-3" id="media_url_group" style="display:none;">
                <label for="media_url" class="form-label">URL Media</label>
                <input type="url" id="media_url" name="media_url" class="form-control" placeholder="Masukkan URL media (gambar, video, pdf, dll)" value="<?= $editData ? htmlspecialchars($editData['media_url']) : '' ?>" />
                <div id="urlPreview" class="mt-3"></div>
            </div>

            <button type="submit" class="btn btn-primary"><?= $editData ? 'Update Materi' : 'Tambah Materi' ?></button>
            <?php if ($editData): ?>
                <a href="materi.php<?= $kelas_id ? '?kelas_id=' . $kelas_id : '' ?>" class="btn btn-secondary ms-2">Batal Edit</a>
            <?php endif; ?>
        </form>
    </section>

    <?php elseif ($role === 'mahasiswa'): ?>
    <!-- Hide Buttons for Mahasiswa -->
    <?php if ($message): ?>
        <div class="alert alert-warning">
            <?= $message ?>
        </div>
    <?php endif; ?>

    <?php endif; ?>

    <h2 class="mb-4">Daftar Materi</h2>
    <form method="get" class="filter-kelas mb-4">
      <label for="kelas_id_filter" class="form-label">Filter Berdasarkan Kelas:</label>
      <select name="kelas_id" id="kelas_id_filter" class="form-select" onchange="this.form.submit()">
        <option value="0" <?= $kelas_id === 0 ? 'selected' : '' ?>>Semua Kelas</option>
        <?php foreach ($kelasList as $kelas): ?>
          <option value="<?= $kelas['id'] ?>" <?= $kelas_id === (int)$kelas['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($kelas['nama_kelas']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </form>

    <?php if (empty($materis)): ?>
      <p class="text-center">Tidak ada materi tersedia untuk kelas ini.</p>
    <?php else: ?>
      <?php foreach ($materis as $materi): ?>
        <div class="materi-item">
          <?php renderMateriContent($materi); ?>
          <small>Dibuat pada: <?= date('d M Y H:i', strtotime($materi['created_at'])) ?></small>
          <div class="mt-3">
            <?php if ($role === 'dosen'): ?>
              <a href="update_materi.php?edit_id=<?= $materi['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
              <a href="materi.php?delete=<?= $materi['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin hapus materi ini?')">Hapus</a>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>

      <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
          <?php if ($page > 1): ?>
            <li class="page-item"><a class="page-link" href="?kelas_id=<?= $kelas_id ?>&page=<?= $page - 1 ?>">Sebelumnya</a></li>
          <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Sebelumnya</span></li>
          <?php endif; ?>

          <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
              <a class="page-link" href="?kelas_id=<?= $kelas_id ?>&page=<?= $p ?>"><?= $p ?></a>
            </li>
          <?php endfor; ?>

          <?php if ($page < $totalPages): ?>
            <li class="page-item"><a class="page-link" href="?kelas_id=<?= $kelas_id ?>&page=<?= $page + 1 ?>">Berikutnya</a></li>
          <?php else: ?>
            <li class="page-item disabled"><span class="page-link">Berikutnya</span></li>
          <?php endif; ?>
        </ul>
      </nav>
    <?php endif; ?>

  </main>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  const previewModal = document.getElementById('previewModal');
  previewModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    const tipe = button.getAttribute('data-tipe');
    let url = button.getAttribute('data-url');
    const judul = button.getAttribute('data-judul');
    const modalTitle = previewModal.querySelector('.modal-title');
    const modalBody = previewModal.querySelector('.modal-body');

    modalTitle.textContent = `Preview Materi: ${judul}`;

    // Tambahkan ../ prefix jika bukan URL absolut
    if (!/^https?:\/\//i.test(url)) {
      url = '../' + url.replace(/^\/+/, '');
    }

    let content = '';
    if(tipe === 'pdf') {
      content = `<embed src="${url}" type="application/pdf" width="100%" height="600px" />`;
    } else if(tipe === 'video') {
      content = `<video width="100%" controls><source src="${url}" type="video/mp4">Video tidak didukung browser Anda.</video>`;
    } else if(tipe === 'image') {
      content = `<img src="${url}" alt="${judul}" style="max-width:100%; height:auto; border-radius:8px;" />`;
    } else if(tipe === 'lottie') {
      content = `<lottie-player src="${url}" background="transparent" speed="1" loop autoplay style="width:100%; height:400px;"></lottie-player>`;
    } else if(tipe === 'url') {
      content = `<iframe src="${url}" width="100%" height="600" frameborder="0" allowfullscreen></iframe>`;
    } else if(tipe === 'text') {
      content = `<div style="background:#f5f5f5; padding:15px; border-radius:8px; white-space: pre-wrap;">Deskripsi teks tidak dapat dipreview.</div>`;
    } else {
      content = `<p class="text-danger">Tipe file tidak dikenali atau tidak dapat dipreview.</p>`;
    }
    modalBody.innerHTML = content;
  });

  function toggleMediaInput() {
    const sourceFile = document.getElementById('media_source_file').checked;
    document.getElementById('media_file_group').style.display = sourceFile ? 'block' : 'none';
    document.getElementById('media_url_group').style.display = sourceFile ? 'none' : 'block';
  }

  document.querySelectorAll('input[name="media_source"]').forEach(el => {
    el.addEventListener('change', toggleMediaInput);
  });

  toggleMediaInput();

  document.getElementById('media_file').addEventListener('change', function(event) {
    const file = event.target.files[0];
    const previewContainer = document.getElementById('uploadPreview');
    previewContainer.innerHTML = '';

    if (!file) return;

    const fileType = file.type;
    const reader = new FileReader();

    reader.onload = function(e) {
      let element;
      if (fileType.startsWith('image/')) {
        element = document.createElement('img');
        element.src = e.target.result;
        element.style.maxWidth = '100%';
        element.style.height = 'auto';
        element.style.borderRadius = '8px';
      } else if (fileType === 'application/pdf') {
        element = document.createElement('embed');
        element.src = e.target.result;
        element.type = 'application/pdf';
        element.width = '100%';
        element.height = '300px';
        element.style.borderRadius = '8px';
      } else if (fileType.startsWith('video/')) {
        element = document.createElement('video');
        element.controls = true;
        element.width = 400;
        const source = document.createElement('source');
        source.src = e.target.result;
        source.type = fileType;
        element.appendChild(source);
      } else {
        element = document.createElement('p');
        element.textContent = 'Preview tidak tersedia untuk tipe file ini.';
      }
      previewContainer.appendChild(element);
    };

    if(fileType.startsWith('image/') || fileType === 'application/pdf' || fileType.startsWith('video/')) {
      reader.readAsDataURL(file);
    } else {
      previewContainer.innerHTML = '<p>Preview tidak tersedia untuk tipe file ini.</p>';
    }
  });

  function previewUrl() {
    const urlInput = document.getElementById('media_url');
    const preview = document.getElementById('urlPreview');
    const url = urlInput.value.trim();
    preview.innerHTML = '';

    if (!url) return;

    const lowerUrl = url.toLowerCase();

    if (lowerUrl.endsWith('.json')) {
      preview.innerHTML = `<lottie-player src="${url}" background="transparent" speed="1" loop autoplay style="width:150px; height:150px;"></lottie-player>`;
    } else if (/\.(png|jpg|jpeg|gif)$/i.test(lowerUrl)) {
      preview.innerHTML = `<img src="${url}" alt="Preview" style="max-width:150px; max-height:150px; border-radius:8px;" />`;
    } else if (/\.(mp4)$/i.test(lowerUrl)) {
      preview.innerHTML = `<video width="200" controls><source src="${url}" type="video/mp4">Browser tidak mendukung video.</video>`;
    } else if (url.includes('youtube.com') || url.includes('youtu.be')) {
      let embedUrl = url;
      if (url.includes('watch?v=')) {
        embedUrl = url.replace('watch?v=', 'embed/');
      }
      preview.innerHTML = `<iframe width="250" height="150" src="${embedUrl}" frameborder="0" allowfullscreen></iframe>`;
    } else {
      preview.innerHTML = `<small style="color:#888;">Tidak dapat menampilkan preview untuk URL ini.</small>`;
    }
  }

  document.getElementById('media_url').addEventListener('input', previewUrl);
  document.addEventListener('DOMContentLoaded', () => {
    previewUrl();
  });
</script>

</body>
</html>