<?php
session_start();
require_once '../includes/config.php';

// Cek login dan role dosen
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

// Ambil data tugas dan user untuk dropdown
$tugasStmt = $pdo->query("SELECT id, judul FROM tugas ORDER BY created_at DESC");
$tugasList = $tugasStmt->fetchAll();

$userStmt = $pdo->query("SELECT id, name FROM users WHERE role = 'mahasiswa' ORDER BY name ASC");
$userList = $userStmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tugas_id = $_POST['tugas_id'] ?? '';
    $user_id = $_POST['user_id'] ?? '';
    $nilai = $_POST['nilai'] ?? '';
    $komentar = trim($_POST['komentar'] ?? '');

    // Validasi
    if (empty($tugas_id) || empty($user_id) || $nilai === '') {
        $error = "Kolom tugas, mahasiswa, dan nilai wajib diisi.";
    } elseif (!is_numeric($nilai) || $nilai < 0 || $nilai > 100) {
        $error = "Nilai harus berupa angka antara 0 sampai 100.";
    } else {
        // Cek apakah sudah ada nilai untuk tugas dan user ini
        $checkStmt = $pdo->prepare("SELECT id FROM nilai WHERE tugas_id = ? AND user_id = ?");
        $checkStmt->execute([$tugas_id, $user_id]);
        if ($checkStmt->fetch()) {
            $error = "Nilai untuk tugas dan mahasiswa ini sudah ada. Silakan edit nilainya.";
        } else {
            // Cek jika data benar-benar valid, insert data nilai
            $insertStmt = $pdo->prepare("INSERT INTO nilai (tugas_id, user_id, nilai, komentar, submitted_at, dinilai_oleh) VALUES (?, ?, ?, ?, NOW(), ?)");
            $insertStmt->execute([$tugas_id, $user_id, $nilai, $komentar, $_SESSION['user_id']]); // dinilai_oleh = current logged-in user

            $_SESSION['success_message'] = "Nilai berhasil ditambahkan.";
            header("Location: admin_add_nilai.php");
            exit;
        }
    }
}

// Ambil pesan sukses dari session dan hapus
if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tambah Nilai | Dashboard Dosen</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/admin_nilai.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<main class="container mt-4">
    <h2>Tambah Nilai</h2>

    <form method="post" action="" novalidate>
        <div class="mb-3">
            <label for="tugas_id" class="form-label">Pilih Tugas</label>
            <select id="tugas_id" name="tugas_id" class="form-select" required>
                <option value="">-- Pilih Tugas --</option>
                <?php foreach ($tugasList as $tugas): ?>
                    <option value="<?= htmlspecialchars($tugas['id']) ?>" <?= (isset($_POST['tugas_id']) && $_POST['tugas_id'] == $tugas['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($tugas['judul']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="user_id" class="form-label">Pilih Mahasiswa</label>
            <select id="user_id" name="user_id" class="form-select" required>
                <option value="">-- Pilih Mahasiswa --</option>
                <?php foreach ($userList as $user): ?>
                    <option value="<?= htmlspecialchars($user['id']) ?>" <?= (isset($_POST['user_id']) && $_POST['user_id'] == $user['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($user['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="nilai" class="form-label">Nilai (0-100)</label>
            <input type="number" id="nilai" name="nilai" class="form-control" min="0" max="100" required value="<?= htmlspecialchars($_POST['nilai'] ?? '') ?>" />
        </div>

        <div class="mb-3">
            <label for="komentar" class="form-label">Komentar</label>
            <textarea id="komentar" name="komentar" class="form-control" rows="4"><?= htmlspecialchars($_POST['komentar'] ?? '') ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Tambah Nilai</button>
        <a href="nilai.php" class="btn btn-secondary">Kembali</a>
    </form>
</main>

<?php if ($success): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Sukses',
    text: <?= json_encode($success) ?>,
    timer: 3000,
    showConfirmButton: false
});
</script>
<?php endif; ?>

<?php if ($error): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: <?= json_encode($error) ?>,
    timer: 4000,
    showConfirmButton: true
});
</script>
<?php endif; ?>

</body>
</html>