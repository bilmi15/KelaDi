<?php
session_start();
require_once '../includes/config.php';

// Pastikan user login dan role dosen atau mahasiswa
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) 
    || !in_array($_SESSION['role'], ['dosen', 'mahasiswa'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$notif_id = $_GET['id'] ?? null;

if (!$notif_id) {
    $_SESSION['error'] = 'Notifikasi tidak ditemukan.';
    header("Location: notification.php");
    exit;
}

// Ambil detail notifikasi berdasarkan ID dan user yang sedang login
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? AND id = ?");
$stmt->execute([$user_id, $notif_id]);
$notif = $stmt->fetch();

if (!$notif) {
    $_SESSION['error'] = 'Notifikasi tidak ditemukan atau Anda tidak berhak mengaksesnya.';
    header("Location: notification.php");
    exit;
}

// Tandai notifikasi sebagai sudah dibaca jika belum
if ($notif['is_read'] == 0) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    $stmt->execute([$notif_id]);
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Detail Notifikasi | Dashboard <?= ucfirst($role) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/view_notification.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<main class="container mt-4">
    <h2>Detail Notifikasi</h2>

    <div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title"><?= htmlspecialchars($notif['judul']) ?></h5>
            <p class="card-text"><?= nl2br(htmlspecialchars($notif['message'])) ?></p>

            <?php if (!empty($notif['url'])): ?>
                <p><strong>Link: </strong><a href="<?= htmlspecialchars($notif['url']) ?>" target="_blank" rel="noopener noreferrer"><?= htmlspecialchars($notif['url']) ?></a></p>
            <?php endif; ?>

            <p><small class="text-muted"><?= date('d M Y H:i', strtotime($notif['created_at'])) ?></small></p>

            <a href="notification.php" class="btn btn-secondary">Kembali ke Daftar Notifikasi</a>
        </div>
    </div>
</main>

<?php if ($_SESSION['success'] ?? null): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Sukses',
    text: <?= json_encode($_SESSION['success']) ?>,
    timer: 2500,
    timerProgressBar: true,
    showConfirmButton: false
});
</script>
<?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if ($_SESSION['error'] ?? null): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: <?= json_encode($_SESSION['error']) ?>,
    showConfirmButton: true
});
</script>
<?php unset($_SESSION['error']); ?>
<?php endif; ?>

</body>
</html>