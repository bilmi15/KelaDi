<?php
session_start();
require_once '../includes/config.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['dosen', 'mahasiswa'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$kelas_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;

// Ambil data forum dengan join ke tabel kelas untuk nama kelas dan user untuk nama user
// For 'mahasiswa', we filter forum posts by the classes they are enrolled in
if ($role === 'mahasiswa') {
    // Get the student's enrolled classes
    $stmt = $pdo->prepare("SELECT k.id FROM kelas k JOIN kelas_mahasiswa km ON k.id = km.kelas_id WHERE km.mahasiswa_id = ?");
    $stmt->execute([$user_id]);
    $enrolled_classes = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (empty($enrolled_classes)) {
        $forumList = [];
    } else {
        // Fetch forums related to classes the student is enrolled in
        $stmt = $pdo->prepare("
            SELECT f.id, k.nama_kelas, u.name as user_name, f.topik, f.isi, f.created_at
            FROM forum f
            LEFT JOIN kelas k ON f.kelas_id = k.id
            LEFT JOIN users u ON f.user_id = u.id
            WHERE f.kelas_id IN (" . implode(",", $enrolled_classes) . ")
            ORDER BY f.created_at DESC
        ");
        $stmt->execute();
        $forumList = $stmt->fetchAll();
    }
} else {
    // For 'dosen', get all forums
    $stmt = $pdo->prepare("
        SELECT f.id, k.nama_kelas, u.name as user_name, f.topik, f.isi, f.created_at
        FROM forum f
        LEFT JOIN kelas k ON f.kelas_id = k.id
        LEFT JOIN users u ON f.user_id = u.id
        ORDER BY f.created_at DESC
    ");
    $stmt->execute();
    $forumList = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Daftar Forum | Dashboard <?= ucfirst($role) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/forum.css" />
</head>
<body>

<main class="container mt-4">
    <h2>Daftar Forum</h2>

    <!-- Display 'Add Forum' button only for instructors -->
    <?php if ($role === 'dosen'): ?>
        <a href="admin_add_forum.php" class="btn btn-primary mb-3">Tambah Forum Baru</a>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Kelas</th>
                    <th>User</th>
                    <th>Topik</th>
                    <th>Isi</th>
                    <th>Dibuat Pada</th>
                    <?php if ($role === 'dosen'): ?>
                        <th>Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($forumList) > 0): ?>
                    <?php foreach ($forumList as $forum): ?>
                        <tr>
                            <td><?= htmlspecialchars($forum['id']) ?></td>
                            <td><?= htmlspecialchars($forum['nama_kelas'] ?? 'Tidak ada kelas') ?></td>
                            <td><?= htmlspecialchars($forum['user_name'] ?? 'Tidak diketahui') ?></td>
                            <td><?= htmlspecialchars($forum['topik']) ?></td>
                            <td><?= nl2br(htmlspecialchars($forum['isi'])) ?></td>
                            <td><?= htmlspecialchars($forum['created_at']) ?></td>
                            <?php if ($role === 'dosen'): ?>
                                <!-- Actions for 'dosen': Edit and Delete -->
                                <td>
                                    <a href="admin_edit_forum.php?id=<?= urlencode($forum['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="admin_delete_forum.php?id=<?= urlencode($forum['id']) ?>" onclick="return confirm('Yakin hapus forum ini?');" class="btn btn-sm btn-danger">Hapus</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="<?= $role === 'dosen' ? 7 : 6 ?>" class="text-center">Belum ada data forum.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

</body>
</html>