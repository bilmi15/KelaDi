<?php
session_start();
require_once '../includes/config.php';

// Cek login dan role dosen
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: nilai.php");
    exit;
}

$id = (int)$_GET['id'];
$error = '';
$success = '';

// Ambil data nilai berdasarkan id
$stmt = $pdo->prepare("SELECT * FROM nilai WHERE id = ?");
$stmt->execute([$id]);
$nilai = $stmt->fetch();

if (!$nilai) {
    header("Location: nilai.php");
    exit;
}

// Ambil data tugas dan user untuk dropdown
$tugasStmt = $pdo->query("SELECT id, judul FROM tugas ORDER BY created_at DESC");
$tugasList = $tugasStmt->fetchAll();

$userStmt = $pdo->query("SELECT id, name FROM users WHERE role = 'mahasiswa' ORDER BY name ASC");
$userList = $userStmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tugas_id = $_POST['tugas_id'] ?? '';
    $user_id = $_POST['user_id'] ?? '';
    $nilaiInput = $_POST['nilai'] ?? '';
    $komentar = trim($_POST['komentar'] ?? '');

    // Validasi
    if (empty($tugas_id) || empty($user_id) || $nilaiInput === '') {
        $error = "Kolom tugas, mahasiswa, dan nilai wajib diisi.";
    } elseif (!is_numeric($nilaiInput) || $nilaiInput < 0 || $nilaiInput > 100) {
        $error = "Nilai harus berupa angka antara 0 sampai 100.";
    } else {
        // Update nilai
        $updateStmt = $pdo->prepare("UPDATE nilai SET tugas_id = ?, user_id = ?, nilai = ?, komentar = ? WHERE id = ?");
        $updateStmt->execute([$tugas_id, $user_id, $nilaiInput, $komentar, $id]);

        $_SESSION['success_message'] = "Nilai berhasil diperbarui.";
        header("Location: admin_edit_nilai.php?id=" . $id);
        exit;
    }
}

// Ambil pesan sukses dari session dan hapus
if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Edit Nilai | Dashboard Dosen</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/admin_nilai.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<main class="container mt-4">
    <h2>Edit Nilai</h2>

    <form method="post" action="" novalidate>
        <div class="mb-3">
            <label for="tugas_id" class="form-label">Pilih Tugas</label>
            <select id="tugas_id" name="tugas_id" class="form-select" required>
                <option value="">-- Pilih Tugas --</option>
                <?php foreach ($tugasList as $tugas): ?>
                    <option value="<?= htmlspecialchars($tugas['id']) ?>" <?= ($nilai['tugas_id'] == $tugas['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($tugas['judul']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="user_id" class="form-label">Pilih Mahasiswa</label>
            <select id="user_id" name="user_id" class="form-select" required>
                <option value="">-- Pilih Mahasiswa --</option>
                <?php foreach ($userList as $user): ?>
                    <option value="<?= htmlspecialchars($user['id']) ?>" <?= ($nilai['user_id'] == $user['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($user['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="nilai" class="form-label">Nilai (0-100)</label>
            <input type="number" id="nilai" name="nilai" class="form-control" min="0" max="100" required value="<?= htmlspecialchars($nilai['nilai']) ?>" />
        </div>

        <div class="mb-3">
            <label for="komentar" class="form-label">Komentar</label>
            <textarea id="komentar" name="komentar" class="form-control" rows="4"><?= htmlspecialchars($nilai['komentar']) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Perbarui Nilai</button>
        <a href="nilai.php" class="btn btn-secondary">Kembali</a>
    </form>
</main>

<?php if ($success): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Sukses',
    text: <?= json_encode($success) ?>,
    timer: 3000,
    showConfirmButton: false
});
</script>
<?php endif; ?>

<?php if ($error): ?>
<script>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: <?= json_encode($error) ?>,
    timer: 4000,
    showConfirmButton: true
});
</script>
<?php endif; ?>

</body>
</html>