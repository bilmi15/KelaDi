<?php 
session_start();
require_once '../includes/config.php';

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['dosen', 'mahasiswa'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Ambil daftar kelas untuk filter
if ($role === 'dosen') {
    // Dosen melihat kelas yang mereka ajar
    $stmt = $pdo->prepare("SELECT id, nama_kelas FROM kelas WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $kelasList = $stmt->fetchAll();
} else {
    // Mahasiswa hanya melihat kelas yang mereka ikuti
    $stmt = $pdo->prepare("SELECT k.id, k.nama_kelas FROM kelas k JOIN kelas_mahasiswa km ON k.id = km.kelas_id WHERE km.mahasiswa_id = ?");
    $stmt->execute([$user_id]);
    $kelasList = $stmt->fetchAll();
}

$kelas_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;

// Query untuk mendapatkan data nilai berdasarkan peran dan kelas
if ($role === 'mahasiswa') {
    // Untuk mahasiswa, hanya tampilkan nilai mereka sendiri dan berdasarkan kelas yang dipilih
    $stmt = $pdo->prepare("
        SELECT n.id, t.judul AS tugas_judul, u.name AS user_name, n.nilai, n.komentar, n.submitted_at
        FROM nilai n
        LEFT JOIN tugas t ON n.tugas_id = t.id
        LEFT JOIN users u ON n.user_id = u.id
        LEFT JOIN kelas k ON t.kelas_id = k.id
        WHERE u.id = ? AND k.id = ?
        ORDER BY n.submitted_at DESC
    ");
    $stmt->execute([$user_id, $kelas_id]);
} else {
    // Untuk dosen, tampilkan semua nilai berdasarkan kelas yang dipilih
    $stmt = $pdo->prepare("
        SELECT n.id, t.judul AS tugas_judul, u.name AS user_name, n.nilai, n.komentar, n.submitted_at
        FROM nilai n
        LEFT JOIN tugas t ON n.tugas_id = t.id
        LEFT JOIN users u ON n.user_id = u.id
        LEFT JOIN kelas k ON t.kelas_id = k.id
        WHERE n.dinilai_oleh = ? AND k.id = ?
        ORDER BY n.submitted_at DESC
    ");
    $stmt->execute([$user_id, $kelas_id]);
}

$nilaiList = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Daftar Nilai | Dashboard <?= ucfirst($role) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/grade.css">

<main class="container mt-4">
    <h2>Daftar Nilai</h2>

    <!-- Filter Kelas -->
    <form method="GET" class="mb-3">
        <label for="kelas_id" class="form-label">Filter Kelas:</label>
        <select name="kelas_id" id="kelas_id" class="form-select" onchange="this.form.submit()">
            <option value="">-- Semua Kelas --</option>
            <?php foreach ($kelasList as $kelas): ?>
                <option value="<?= $kelas['id'] ?>" <?= $kelas_id == $kelas['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($kelas['nama_kelas']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <!-- Display 'Add Nilai' button only for dosen -->
    <?php if ($role === 'dosen'): ?>
        <a href="admin_add_nilai.php" class="btn btn-primary mb-3">Tambah Nilai Baru</a>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Tugas</th>
                    <th>Nama Mahasiswa</th>
                    <th>Nilai</th>
                    <th>Komentar</th>
                    <th>Diserahkan Pada</th>
                    <?php if ($role === 'dosen'): ?>
                        <th>Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($nilaiList) > 0): ?>
                    <?php foreach ($nilaiList as $nilai): ?>
                        <tr>
                            <td><?= htmlspecialchars($nilai['id']) ?></td>
                            <td><?= htmlspecialchars($nilai['tugas_judul'] ?? 'Tugas tidak ditemukan') ?></td>
                            <td><?= htmlspecialchars($nilai['user_name'] ?? 'User tidak ditemukan') ?></td>
                            <td><?= htmlspecialchars($nilai['nilai']) ?></td>
                            <td><?= nl2br(htmlspecialchars($nilai['komentar'])) ?></td>
                            <td><?= htmlspecialchars($nilai['submitted_at']) ?></td>
                            <?php if ($role === 'dosen'): ?>
                                <!-- For dosen, actions to edit or delete nilai -->
                                <td>
                                    <a href="admin_edit_nilai.php?id=<?= urlencode($nilai['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="admin_delete_nilai.php?id=<?= urlencode($nilai['id']) ?>" onclick="return confirm('Yakin hapus nilai ini?');" class="btn btn-sm btn-danger">Hapus</a>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="<?= $role === 'dosen' ? 7 : 6 ?>" class="text-center">Belum ada data nilai.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

</body>
</html>