<?php
session_start();
require_once '../includes/config.php';

// Cek apakah pengguna sudah login dan memiliki role 'dosen'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: nilai.php");
    exit;
}

$id = (int)$_GET['id'];
$error = '';

// Proses hapus data nilai setelah konfirmasi POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'yes') {
        try {
            $stmt = $pdo->prepare("DELETE FROM nilai WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success_message'] = "Nilai berhasil dihapus.";
            header("Location: nilai.php");
            exit;
        } catch (PDOException $e) {
            $error = "Gagal menghapus nilai: " . $e->getMessage();
        }
    } else {
        // Jika batal hapus, kembali ke halaman nilai.php
        header("Location: nilai.php");
        exit;
    }
}

// Ambil data nilai untuk konfirmasi (misal: tampilkan komentar atau nilai)
$stmt = $pdo->prepare("SELECT n.id, n.nilai, u.name as mahasiswa, t.judul as tugas 
                       FROM nilai n
                       LEFT JOIN users u ON n.user_id = u.id
                       LEFT JOIN tugas t ON n.tugas_id = t.id
                       WHERE n.id = ?");
$stmt->execute([$id]);
$nilai = $stmt->fetch();

if (!$nilai) {
    header("Location: nilai.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Hapus Nilai | Dashboard Dosen</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/dashboard_dosen.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
      body {
        background-color: #f0f4f8;
        font-family: 'Nunito', sans-serif;
        margin: 0;
        padding: 20px;
      }
      main.container {
        max-width: 500px;
        margin: 50px auto;
        background-color: white;
        padding: 30px 40px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        text-align: center;
      }
      button.btn-danger {
        background-color: #dc3545;
        border-color: #dc3545;
        padding: 10px 25px;
        font-weight: 600;
        border-radius: 8px;
        margin-right: 15px;
        transition: background-color 0.3s ease;
        color: white;
      }
      button.btn-danger:hover {
        background-color: #bb2d3b;
        border-color: #bb2d3b;
      }
      a.btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
        padding: 10px 25px;
        font-weight: 600;
        border-radius: 8px;
        color: white;
        text-decoration: none;
        transition: background-color 0.3s ease;
      }
      a.btn-secondary:hover {
        background-color: #565e64;
        border-color: #565e64;
      }
    </style>
</head>
<body>

<main class="container">
  <h2>Konfirmasi Hapus Nilai</h2>
  <p>Apakah Anda yakin ingin menghapus nilai berikut?</p>
  <p><strong>Mahasiswa:</strong> <?= htmlspecialchars($nilai['mahasiswa']) ?></p>
  <p><strong>Tugas:</strong> <?= htmlspecialchars($nilai['tugas']) ?></p>
  <p><strong>Nilai:</strong> <?= htmlspecialchars($nilai['nilai']) ?></p>

  <form method="post" action="">
    <button type="submit" name="confirm" value="yes" class="btn btn-danger">Ya, Hapus</button>
    <a href="nilai.php" class="btn btn-secondary">Batal</a>
  </form>
</main>

<?php if ($error): ?>
<script>
Swal.fire({
  icon: 'error',
  title: 'Error',
  text: <?= json_encode($error) ?>,
  timer: 4000,
  showConfirmButton: true
});
</script>
<?php endif; ?>

</body>
</html>