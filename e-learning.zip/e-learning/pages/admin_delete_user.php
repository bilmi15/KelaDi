<?php
session_start();
require_once '../includes/config.php';

// Cek apakah pengguna sudah login dan memiliki role 'dosen'
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin_users.php");
    exit;
}

$id = (int)$_GET['id'];

// Hapus user berdasarkan id
$stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
$stmt->execute([$id]);

// Bisa tambahkan notifikasi sukses di session jika ingin
$_SESSION['success_message'] = "User berhasil dihapus.";

header("Location: admin_users.php");
exit;