<?php
session_start();
require_once '../includes/config.php';

// Pastikan pengguna sudah login dan memiliki role 'dosen'
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'dosen') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

if (isset($_GET['id'])) {
    $mahasiswa_id = $_GET['id'];

    // Ambil data mahasiswa berdasarkan ID
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$mahasiswa_id]);
    $mahasiswa = $stmt->fetch();

    if (!$mahasiswa) {
        header("Location: jumlah_mahasiswa.php");
        exit;
    }

    // Proses form edit
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name'] ?? '');

        if (!$name) {
            $error = "Nama mahasiswa wajib diisi.";
        } else {
            // Update nama mahasiswa
            $stmt = $pdo->prepare("UPDATE users SET name = ? WHERE id = ?");
            $stmt->execute([$name, $mahasiswa_id]);

            // Notifikasi jika berhasil
            $_SESSION['success'] = "Nama mahasiswa berhasil diperbarui.";
            header("Location: jumlah_mahasiswa.php");
            exit;
        }
    }
} else {
    header("Location: jumlah_mahasiswa.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Mahasiswa</title>
    <link rel="stylesheet" href="../assets/css/jumlah_mahasiswa.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-4">
    <h2>Edit Mahasiswa</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="name" class="form-label">Nama Mahasiswa</label>
            <input type="text" id="name" name="name" class="form-control" value="<?= htmlspecialchars($mahasiswa['name']) ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Update Mahasiswa</button>
    </form>

    <a href="jumlah_mahasiswa.php" class="btn btn-secondary mt-3">Kembali</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>