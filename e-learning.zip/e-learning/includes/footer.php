<?php
// includes/footer.php
?>
    <footer class="main-footer <?php echo $isPagesFolder ? 'pages-footer' : ''; ?>" role="contentinfo">
      <div class="container">
        &copy; <?= date('Y') ?> KelaDi — Kelas Digital untuk Generasi Cerdas.
      </div>
    </footer>
  </div> <!-- .content-wrapper -->

  <!-- Bootstrap & AOS JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  
  <!-- Toggle Search Input JS -->
  <script src="assets/js/search-toggle.js"></script>

  <!-- Dark Mode Toggle JS -->
  <script src="assets/js/dark-mode-toggle.js" defer></script>

  <!-- Carousel Autoplay JS -->
  <script src="assets/js/carousel-autoplay.js" defer></script>

  <script>
    window.addEventListener('load', () => {
      const overlay = document.getElementById('loadingOverlay');
      const content = document.querySelector('.content-wrapper');
      overlay.style.opacity = 0;
      setTimeout(() => {
        overlay.style.display = 'none';
        content.classList.add('loaded');
      }, 600);
    });

    // Dynamic greeting function
    function setGreeting() {
      const greetingElem = document.getElementById('greeting');
      if (!greetingElem) return;
      const hour = new Date().getHours();
      let greetingText = 'Halo!';
      if (hour >= 4 && hour < 10) greetingText = 'Hallo, Selamat Pagi, Sahabat! 🌅';
      else if (hour >= 10 && hour < 15) greetingText = 'Hallo, Selamat Siang, Sahabat! ☀️';
      else if (hour >= 15 && hour < 18) greetingText = 'Hallo, Selamat Sore, Sahabat! 🌇';
      else greetingText = 'Hallo, Selamat Malam, Sahabat! 🌙';
      greetingElem.textContent = greetingText;
    }
    setGreeting();

    // Initialize AOS animations
    AOS.init({ duration: 1000, once: true });

    // Load tsParticles configuration
    tsParticles.load("tsparticles", {
      fpsLimit: 60,
      particles: {
        number: { value: 60, density: { enable: true, area: 800 } },
        color: { value: "#14B8A6" },
        shape: { type: "circle" },
        opacity: { value: 0.3, random: true },
        size: { value: 3, random: true },
        move: { enable: true, speed: 1, direction: "none", outModes: "bounce" },
        links: {
          enable: true,
          distance: 150,
          color: "#14B8A6",
          opacity: 0.4,
          width: 1
        }
      },
      interactivity: {
        events: {
          onHover: { enable: true, mode: "grab" },
          onClick: { enable: true, mode: "push" }
        },
        modes: {
          grab: { distance: 150, links: { opacity: 0.4 } },
          push: { quantity: 4 }
        }
      },
      detectRetina: true
    });

    // Make feature cards clickable and keyboard accessible
    document.querySelectorAll('.feature-card').forEach(card => {
      card.addEventListener('click', () => {
        const link = card.getAttribute('data-link');
        if (link) window.location.href = link;
      });
      card.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const link = card.getAttribute('data-link');
          if (link) window.location.href = link;
        }
      });
    });
  </script>
</body>
</html>