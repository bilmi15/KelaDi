<?php
require_once '../includes/config.php';

// Fungsi untuk validasi file upload
function isValidFileType($fileType, $allowedTypes) {
    return in_array(strtolower($fileType), $allowedTypes);
}

// Fungsi untuk menangani upload file media
function handleFileUpload($file, $tipe_media, $uploadDir = '../uploads/') {
    $fileTmpPath = $file['tmp_name'];
    $fileName = basename($file['name']);
    $fileSize = $file['size'];
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    // Validasi ukuran file
    if ($fileSize > 10 * 1024 * 1024) {
        return "Ukuran file maksimal 10MB.";
    }

    // Tentukan ekstensi yang diperbolehkan
    $allowedExtensions = [];
    switch ($tipe_media) {
        case 'image': $allowedExtensions = ['jpg','jpeg','png','gif']; break;
        case 'video': $allowedExtensions = ['mp4']; break;
        case 'pdf': $allowedExtensions = ['pdf']; break;
        case 'lottie': $allowedExtensions = ['json']; break;
        default: $allowedExtensions = [];
    }

    // Cek apakah ekstensi file sesuai
    if (!empty($allowedExtensions) && !isValidFileType($fileType, $allowedExtensions)) {
        return "Ekstensi file tidak sesuai untuk tipe media yang dipilih.";
    }

    // Proses penyimpanan file
    $newFileName = uniqid('media_', true) . '.' . $fileType;
    $destPath = $uploadDir . $newFileName;
    if (!move_uploaded_file($fileTmpPath, $destPath)) {
        return "Gagal menyimpan file upload.";
    }
    return 'uploads/' . $newFileName; // Mengembalikan path relatif
}

// Fungsi untuk menambah notifikasi
function addNotification($pdo, $user_id, $judul, $message, $url = null) {
    $sql = "INSERT INTO notifications (user_id, sender_role, judul, message, url, is_read, created_at) VALUES (?, ?, ?, ?, ?, 0, NOW())";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id, 'dosen', $judul, $message, $url]);
}

// Fungsi untuk melihat preview media
function previewMedia($mediaUrl, $mediaType) {
    $file = preg_match('#^https?://#i', $mediaUrl) ? $mediaUrl : '../' . ltrim($mediaUrl, '/');
    $content = '';

    switch ($mediaType) {
        case 'pdf':
            $content = "<embed src='$file' type='application/pdf' width='100%' height='600px' />";
            break;
        case 'video':
            $content = "<video width='100%' controls><source src='$file' type='video/mp4'>Browser tidak mendukung video.</video>";
            break;
        case 'image':
            $content = "<img src='$file' alt='Preview Image' style='max-width:100%; height:auto;' />";
            break;
        case 'lottie':
            $content = "<lottie-player src='$file' background='transparent' speed='1' loop autoplay style='width:100%; height:300px;'></lottie-player>";
            break;
        case 'url':
            $content = "<iframe src='$file' width='100%' height='600' frameborder='0' allowfullscreen></iframe>";
            break;
        default:
            $content = "<p class='text-danger'>Tipe file tidak dikenali atau tidak dapat dipreview.</p>";
    }
    return $content;
}

// Fungsi untuk menampilkan tugas berdasarkan kelas
function getTugasByKelas($pdo, $kelas_id) {
    $stmt = $pdo->prepare("SELECT * FROM tugas WHERE kelas_id = ? ORDER BY created_at DESC");
    $stmt->execute([$kelas_id]);
    return $stmt->fetchAll();
}

// Fungsi untuk menangani upload tugas oleh mahasiswa
function uploadTugas($pdo, $user_id, $tugas_id, $file, $description = "") {
    $file_url = handleFileUpload($file, 'pdf');
    if (strpos($file_url, 'uploads/') === false) {
        return $file_url; // Jika ada error dalam upload, akan mengembalikan pesan error
    }

    $stmt = $pdo->prepare("INSERT INTO hasil_tugas (tugas_id, user_id, upload_id, description, submitted_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->execute([$tugas_id, $user_id, $file_url, $description]);
    return "Tugas berhasil diupload!";
}

// Fungsi untuk menilai tugas mahasiswa
function giveGrade($pdo, $nilai, $komentar, $user_id, $tugas_id) {
    $stmt = $pdo->prepare("UPDATE hasil_tugas SET nilai = ?, komentar = ? WHERE user_id = ? AND tugas_id = ?");
    $stmt->execute([$nilai, $komentar, $user_id, $tugas_id]);

    $stmt2 = $pdo->prepare("INSERT INTO nilai (hasil_tugas_id, nilai, komentar, dinilai_oleh) VALUES (?, ?, ?, ?)");
    $stmt2->execute([$tugas_id, $nilai, $komentar, $user_id]);
    return "Penilaian berhasil!";
}

// Fungsi untuk mendapatkan nilai tugas mahasiswa
function getGrades($pdo, $tugas_id, $user_id) {
    $stmt = $pdo->prepare("SELECT * FROM nilai WHERE hasil_tugas_id = ? AND user_id = ?");
    $stmt->execute([$tugas_id, $user_id]);
    return $stmt->fetch();
}

// Fungsi untuk memeriksa role pengguna (dosen atau mahasiswa)
function checkUserRole($role) {
    if ($_SESSION['role'] !== $role) {
        header('Location: login.php');
        exit;
    }
}

// Fungsi untuk menangani perbedaan akses pada halaman uploads.php untuk mahasiswa dan hasil_tugas.php untuk dosen
function handleAccessControl($page) {
    // Pastikan pengguna telah login
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }

    // Periksa peran pengguna (role) untuk menentukan akses halaman
    if ($page == 'uploads.php' && $_SESSION['role'] == 'mahasiswa') {
        // Mahasiswa hanya bisa mengupload tugas
        return true;
    } elseif ($page == 'hasil_tugas.php' && $_SESSION['role'] == 'dosen') {
        // Dosen bisa melihat hasil tugas dan menilai
        return true;
    } elseif ($page == 'tugas.php' && $_SESSION['role'] == 'dosen') {
        // Dosen bisa melihat dan mengelola tugas
        return true;
    } elseif ($page == 'nilai.php' && ($_SESSION['role'] == 'dosen' || $_SESSION['role'] == 'mahasiswa')) {
        // Baik dosen maupun mahasiswa bisa melihat nilai
        return true;
    }

    // Jika akses tidak sesuai
    return false;
}

// Fungsi untuk mengatur tampilan berdasarkan role pengguna
function displayDashboardContent() {
    if ($_SESSION['role'] == 'dosen') {
        // Konten khusus dosen
        echo "<h1>Selamat datang, Dosen</h1>";
        echo "<p>Anda memiliki akses untuk mengelola tugas, penilaian, dan materi.</p>";
    } elseif ($_SESSION['role'] == 'mahasiswa') {
        // Konten khusus mahasiswa
        echo "<h1>Selamat datang, Mahasiswa</h1>";
        echo "<p>Anda memiliki akses untuk melihat materi, mengupload tugas, dan melihat hasil penilaian.</p>";
    }
}

?>