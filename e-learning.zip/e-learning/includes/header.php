<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>KelaDi - Kelas Digital</title>

  <!-- Google Fonts Nunito -->
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

  <!-- AOS CSS -->
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />

  <!-- SweetAlert2 & Animate.css -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

  <!-- tsParticles -->
  <script src="https://cdn.jsdelivr.net/npm/tsparticles@2.11.1/tsparticles.bundle.min.js"></script>

  <!-- Lottie Player -->
  <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js" defer></script>

  <!-- Dark Mode Toggle -->
  <script src="assets/js/dark-mode-toggle.js" defer></script>

  <!-- CSS Global & Halaman -->
  <link rel="stylesheet" href="assets/css/layout.css" />
  <link rel="stylesheet" href="assets/css/header-footer.css" />

  <?php
  // Load CSS khusus halaman
  $file = basename($_SERVER['PHP_SELF']);
  if ($file === 'index.php') {
    echo '<link rel="stylesheet" href="assets/css/index.css" />';
  } elseif ($file === 'search.php') {
    echo '<link rel="stylesheet" href="assets/css/search.css" />';
  } elseif (in_array($file, ['kelas_online.php', 'materi.php', 'progress.php', 'tentang.php'])) {
    echo '<link rel="stylesheet" href="assets/css/fitur_card.css" />';
  }
  $folder = basename(dirname($_SERVER['PHP_SELF']));
  $isPagesFolder = ($folder === 'pages');
  ?>
</head>
<body class="<?= $file == 'search.php' ? 'search-page' : '' ?>">

  <div id="loadingOverlay" aria-live="polite" aria-busy="true" role="alert">
    <div class="spinner-border" role="status" aria-hidden="true"></div>
    <p>Memuat KelaDi...</p>
  </div>

  <div id="tsparticles" aria-hidden="true"></div>

  <div class="content-wrapper">
    <header class="main-header" role="banner" aria-label="Header website">
      <a href="index.php" class="branding" role="link" aria-label="Beranda KelaDi" tabindex="0">
        <img src="assets/images/logokeladi.png" alt="Logo KelaDi" />
        <span class="tagline">Belajar Modern, Mudah, dan Menyenangkan</span>
      </a>

      <?php if ($file !== 'search.php'): ?>
      <form class="header-search-form" role="search" method="GET" action="search.php" aria-label="Form pencarian konten">
        <input
          type="text"
          name="query"
          placeholder="Cari konten..."
          aria-label="Input pencarian konten"
          required
        />
        <button type="submit" aria-label="Cari konten">
          Cari
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" >
            <path
              d="M21 21l-4.35-4.35m-1.4 0A6.6 6.6 0 1 0 6.6 6.6a6.6 6.6 0 0 0 8.65 8.65z"
              stroke="currentColor"
              stroke-width="2"
              fill="none"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </button>
      </form>
      <?php endif; ?>

<?php if (isset($_SESSION['username'])): ?>
    <div class="user-dropdown" tabindex="0" aria-haspopup="true" aria-expanded="false">
        <button class="user-name" aria-haspopup="true" aria-expanded="false" aria-label="User menu">
            <span class="user-fullname"><?= htmlspecialchars($_SESSION['name'] ?? 'User') ?></span>
            <span class="user-username"><?= htmlspecialchars($_SESSION['username'] ?? '') ?></span>
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="margin-left:6px;">
                <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
        </button>
        <div class="dropdown-menu" role="menu" aria-label="User menu options" hidden>
            <!-- Membuat URL absolut berdasarkan session role -->
            <a href="<?= ($_SESSION['role'] == 2) ? 'http://' . $_SERVER['HTTP_HOST'] . '/e-learning/pages/dashboard.php' : 'http://' . $_SERVER['HTTP_HOST'] . '/e-learning/pages/dashboard.php'; ?>" class="dropdown-item" role="menuitem" tabindex="-1">Dashboard</a>
            <a href="http://<?= $_SERVER['HTTP_HOST'] ?>/e-learning/pages/logout.php" class="dropdown-item" role="menuitem" tabindex="-1">Logout</a>
        </div>
    </div>
<?php else: ?>
    <button class="btn-login" onclick="window.location.href='pages/login.php';" aria-label="Login">Login</button>
<?php endif; ?>

      <!-- Dark Mode Toggle -->
      <label class="dark-mode-toggle" title="Toggle dark mode" aria-label="Toggle dark mode">
        <input type="checkbox" id="darkModeToggle" aria-checked="false" />
        <span class="toggle-slider" role="presentation">
          <span class="icon sun" aria-hidden="true">&#9728;</span>
          <span class="icon moon" aria-hidden="true">&#9790;</span>
          <span class="toggle-thumb"></span>
        </span>
      </label>
    </header>

<script>
  // Welcome popup hanya muncul 1x dalam 24 jam
  document.addEventListener('DOMContentLoaded', () => {
    const popupKey = 'keladi-welcome-popup';
    const lastPopup = localStorage.getItem(popupKey);
    const now = Date.now();
    const dayInMs = 24 * 60 * 60 * 1000;

    if (!lastPopup || now - lastPopup > dayInMs) {
      Swal.fire({
        title: 'Selamat datang di KelaDi!',
        text: 'Platform pembelajaran digital terbaik untuk generasi cerdas.',
        icon: 'info',
        confirmButtonText: 'Mulai Belajar',
        showClass: { popup: 'animate__animated animate__fadeInDown' },
        hideClass: { popup: 'animate__animated animate__fadeOutUp' }
      }).then(() => {
        localStorage.setItem(popupKey, now);
      });
    }
  });

  // Toggle dropdown user menu saat klik nama user
  document.addEventListener('DOMContentLoaded', () => {
    const userDropdown = document.querySelector('.user-dropdown');
    if (!userDropdown) return;

    const userBtn = userDropdown.querySelector('.user-name');
    const dropdownMenu = userDropdown.querySelector('.dropdown-menu');

    userBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const isExpanded = userDropdown.classList.toggle('show');
      userBtn.setAttribute('aria-expanded', isExpanded);
      dropdownMenu.hidden = !isExpanded;
    });

    // Tutup dropdown jika klik di luar elemen
    document.addEventListener('click', (e) => {
      if (!userDropdown.contains(e.target)) {
        userDropdown.classList.remove('show');
        userBtn.setAttribute('aria-expanded', 'false');
        dropdownMenu.hidden = true;
      }
    });
  });
</script>

</body>
</html>