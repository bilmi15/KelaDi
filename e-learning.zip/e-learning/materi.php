<?php
include 'includes/header.php';
?>

<main class="kelas-online-main" role="main" tabindex="-1">
  <h1 class="page-title">Materi Interaktif</h1>

  <section class="kelas-card" aria-label="Konten materi interaktif">
    <div class="lottie-wrapper">
      <lottie-player
        src="https://assets4.lottiefiles.com/packages/lf20_0yfsb3a1.json"
        background="transparent"
        speed="1"
        loop
        autoplay>
      </lottie-player>
    </div>

    <p class="kelas-description">
      Pelajari berbagai materi pembelajaran digital seperti PDF, video, dan kuis interaktif yang dapat kamu akses kapan saja secara fleksibel dan terstruktur.
    </p>
  </section>

  <button class="btn-kembali" onclick="window.location.href='index.php'" aria-label="Kembali ke beranda">
    ← Kembali ke Beranda
  </button>
</main>

<?php include 'includes/footer.php'; ?>