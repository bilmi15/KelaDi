<?php
include 'includes/header.php';
?>

<main class="kelas-online-main" role="main" tabindex="-1">
  <h1 class="page-title">Kelas Online</h1>

  <section class="kelas-card" aria-label="Deskripsi kelas online">
    <div class="lottie-wrapper">
      <lottie-player 
        src="https://assets10.lottiefiles.com/packages/lf20_w51pcehl.json" 
        background="transparent" 
        speed="1" 
        loop 
        autoplay>
      </lottie-player>
    </div>

    <p class="kelas-description">
      Belajar secara interaktif dan real-time bersama pengajar profesional melalui kelas online, dengan diskusi langsung dan interaksi aktif.
    </p>
  </section>

  <button 
    class="btn-kembali" 
    type="button" 
    aria-label="Kembali ke beranda" 
    onclick="window.location.href='index.php'">
    ← Kembali ke Beranda
  </button>
</main>

<?php include 'includes/footer.php'; ?>