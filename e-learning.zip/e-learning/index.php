<?php
include 'includes/header.php';
?>

<main role="main" aria-label="Konten utama">

<section class="hero" aria-label="Hero section" data-aos="fade-up" data-aos-duration="1000">
    <div class="hero-text">
        <h1>KelaDi</h1>
        <div class="dynamic-greeting" id="greeting" aria-live="polite"></div>
        <p>Platform pembelajaran digital terbaik yang membantu kamu belajar dengan cara modern, mudah, dan menyenangkan.</p>
        <div class="hero-buttons" role="group" aria-label="Tombol aksi utama">
            <button class="btn btn-keladi" onclick="location.href='pages/login.php'" aria-label="Mulai belajar di kelas online"> Mulai Belajar</button>
            <button class="btn btn-outline-keladi" onclick="location.href='pages/register.php'" aria-label="Daftar untuk mengikuti kelas"> Daftar Akun</button>
        </div>
    </div>
    <div class="hero-img" aria-hidden="true" data-aos="fade-left" data-aos-duration="1200" data-aos-delay="300">
        <img src="assets/images/utama.png" alt="Ilustrasi pembelajaran digital" />
    </div>
</section>

<section id="featuresCarousel" aria-label="Fitur KelaDi">
  <h2 id="featureTitle" data-aos="fade-up" data-aos-duration="1000">Fitur Unggulan</h2>
  <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" data-bs-interval="6000" tabindex="0">
    <div class="carousel-inner">
      <div class="carousel-item active" data-aos="fade-right" data-aos-duration="800">
        <div class="feature-card" tabindex="0" role="button" data-link="kelas_online.php" aria-label="Kelas Online">
          <lottie-player
           src="https://assets10.lottiefiles.com/packages/lf20_w51pcehl.json"
           background="transparent"
           speed="1"
           loop
           autoplay
           class="feature-lottie">
          </lottie-player>
          <h3 class="feature-title text-purple">Kelas Online</h3>
          <p class="feature-desc">Ikuti kelas live atau rekaman dengan diskusi langsung dan interaksi aktif.</p>
        </div>
      </div>
      <div class="carousel-item" data-aos="fade-right" data-aos-duration="800" data-aos-delay="150">
        <div class="feature-card" tabindex="0" role="button" data-link="materi.php" aria-label="Materi Interaktif Terstruktur">
          <lottie-player
           src="https://assets4.lottiefiles.com/packages/lf20_0yfsb3a1.json"
           background="transparent"
           speed="1"
           loop
           autoplay
           class="feature-lottie">
          </lottie-player>
          <h3 class="feature-title text-purple">Materi Interaktif Terstruktur</h3>
          <p class="feature-desc">Pelajari berbagai materi pembelajaran digital seperti PDF, video, dan interaktif yang dapat diakses kapan saja.</p>
        </div>
      </div>
      <div class="carousel-item" data-aos="fade-right" data-aos-duration="800" data-aos-delay="300">
        <div class="feature-card" tabindex="0" role="button" data-link="progress.php" aria-label="Tracking Progress">
          <lottie-player
           src="https://assets7.lottiefiles.com/packages/lf20_M9p23l.json"
           background="transparent"
           speed="1"
           loop
           autoplay
           class="feature-lottie">
          </lottie-player>
          <h3 class="feature-title text-purple">Monitoring Progres Belajar</h3>
          <p class="feature-desc">Lihat perkembangan belajar dan capaian tugas di dashboard pribadi Anda.</p>
        </div>
      </div>
      <div class="carousel-item" data-aos="fade-right" data-aos-duration="800" data-aos-delay="450">
        <div class="feature-card" tabindex="0" role="button" data-link="tentang.php" aria-label="Tentang KelaDi">
          <lottie-player
           src="https://assets9.lottiefiles.com/packages/lf20_49rdyysj.json"
           background="transparent"
           speed="1"
           loop
           autoplay
           class="feature-lottie">
          </lottie-player>
          <h3 class="feature-title text-purple">Tentang KelaDi</h3>
          <p class="feature-desc">Website ini dikembangkan oleh mahasiswa sebagai bagian dari proyek akhir matkul Pemrograman Web.</p>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev" aria-label="Slide sebelumnya">
      <span aria-hidden="true">&#8249;</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next" aria-label="Slide berikutnya">
      <span aria-hidden="true">&#8250;</span>
    </button>
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" aria-label="Slide 1" class="active" aria-current="true"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
      <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
    </div>
  </div>
</section>

<section id="visimisiCards" aria-label="Visi dan Misi KelaDi">
  <h2 class="feature-title" style="margin-bottom: 2rem;" data-aos="fade-up" data-aos-duration="1000">Visi & Misi KelaDi</h2>
  
  <div class="visi-misi-wrapper">
    
    <!-- VISI -->
    <div class="feature-card visi" data-aos="fade-right" data-aos-duration="1000" data-aos-delay="100">
      <lottie-player
        src="https://assets1.lottiefiles.com/packages/lf20_k86wxpgr.json"
        background="transparent"
        speed="1"
        loop
        autoplay
        class="feature-lottie"
      ></lottie-player>
      <h3 class="feature-title text-purple">Visi</h3>
      <p class="feature-desc">
        Menjadi platform pembelajaran digital terdepan yang menyajikan pengalaman belajar yang modern, mudah, dan menyenangkan untuk semua kalangan. Kami berkomitmen untuk memberikan solusi pembelajaran yang inovatif, inklusif, dan mendukung pengembangan keterampilan abad 21.
      </p>
    </div>

    <!-- MISI -->
    <div class="feature-card misi" data-aos="fade-left" data-aos-duration="1000" data-aos-delay="200">
      <lottie-player
        src="https://assets4.lottiefiles.com/packages/lf20_jcikwtux.json"
        background="transparent"
        speed="1"
        loop
        autoplay
        class="feature-lottie"
      ></lottie-player>
      <h3 class="feature-title text-purple">Misi</h3>
      <ul class="feature-desc">
        <li>Menyediakan konten pembelajaran yang interaktif dan berkualitas.</li>
        <li>Mendorong keterlibatan aktif antara pengajar dan pelajar.</li>
        <li>Mendukung pembelajaran fleksibel berbasis teknologi.</li>
        <li>Menjadi wadah pengembangan digital generasi cerdas.</li>
      </ul>
    </div>

  </div>
</section>

</main>

<!-- AOS JS -->
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    once: true,            // Animasi hanya sekali ketika muncul
    duration: 800,         // Durasi animasi default
    easing: 'ease-in-out', // Easing yang halus
  });
</script>

<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

<?php include 'includes/footer.php'; ?>