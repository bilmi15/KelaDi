<?php
include 'includes/header.php';
?>

<main class="kelas-online-main" role="main" tabindex="-1">
  <h1 class="page-title">Progress Belajar</h1>

  <section class="kelas-card" aria-label="Konten progress belajar">
    <div class="lottie-wrapper">
      <lottie-player
        src="https://assets7.lottiefiles.com/packages/lf20_M9p23l.json"
        background="transparent"
        speed="1"
        loop
        autoplay>
      </lottie-player>
    </div>

    <p class="kelas-description">
      Pantau perkembangan belajarmu dengan grafik visual yang informatif: mulai dari penyelesaian materi, capaian tugas, hingga nilai evaluasi.
    </p>
  </section>

  <button class="btn-kembali" onclick="window.location.href='index.php'" aria-label="Kembali ke beranda">
    ← Kembali ke Beranda
  </button>
</main>

<?php include 'includes/footer.php'; ?>