<?php
require_once 'includes/config.php';
include 'includes/header.php';

$query = trim($_GET['query'] ?? '');
$results = [];

if ($query !== '') {
  $allData = [
    ['title' => 'Kelas Online', 'desc' => 'Belajar secara interaktif dan real-time bersama pengajar profesional melalui kelas online, dengan diskusi langsung dan interaksi aktif.', 'link' => 'materi.php'],
    ['title' => 'Materi Interaktif Terstruktur', 'desc' => 'Pelajari berbagai materi pembelajaran digital, seperti PDF, video, dan konten interaktif yang dapat diakses kapan saja, serta dapatkan informasi terbaru mengenai jadwal kelas online.', 'link' => 'kelas_online.php'],
    ['title' => 'Monitoring Progres Belajar', 'desc' => 'Pantau perkembangan dan capaian tugas belajar Anda secara sistematis melalui dashboard pribadi yang dirancang khusus untuk memonitor kemajuan belajar secara efektif.', 'link' => 'progress.php'],
    ['title' => 'Tentang KelaDi', 'desc' => 'Website ini merupakan hasil pengembangan mahasiswa dalam proyek akhir mata kuliah Pemrograman Web, yang dirancang untuk menyampaikan informasi lengkap mengenai visi dan misi KelaDi.', 'link' => 'tentang.php'],
  ];

  foreach ($allData as $item) {
    if (stripos($item['title'], $query) !== false || stripos($item['desc'], $query) !== false) {
      $results[] = $item;
    }
  }
}
?>

<main role="main" aria-label="Hasil pencarian">
  <section class="search-results-container">
    <h1>Hasil Pencarian untuk "<?= htmlspecialchars($query, ENT_QUOTES) ?>":</h1>

    <?php if (empty($results)): ?>
      <p>Tidak ditemukan hasil yang sesuai.</p>
    <?php else: ?>
      <?php foreach ($results as $res): ?>
        <a href="<?= htmlspecialchars($res['link'], ENT_QUOTES) ?>" class="result-item" role="link" tabindex="0" aria-label="Buka halaman <?= htmlspecialchars($res['title'], ENT_QUOTES) ?>">
          <h3><?= htmlspecialchars($res['title'], ENT_QUOTES) ?></h3>
          <p><?= htmlspecialchars($res['desc'], ENT_QUOTES) ?></p>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>

    <!-- Tombol Kembali -->
    <button="#" id="btnBack" class="btn btn-keladi" role="button" aria-label="Kembali ke halaman sebelumnya">← Kembali</a>
  </section>
</main>

<!-- Load dark-mode-toggle.js yang sudah ada -->
<script src="assets/js/dark-mode-toggle.js" defer></script>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const btnBack = document.getElementById('btnBack');
    btnBack.addEventListener('click', (e) => {
      e.preventDefault();
      if (document.referrer) {
        // Navigasi ke halaman sebelumnya dengan reload supaya mode gelap-terang update
        window.location.href = document.referrer;
      } else {
        // Jika tidak ada referrer, fallback ke index.php
        window.location.href = 'index.php';
      }
    });
  });
</script>

<?php include 'includes/footer.php'; ?>