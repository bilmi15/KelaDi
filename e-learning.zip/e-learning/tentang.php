<?php
include 'includes/header.php';
?>

<main class="kelas-online-main" role="main" tabindex="-1">

  <h1 class="page-title" data-aos="fade-down" data-aos-duration="800">Tentang KelaDi</h1>

  <section class="kelas-card" aria-label="Informasi tentang KelaDi" data-aos="fade-up" data-aos-duration="1000">
    <div class="lottie-wrapper" style="max-width: 400px; margin: 0 auto 1.5rem auto;">
      <lottie-player
        src="https://assets9.lottiefiles.com/packages/lf20_49rdyysj.json"
        background="transparent"
        speed="1"
        loop
        autoplay
        style="width: 100%; max-width: 400px; height: auto;">
      </lottie-player>
    </div>

    <p class="kelas-description">
      KelaDi adalah platform pembelajaran digital yang dikembangkan oleh mahasiswa sebagai bagian dari proyek akhir mata kuliah Pemrograman Web. Dibuat untuk mendukung proses belajar yang modern, terstruktur, dan menyenangkan.
    </p>
  </section>

  <section id="teamProfiles" aria-label="Profil Tim Pengembang KelaDi" style="max-width: 960px; margin: 3rem auto 4rem auto; padding: 0 1rem;">
    <h1 class="feature-title" data-aos="fade-up" data-aos-duration="900">Profil Anggota Kelompok 1</h1>

    <div class="visi-misi-wrapper" style="justify-content: center; gap: 2rem; flex-wrap: wrap; display: flex;">
      <!-- Profil 1 -->
      <div class="feature-card" style="max-width: 280px; min-height: auto;" data-aos="fade-up" data-aos-delay="100" tabindex="0" role="group" aria-label="Profil Nama Pengembang 1">
        <img src="assets/images/team/anggota1.jpg" alt="Foto Nama Pengembang 1" style="width: 150px; height: 150px; object-fit: cover; border-radius: 50%; margin: 0 auto 1rem auto; box-shadow: 0 4px 12px rgba(0,0,0,0.15);" />
        <h3 class="feature-title text-purple" style="margin-top: 0;">Muhammad Bahrul Ilmi</h3>
        <p class="feature-desc" style="font-size: 1rem; user-select: text; text-align: center;">
          Backend & Frontend Developer — Bertanggung jawab pada logika server, basis data, UI/UX, dan interaksi pengguna.
        </p>
      </div>

      <!-- Profil 2 -->
      <div class="feature-card" style="max-width: 280px; min-height: auto;" data-aos="fade-up" data-aos-delay="200" tabindex="0" role="group" aria-label="Profil Nama Pengembang 2">
        <img src="assets/images/team/anggota2.jpg" alt="Foto Nama Pengembang 2" style="width: 150px; height: 150px; object-fit: cover; border-radius: 50%; margin: 0 auto 1rem auto; box-shadow: 0 4px 12px rgba(0,0,0,0.15);" />
        <h3 class="feature-title text-purple" style="margin-top: 0;">Rizki Kurnia Tari</h3>
        <p class="feature-desc" style="font-size: 1rem; user-select: text; text-align: center;">
          Frontend Developer — Bertanggung jawab pada UI/UX dan interaksi pengguna.
        </p>
      </div>

      <!-- Profil 3 -->
      <div class="feature-card" style="max-width: 280px; min-height: auto;" data-aos="fade-up" data-aos-delay="300" tabindex="0" role="group" aria-label="Profil Nama Pengembang 3">
        <img src="assets/images/team/anggota3.jpg" alt="Foto Nama Pengembang 3" style="width: 150px; height: 150px; object-fit: cover; border-radius: 50%; margin: 0 auto 1rem auto; box-shadow: 0 4px 12px rgba(0,0,0,0.15);" />
        <h3 class="feature-title text-purple" style="margin-top: 0;">Fitri Zalita Dalimunthe</h3>
        <p class="feature-desc" style="font-size: 1rem; user-select: text; text-align: center;">
          Tester — Pengujian sistem, debugging, dan validasi fitur fungsional.
        </p>
      </div>

      <!-- Profil 4 -->
      <div class="feature-card" style="max-width: 280px; min-height: auto;" data-aos="fade-up" data-aos-delay="400" tabindex="0" role="group" aria-label="Profil Nama Pengembang 4">
        <img src="assets/images/team/anggota4.jpg" alt="Foto Nama Pengembang 4" style="width: 150px; height: 150px; object-fit: cover; border-radius: 50%; margin: 0 auto 1rem auto; box-shadow: 0 4px 12px rgba(0,0,0,0.15);" />
        <h3 class="feature-title text-purple" style="margin-top: 0;">Hanfiandi Akbar Siregar</h3>
        <p class="feature-desc" style="font-size: 1rem; user-select: text; text-align: center;">
          Manajer Proyek — Bertanggung jawab pada dokumentasi teknis, pembuatan mockup antarmuka, serta koordinasi dan pengawasan proyek.
        </p>
      </div>
    </div>
  </section>

  <button class="btn-kembali" onclick="window.location.href='index.php'" aria-label="Kembali ke beranda" data-aos="fade-up" data-aos-duration="800" data-aos-delay="500">
    ← Kembali ke Beranda
  </button>

</main>

<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({
    once: true,
    duration: 800,
    easing: 'ease-in-out',
  });
</script>

<?php include 'includes/footer.php'; ?>